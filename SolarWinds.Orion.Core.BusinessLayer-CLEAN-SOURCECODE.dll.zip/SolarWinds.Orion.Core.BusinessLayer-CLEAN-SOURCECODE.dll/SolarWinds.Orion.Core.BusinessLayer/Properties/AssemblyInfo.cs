﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("2020.2.5300.12432")]
[assembly: AssemblyCompany("SolarWinds Worldwide, LLC.")]
[assembly: AssemblyCopyright("Copyright © 1999-2020 SolarWinds Worldwide, LLC. All Rights Reserved.")]
[assembly: AssemblyFileVersion("2020.2.5300.12432")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
[assembly: InternalsVisibleTo("LINQPadQuery")]
[assembly: InternalsVisibleTo("SolarWinds.Orion.Core.BusinessLayer.Tests")]
[assembly: AssemblyTitle("SolarWinds.Orion.Core.BusinessLayer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("SolarWinds.Orion.Core.BusinessLayer")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("14e64ecd-0839-4fb5-a727-69a46cce6181")]
[assembly: InternalsVisibleTo("SolarWinds.Orion.Discovery.Job.Tests")]
