﻿using System;

// Token: 0x02000007 RID: 7
internal static class GlobalConstants
{
	// Token: 0x0400000C RID: 12
	public static readonly DateTime DropDeadDate = DateTime.MaxValue;
}
