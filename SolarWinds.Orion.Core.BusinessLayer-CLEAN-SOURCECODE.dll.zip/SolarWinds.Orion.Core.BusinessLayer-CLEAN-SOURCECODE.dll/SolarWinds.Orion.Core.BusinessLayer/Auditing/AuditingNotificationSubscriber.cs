﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SolarWinds.Common.Utility;
using SolarWinds.InformationService.Contract2;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.BusinessLayer;
using SolarWinds.Orion.Core.BusinessLayer.DAL;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.i18n;
using SolarWinds.Orion.Core.Common.Indications;
using SolarWinds.Orion.Core.Common.Swis;
using SolarWinds.Orion.PubSub;
using SolarWinds.Orion.Swis.PubSub;
using SolarWinds.Orion.Swis.PubSub.InformationService;

namespace SolarWinds.Orion.Core.Auditing
{
	// Token: 0x02000009 RID: 9
	internal class AuditingNotificationSubscriber : ISubscriber
	{
		// Token: 0x06000025 RID: 37 RVA: 0x000027CC File Offset: 0x000009CC
		public AuditingNotificationSubscriber() : this(SubscriptionManager.Instance)
		{
		}

		// Token: 0x06000026 RID: 38 RVA: 0x000027DC File Offset: 0x000009DC
		public AuditingNotificationSubscriber(ISubscriptionManager subscriptionManager)
		{
			if (subscriptionManager == null)
			{
				throw new ArgumentNullException("subscriptionManager");
			}
			this.subscriptionManager = subscriptionManager;
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000027 RID: 39 RVA: 0x0000282D File Offset: 0x00000A2D
		// (set) Token: 0x06000028 RID: 40 RVA: 0x00002835 File Offset: 0x00000A35
		private protected bool AuditingTrailsEnabled { protected get; private set; }

		// Token: 0x06000029 RID: 41 RVA: 0x00002840 File Offset: 0x00000A40
		private void PublishModificationOfAuditingEvents(AuditDatabaseDecoratedContainer auditDatabaseDecoratedContainer, int insertedId)
		{
			if (this.notificationPublisherManager == null)
			{
				this.notificationPublisherManager = PublisherClient.Instance;
			}
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					"ActionType",
					auditDatabaseDecoratedContainer.ActionType.ToString()
				},
				{
					"AuditEventId",
					insertedId
				},
				{
					"InstanceType",
					"Orion.AuditingEvents"
				},
				{
					"OriginalAccountId",
					auditDatabaseDecoratedContainer.AccountId
				}
			};
			Notification notification = new Notification("System.InstanceCreated", IndicationHelper.GetIndicationProperties(), dictionary);
			this.notificationPublisherManager.Publish(notification);
		}

		// Token: 0x0600002A RID: 42 RVA: 0x000028CB File Offset: 0x00000ACB
		private string FormatPropertyData(string prefix, string key, object value)
		{
			return string.Concat(new object[]
			{
				prefix,
				key,
				": ",
				value ?? "null",
				Environment.NewLine
			});
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00002900 File Offset: 0x00000B00
		public void Start()
		{
			try
			{
				this.AuditingTrailsEnabled = SettingsDAL.GetCurrent<bool>("SWNetPerfMon-AuditingTrails", true);
			}
			catch (Exception ex)
			{
				AuditingNotificationSubscriber.log.FatalFormat("Auditing setting error - will be forciby enabled. {0}", ex);
				this.AuditingTrailsEnabled = true;
			}
			this.checkAuditingSetting = true;
			this.auditingPlugins.Initialize();
			Scheduler.Instance.Add(new ScheduledTask("AuditingIndications", new TimerCallback(this.Subscribe), null, TimeSpan.FromSeconds(1.0), TimeSpan.FromMinutes(1.0)), true);
		}

		// Token: 0x0600002C RID: 44 RVA: 0x0000299C File Offset: 0x00000B9C
		public void Stop()
		{
			Scheduler.Instance.Remove("AuditingIndications");
		}

		// Token: 0x0600002D RID: 45 RVA: 0x000029B0 File Offset: 0x00000BB0
		private void Subscribe(object state)
		{
			AuditingNotificationSubscriber.log.Debug("Subscribing auditing indications..");
			try
			{
				AuditingNotificationSubscriber.DeleteOldSubscriptions();
			}
			catch (Exception ex)
			{
				AuditingNotificationSubscriber.log.Warn("Exception deleting old subscriptions:", ex);
			}
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			foreach (IAuditing2 auditing in this.auditingPlugins.AuditingInstances)
			{
				IAuditingMultiSubscription auditingMultiSubscription = auditing as IAuditingMultiSubscription;
				if (auditingMultiSubscription != null)
				{
					foreach (string item in auditingMultiSubscription.GetSubscriptionQueries())
					{
						hashSet.Add(item);
					}
				}
				else
				{
					hashSet.Add(auditing.GetSubscriptionQuery());
				}
			}
			foreach (string text in hashSet)
			{
				try
				{
					SubscriptionId subscriptionId;
					subscriptionId..ctor("Core", typeof(AuditingNotificationSubscriber).FullName + "." + this.GetHashFromQuery(text), 0);
					SubscriberConfiguration subscriberConfiguration = new SubscriberConfiguration
					{
						SubscriptionQuery = text
					};
					AuditingNotificationSubscriber.log.DebugFormat("Subscribing '{0}'", text);
					SubscriptionId id = this.subscriptionManager.Subscribe(subscriptionId, this, subscriberConfiguration).Id;
					string query1 = text;
					this.subscriptionIdToAuditingInstances.TryAdd(id.ToString(), this.auditingPlugins.AuditingInstances.Where(delegate(IAuditing2 instance)
					{
						bool result;
						try
						{
							result = (string.Compare(query1, instance.GetSubscriptionQuery(), StringComparison.OrdinalIgnoreCase) == 0);
						}
						catch (NotImplementedException)
						{
							IAuditingMultiSubscription auditingMultiSubscription2 = instance as IAuditingMultiSubscription;
							result = (auditingMultiSubscription2 != null && auditingMultiSubscription2.GetSubscriptionQueries().Contains(query1));
						}
						return result;
					}));
					AuditingNotificationSubscriber.log.DebugFormat("Subscribed '{0}' with {1} number of auditing instances.", text, this.subscriptionIdToAuditingInstances[id.ToString()].Count<IAuditing2>());
				}
				catch (Exception ex2)
				{
					AuditingNotificationSubscriber.log.ErrorFormat("Unable to subscribe auditing instance with query '{0}'. {1}", text, ex2);
				}
			}
			AuditingNotificationSubscriber.log.InfoFormat("Auditing pub/sub subscription succeeded.", Array.Empty<object>());
			Scheduler.Instance.Remove("AuditingIndications");
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00002C18 File Offset: 0x00000E18
		private static void DeleteOldSubscriptions()
		{
			using (IInformationServiceProxy2 informationServiceProxy = SwisConnectionProxyPool.GetSystemCreator().Create())
			{
				string text = "SELECT Uri FROM System.Subscription WHERE description = @description";
				foreach (DataRow dataRow in informationServiceProxy.Query(text, new Dictionary<string, object>
				{
					{
						"description",
						"AuditingIndications"
					}
				}).Rows.Cast<DataRow>())
				{
					informationServiceProxy.Delete(dataRow[0].ToString());
				}
			}
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00002CB8 File Offset: 0x00000EB8
		private string GetHashFromQuery(string query)
		{
			string result;
			using (SHA1 sha = SHA1.Create())
			{
				byte[] bytes = Encoding.ASCII.GetBytes(query);
				byte[] array = sha.ComputeHash(bytes);
				StringBuilder stringBuilder = new StringBuilder();
				foreach (byte b in array)
				{
					stringBuilder.Append(b.ToString("x2"));
				}
				result = stringBuilder.ToString();
			}
			return result;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00002D38 File Offset: 0x00000F38
		public Task OnNotificationAsync(Notification notification)
		{
			if (AuditingNotificationSubscriber.log.IsDebugEnabled)
			{
				AuditingNotificationSubscriber.log.DebugFormat("OnNotification type: {0} SubscriptionId: {1}", notification.IndicationType, notification.SubscriptionId);
			}
			PropertyBag propertyBag = new PropertyBag(notification.SourceInstanceProperties);
			PropertyBag propertyBag2 = new PropertyBag(notification.IndicationProperties);
			if (this.checkAuditingSetting)
			{
				try
				{
					object value;
					if (IndicationHelper.GetIndicationType(2) == notification.IndicationType && propertyBag != null && propertyBag.TryGet<string>("SettingsID") == "SWNetPerfMon-AuditingTrails" && propertyBag.TryGet<string>("InstanceType") == "Orion.Settings" && propertyBag.TryGetValue("CurrentValue", out value))
					{
						this.AuditingTrailsEnabled = Convert.ToBoolean(value);
					}
					else if (!this.AuditingTrailsEnabled)
					{
						return Task.CompletedTask;
					}
				}
				catch (Exception ex)
				{
					AuditingNotificationSubscriber.log.FatalFormat("Auditing check error - will be forciby enabled. {0}", ex);
					this.AuditingTrailsEnabled = true;
					this.checkAuditingSetting = false;
				}
			}
			AuditNotificationContainer auditNotificationContainer = new AuditNotificationContainer(notification.IndicationType, propertyBag2, propertyBag);
			IEnumerable<IAuditing2> enumerable;
			if (this.subscriptionIdToAuditingInstances.TryGetValue(notification.SubscriptionId.ToString(), out enumerable))
			{
				using (IEnumerator<IAuditing2> enumerator = enumerable.GetEnumerator())
				{
					Func<AuditDataContainer, AuditDataContainer> <>9__0;
					Func<string, KeyValuePair<string, object>, string> <>9__1;
					Func<string, KeyValuePair<string, object>, string> <>9__2;
					while (enumerator.MoveNext())
					{
						IAuditing2 auditing = enumerator.Current;
						try
						{
							if (AuditingNotificationSubscriber.log.IsTraceEnabled)
							{
								AuditingNotificationSubscriber.log.TraceFormat("Trying plugin {0}", new object[]
								{
									auditing
								});
							}
							IEnumerable<AuditDataContainer> enumerable2 = auditing.ComposeDataContainers(auditNotificationContainer);
							if (enumerable2 != null)
							{
								if (AuditingNotificationSubscriber.log.IsTraceEnabled)
								{
									AuditingNotificationSubscriber.log.Trace("Storing notification.");
								}
								CultureInfo currentUICulture = Thread.CurrentThread.CurrentUICulture;
								try
								{
									Thread.CurrentThread.CurrentUICulture = LocaleConfiguration.GetNonNeutralLocale(LocaleConfiguration.PrimaryLocale);
								}
								catch (Exception ex2)
								{
									AuditingNotificationSubscriber.log.Warn("Unable set CurrentUICulture to PrimaryLocale.", ex2);
								}
								IEnumerable<AuditDataContainer> source = enumerable2;
								Func<AuditDataContainer, AuditDataContainer> selector;
								if ((selector = <>9__0) == null)
								{
									selector = (<>9__0 = ((AuditDataContainer composedDataContainer) => new AuditDataContainer(composedDataContainer, auditNotificationContainer.AccountId)));
								}
								foreach (AuditDataContainer auditDataContainer in source.Select(selector))
								{
									AuditDatabaseDecoratedContainer auditDatabaseDecoratedContainer = new AuditDatabaseDecoratedContainer(auditDataContainer, auditNotificationContainer, auditing.GetMessage(auditDataContainer));
									int insertedId = this.auditingDAL.StoreNotification(auditDatabaseDecoratedContainer);
									this.PublishModificationOfAuditingEvents(auditDatabaseDecoratedContainer, insertedId);
								}
								try
								{
									Thread.CurrentThread.CurrentUICulture = currentUICulture;
									continue;
								}
								catch (Exception ex3)
								{
									AuditingNotificationSubscriber.log.Warn("Unable set CurrentUICulture back to original locale.", ex3);
									continue;
								}
							}
							if (AuditingNotificationSubscriber.log.IsTraceEnabled)
							{
								AuditingNotificationSubscriber.log.Trace("ComposeDataContainers returned null.");
							}
						}
						catch (Exception ex4)
						{
							string text = string.Empty;
							if (propertyBag2 != null)
							{
								IEnumerable<KeyValuePair<string, object>> source2 = propertyBag2;
								string newLine = Environment.NewLine;
								Func<string, KeyValuePair<string, object>, string> func;
								if ((func = <>9__1) == null)
								{
									func = (<>9__1 = ((string current, KeyValuePair<string, object> item) => current + this.FormatPropertyData("Indication Property: ", item.Key, item.Value)));
								}
								text = source2.Aggregate(newLine, func);
							}
							if (propertyBag != null)
							{
								IEnumerable<KeyValuePair<string, object>> source3 = propertyBag;
								string seed = text;
								Func<string, KeyValuePair<string, object>, string> func2;
								if ((func2 = <>9__2) == null)
								{
									func2 = (<>9__2 = ((string current, KeyValuePair<string, object> item) => current + this.FormatPropertyData("SourceInstance Property: ", item.Key, item.Value)));
								}
								text = source3.Aggregate(seed, func2);
							}
							AuditingNotificationSubscriber.log.ErrorFormat("Auditing translation failed. IndicationType: {0}, {1} PluginName: {2}, subscriptionId: {3} Exception: {4}", new object[]
							{
								notification.IndicationType,
								text,
								auditing.PluginName,
								notification.SubscriptionId,
								ex4
							});
						}
					}
					goto IL_38F;
				}
			}
			if (AuditingNotificationSubscriber.log.IsDebugEnabled)
			{
				AuditingNotificationSubscriber.log.DebugFormat("No auditing instances has been registered yet for subscriptionId '{0}'", notification.SubscriptionId.ToString());
			}
			IL_38F:
			return Task.CompletedTask;
		}

		// Token: 0x04000010 RID: 16
		private const string AuditingIndications = "AuditingIndications";

		// Token: 0x04000011 RID: 17
		private static readonly Log log = new Log(typeof(AuditingNotificationSubscriber));

		// Token: 0x04000012 RID: 18
		private IPublisherManager notificationPublisherManager;

		// Token: 0x04000013 RID: 19
		private readonly AuditingPluginManager auditingPlugins = new AuditingPluginManager();

		// Token: 0x04000014 RID: 20
		private readonly AuditingDAL auditingDAL = new AuditingDAL();

		// Token: 0x04000015 RID: 21
		private bool checkAuditingSetting = true;

		// Token: 0x04000016 RID: 22
		private readonly ISubscriptionManager subscriptionManager;

		// Token: 0x04000017 RID: 23
		private readonly ConcurrentDictionary<string, IEnumerable<IAuditing2>> subscriptionIdToAuditingInstances = new ConcurrentDictionary<string, IEnumerable<IAuditing2>>();
	}
}
