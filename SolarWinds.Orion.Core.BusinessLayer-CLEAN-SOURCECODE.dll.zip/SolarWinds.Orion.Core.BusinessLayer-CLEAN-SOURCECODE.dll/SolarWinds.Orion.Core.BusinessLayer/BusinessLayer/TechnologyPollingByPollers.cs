﻿using System;
using System.Collections.Generic;
using System.Linq;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Models.Interfaces;
using SolarWinds.Orion.Core.Models.Technology;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x0200003E RID: 62
	public class TechnologyPollingByPollers : ITechnologyPolling
	{
		// Token: 0x0600040D RID: 1037 RVA: 0x0001C058 File Offset: 0x0001A258
		public TechnologyPollingByPollers(string technologyID, string technologyPollingID, string displayName, int priority, string[] pollerTypePatterns)
		{
			this.TechnologyID = technologyID;
			this.TechnologyPollingID = technologyPollingID;
			this.DisplayName = displayName;
			this.Priority = priority;
			this.pollerTypePatterns = pollerTypePatterns;
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x0600040E RID: 1038 RVA: 0x0001C090 File Offset: 0x0001A290
		// (set) Token: 0x0600040F RID: 1039 RVA: 0x0001C098 File Offset: 0x0001A298
		public string TechnologyID { get; set; }

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000410 RID: 1040 RVA: 0x0001C0A1 File Offset: 0x0001A2A1
		// (set) Token: 0x06000411 RID: 1041 RVA: 0x0001C0A9 File Offset: 0x0001A2A9
		public string TechnologyPollingID { get; set; }

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000412 RID: 1042 RVA: 0x0001C0B2 File Offset: 0x0001A2B2
		// (set) Token: 0x06000413 RID: 1043 RVA: 0x0001C0BA File Offset: 0x0001A2BA
		public string DisplayName { get; set; }

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000414 RID: 1044 RVA: 0x0001C0C3 File Offset: 0x0001A2C3
		// (set) Token: 0x06000415 RID: 1045 RVA: 0x0001C0CB File Offset: 0x0001A2CB
		public int Priority { get; set; }

		// Token: 0x06000416 RID: 1046 RVA: 0x0001C0D4 File Offset: 0x0001A2D4
		public int[] EnableDisableAssignment(bool enable, int[] netObjectIDs)
		{
			return (from p in this.pollersDAL.UpdatePollersStatus(this.pollerTypePatterns, enable, netObjectIDs)
			select p.NetObjectID).Distinct<int>().ToArray<int>();
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0001C124 File Offset: 0x0001A324
		public int[] EnableDisableAssignment(bool enable)
		{
			return (from p in this.pollersDAL.UpdatePollersStatus(this.pollerTypePatterns, enable, null)
			select p.NetObjectID).Distinct<int>().ToArray<int>();
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x0001C172 File Offset: 0x0001A372
		public IEnumerable<TechnologyPollingAssignment> GetAssignments()
		{
			return this.GetAssignments(null);
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x0001C17B File Offset: 0x0001A37B
		public IEnumerable<TechnologyPollingAssignment> GetAssignments(int[] netObjectIDs)
		{
			return this.pollersDAL.GetPollersAssignmentsGroupedByNetObjectId(this.TechnologyPollingID, this.pollerTypePatterns, netObjectIDs);
		}

		// Token: 0x040000F0 RID: 240
		private PollersDAL pollersDAL = new PollersDAL();

		// Token: 0x040000F1 RID: 241
		protected string[] pollerTypePatterns;
	}
}
