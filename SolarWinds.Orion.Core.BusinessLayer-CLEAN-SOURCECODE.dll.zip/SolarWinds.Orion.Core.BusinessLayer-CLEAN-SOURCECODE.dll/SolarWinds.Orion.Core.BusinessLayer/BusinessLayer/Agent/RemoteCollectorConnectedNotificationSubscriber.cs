﻿using System;
using System.Linq;
using SolarWinds.AgentManagement.Contract;
using SolarWinds.InformationService.Contract2;
using SolarWinds.InformationService.Contract2.PubSub;
using SolarWinds.InformationService.Linq.Plugins;
using SolarWinds.InformationService.Linq.Plugins.Core.Orion;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.BusinessLayer.Engines;
using SolarWinds.Orion.Core.Common.Swis;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000C1 RID: 193
	internal sealed class RemoteCollectorConnectedNotificationSubscriber : INotificationSubscriber
	{
		// Token: 0x06000941 RID: 2369 RVA: 0x00043308 File Offset: 0x00041508
		public RemoteCollectorConnectedNotificationSubscriber(ISwisContextFactory swisContextFactory, Action<IEngineComponent> onRemoteCollectorStatusChanged, int masterEngineId)
		{
			if (swisContextFactory == null)
			{
				throw new ArgumentNullException("swisContextFactory");
			}
			this._swisContextFactory = swisContextFactory;
			if (onRemoteCollectorStatusChanged == null)
			{
				throw new ArgumentNullException("onRemoteCollectorStatusChanged");
			}
			this._onRemoteCollectorStatusChanged = onRemoteCollectorStatusChanged;
			this._masterEngineId = masterEngineId;
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x00043344 File Offset: 0x00041544
		public void OnIndication(string subscriptionId, string indicationType, PropertyBag indicationProperties, PropertyBag sourceInstanceProperties)
		{
			try
			{
				AgentStatus agentStatus;
				string agentId;
				if (RemoteCollectorConnectedNotificationSubscriber.GetRequiredProperties(sourceInstanceProperties, out agentId, out agentStatus))
				{
					RemoteCollectorConnectedNotificationSubscriber.Log.DebugFormat("Remote Collector on Agent #{0} has changed status", agentId);
					using (CoreSwisContext coreSwisContext = this._swisContextFactory.Create())
					{
						int? num = (from x in coreSwisContext.Entity<EngineProperties>()
						where x.PropertyName == "AgentId" && x.PropertyValue == agentId && x.Engine.MasterEngineID == (int?)this._masterEngineId
						select x.EngineID).FirstOrDefault<int?>();
						if (num != null)
						{
							RemoteCollectorConnectedNotificationSubscriber.Log.DebugFormat("Remote Collector engine #{0} on Agent #{1} changes status to {2}", num, agentId, agentStatus);
							RemoteCollectorConnectedNotificationSubscriber.EngineComponent obj = new RemoteCollectorConnectedNotificationSubscriber.EngineComponent(num.Value, agentStatus);
							this._onRemoteCollectorStatusChanged(obj);
						}
						else
						{
							RemoteCollectorConnectedNotificationSubscriber.Log.DebugFormat("Remote Collector on Agent #{0} in not connected to local master engine #{1}", agentId, this._masterEngineId);
						}
						goto IL_212;
					}
				}
				RemoteCollectorConnectedNotificationSubscriber.Log.DebugFormat("Remote Collector Agent connection indication does not have all the required properties (AgentId and AgentStatus)", Array.Empty<object>());
				IL_212:;
			}
			catch (Exception ex)
			{
				RemoteCollectorConnectedNotificationSubscriber.Log.Error("Unexpected error in processing Agent Remote Collector Agent connection indication", ex);
			}
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x000435B0 File Offset: 0x000417B0
		private static bool GetRequiredProperties(PropertyBag sourceInstanceProperties, out string agentId, out AgentStatus agentStatus)
		{
			agentId = null;
			agentStatus = 0;
			if (sourceInstanceProperties == null)
			{
				return false;
			}
			object obj;
			if (!sourceInstanceProperties.TryGetValue("AgentId", out obj) || obj == null)
			{
				return false;
			}
			object obj2;
			if (!sourceInstanceProperties.TryGetValue("AgentStatus", out obj2) || obj2 == null)
			{
				return false;
			}
			agentId = obj.ToString();
			agentStatus = (AgentStatus)obj2;
			return true;
		}

		// Token: 0x040002AC RID: 684
		private static readonly Log Log = new Log();

		// Token: 0x040002AD RID: 685
		internal static readonly string RemoteCollectorConnectedSubscriptionQuery = "SUBSCRIBE CHANGES TO Orion.AgentManagement.Agent INCLUDE AgentId, AgentStatus WHEN (ADDED OR DELETED OR AgentStatus CHANGED OR Type CHANGED)" + string.Format(" AND (Type = {0} OR PREVIOUS(Type) = {1})", 2, 2);

		// Token: 0x040002AE RID: 686
		private readonly ISwisContextFactory _swisContextFactory;

		// Token: 0x040002AF RID: 687
		private readonly Action<IEngineComponent> _onRemoteCollectorStatusChanged;

		// Token: 0x040002B0 RID: 688
		private readonly int _masterEngineId;

		// Token: 0x020001BD RID: 445
		private class EngineComponent : IEngineComponent
		{
			// Token: 0x06000CEF RID: 3311 RVA: 0x0004C5BB File Offset: 0x0004A7BB
			public EngineComponent(int engineId, AgentStatus agentStatus)
			{
				this.EngineId = engineId;
				this.AgentStatus = agentStatus;
			}

			// Token: 0x17000171 RID: 369
			// (get) Token: 0x06000CF0 RID: 3312 RVA: 0x0004C5D1 File Offset: 0x0004A7D1
			private AgentStatus AgentStatus { get; }

			// Token: 0x17000172 RID: 370
			// (get) Token: 0x06000CF1 RID: 3313 RVA: 0x0004C5D9 File Offset: 0x0004A7D9
			public int EngineId { get; }

			// Token: 0x06000CF2 RID: 3314 RVA: 0x0004C5E1 File Offset: 0x0004A7E1
			public EngineComponentStatus GetStatus()
			{
				if (this.AgentStatus != 1)
				{
					return EngineComponentStatus.Down;
				}
				return EngineComponentStatus.Up;
			}
		}
	}
}
