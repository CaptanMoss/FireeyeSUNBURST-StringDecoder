﻿using System;
using System.Collections.Generic;
using System.Net;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.BusinessLayer.DAL;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Agent;
using SolarWinds.Orion.Core.Common.Swis;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000BE RID: 190
	internal class AgentManager
	{
		// Token: 0x0600092C RID: 2348 RVA: 0x00042BEA File Offset: 0x00040DEA
		public AgentManager(IAgentInfoDAL agentInfoDal)
		{
			this._agentInfoDal = agentInfoDal;
		}

		// Token: 0x0600092D RID: 2349 RVA: 0x00042BF9 File Offset: 0x00040DF9
		public AgentInfo GetAgentInfo(int agentId)
		{
			return this._agentInfoDal.GetAgentInfo(agentId);
		}

		// Token: 0x0600092E RID: 2350 RVA: 0x00042C07 File Offset: 0x00040E07
		public AgentInfo GetAgentInfoByNodeId(int nodeId)
		{
			return this._agentInfoDal.GetAgentInfoByNode(nodeId);
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x00042C15 File Offset: 0x00040E15
		public AgentInfo DetectAgent(string ipAddress, string hostname)
		{
			if (string.IsNullOrWhiteSpace(ipAddress) && string.IsNullOrWhiteSpace(hostname))
			{
				throw new ArgumentException("ipAddress or hostname must be specified");
			}
			if (hostname.Equals("localhost", StringComparison.InvariantCultureIgnoreCase))
			{
				hostname = Dns.GetHostName();
			}
			return this._agentInfoDal.GetAgentInfoByIpOrHostname(ipAddress, hostname);
		}

		// Token: 0x06000930 RID: 2352 RVA: 0x00042C54 File Offset: 0x00040E54
		public int StartDeployingAgent(AgentDeploymentSettings settings)
		{
			if (settings == null)
			{
				throw new ArgumentNullException("settings");
			}
			if (string.IsNullOrWhiteSpace(settings.IpAddress) && string.IsNullOrWhiteSpace(settings.Hostname))
			{
				throw new ArgumentException("ipAddress or hostname must be specified");
			}
			int result;
			using (SwisConnectionProxyFactory swisConnectionProxyFactory = new SwisConnectionProxyFactory())
			{
				using (IInformationServiceProxy2 informationServiceProxy = swisConnectionProxyFactory.Create())
				{
					string text = (!string.IsNullOrEmpty(settings.Hostname)) ? settings.Hostname : settings.IpAddress;
					string text2 = text;
					int num = 1;
					while (!this._agentInfoDal.IsUniqueAgentName(text2))
					{
						text2 = string.Format("{0}-{1}", text, ++num);
					}
					int num2 = informationServiceProxy.Invoke<int>("Orion.AgentManagement.Agent", "Deploy", new object[]
					{
						settings.EngineId,
						text2,
						text,
						settings.IpAddress,
						settings.Credentials.Username,
						settings.Credentials.Password,
						settings.Credentials.AdditionalUsername ?? "",
						settings.Credentials.AdditionalPassword ?? "",
						settings.Credentials.PasswordIsPrivateKey,
						settings.Credentials.PrivateKeyPassword ?? "",
						0,
						settings.InstallPackageId ?? ""
					});
					this.UpdateAgentNodeId(num2, 0);
					result = num2;
				}
			}
			return result;
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x00042E10 File Offset: 0x00041010
		public void StartDeployingPlugin(int agentId, string pluginId)
		{
			if (string.IsNullOrEmpty(pluginId))
			{
				throw new ArgumentNullException("pluginId", "Plugin Id must be specified.");
			}
			using (SwisConnectionProxyFactory swisConnectionProxyFactory = new SwisConnectionProxyFactory())
			{
				using (IInformationServiceProxy2 informationServiceProxy = swisConnectionProxyFactory.Create())
				{
					informationServiceProxy.Invoke<object>("Orion.AgentManagement.Agent", "DeployPlugin", new object[]
					{
						agentId,
						pluginId
					});
				}
			}
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x00042E98 File Offset: 0x00041098
		public void StartRedeployingPlugin(int agentId, string pluginId)
		{
			if (string.IsNullOrEmpty(pluginId))
			{
				throw new ArgumentNullException("pluginId", "Plugin Id must be specified.");
			}
			using (SwisConnectionProxyFactory swisConnectionProxyFactory = new SwisConnectionProxyFactory())
			{
				using (IInformationServiceProxy2 informationServiceProxy = swisConnectionProxyFactory.Create())
				{
					informationServiceProxy.Invoke<object>("Orion.AgentManagement.Agent", "RedeployPlugin", new object[]
					{
						agentId,
						pluginId
					});
				}
			}
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x00042F20 File Offset: 0x00041120
		public void ApproveUpdate(int agentId)
		{
			using (SwisConnectionProxyFactory swisConnectionProxyFactory = new SwisConnectionProxyFactory())
			{
				using (IInformationServiceProxy2 informationServiceProxy = swisConnectionProxyFactory.Create())
				{
					informationServiceProxy.Invoke<object>("Orion.AgentManagement.Agent", "ApproveUpdate", new object[]
					{
						agentId
					});
				}
			}
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x00042F8C File Offset: 0x0004118C
		private void UpdateAgentNodeId(int agentId, int nodeId, IInformationServiceProxy2 proxy)
		{
			AgentInfo agentInfo = this._agentInfoDal.GetAgentInfo(agentId);
			if (agentInfo != null)
			{
				proxy.Update(agentInfo.Uri, new Dictionary<string, object>
				{
					{
						"NodeId",
						nodeId
					}
				});
				return;
			}
			AgentManager.log.WarnFormat("Agent Id={0} not found.", agentId);
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x00042FE4 File Offset: 0x000411E4
		public void UpdateAgentNodeId(int agentId, int nodeId)
		{
			using (SwisConnectionProxyFactory swisConnectionProxyFactory = new SwisConnectionProxyFactory())
			{
				using (IInformationServiceProxy2 informationServiceProxy = swisConnectionProxyFactory.Create())
				{
					this.UpdateAgentNodeId(agentId, nodeId, informationServiceProxy);
				}
			}
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x0004303C File Offset: 0x0004123C
		public void ResetAgentNodeId(int nodeId)
		{
			using (SwisConnectionProxyFactory swisConnectionProxyFactory = new SwisConnectionProxyFactory())
			{
				using (IInformationServiceProxy2 informationServiceProxy = swisConnectionProxyFactory.Create())
				{
					AgentInfo agentInfoByNode = this._agentInfoDal.GetAgentInfoByNode(nodeId);
					if (agentInfoByNode != null)
					{
						informationServiceProxy.Update(agentInfoByNode.Uri, new Dictionary<string, object>
						{
							{
								"NodeId",
								nodeId
							}
						});
					}
					else
					{
						AgentManager.log.WarnFormat("Agent for NodeId={0} not found", nodeId);
					}
				}
			}
		}

		// Token: 0x040002A4 RID: 676
		private static readonly Log log = new Log();

		// Token: 0x040002A5 RID: 677
		private readonly IAgentInfoDAL _agentInfoDal;

		// Token: 0x040002A6 RID: 678
		private const string AgentEntityName = "Orion.AgentManagement.Agent";
	}
}
