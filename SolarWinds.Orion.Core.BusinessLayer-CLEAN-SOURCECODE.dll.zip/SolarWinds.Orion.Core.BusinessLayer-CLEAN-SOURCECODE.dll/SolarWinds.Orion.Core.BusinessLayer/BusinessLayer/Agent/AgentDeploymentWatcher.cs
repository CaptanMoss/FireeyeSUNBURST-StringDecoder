﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.BusinessLayer.DAL;
using SolarWinds.Orion.Core.Common.Agent;
using SolarWinds.Orion.Core.Discovery;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000BD RID: 189
	internal class AgentDeploymentWatcher
	{
		// Token: 0x06000919 RID: 2329 RVA: 0x00005195 File Offset: 0x00003395
		private AgentDeploymentWatcher()
		{
		}

		// Token: 0x0600091A RID: 2330 RVA: 0x0004235D File Offset: 0x0004055D
		private AgentDeploymentWatcher(IAgentInfoDAL agentInfoDal)
		{
			this.AgentInfoDal = agentInfoDal;
			this.Items = new Dictionary<int, AgentDeploymentWatcher.CacheItem>();
			this.NotificationSubscriber = new AgentNotificationSubscriber(new Action<int>(this.AgentNotification));
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x0600091B RID: 2331 RVA: 0x0004238E File Offset: 0x0004058E
		// (set) Token: 0x0600091C RID: 2332 RVA: 0x00042396 File Offset: 0x00040596
		private IAgentInfoDAL AgentInfoDal { get; set; }

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x0600091D RID: 2333 RVA: 0x0004239F File Offset: 0x0004059F
		// (set) Token: 0x0600091E RID: 2334 RVA: 0x000423A7 File Offset: 0x000405A7
		private AgentNotificationSubscriber NotificationSubscriber { get; set; }

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x0600091F RID: 2335 RVA: 0x000423B0 File Offset: 0x000405B0
		// (set) Token: 0x06000920 RID: 2336 RVA: 0x000423B8 File Offset: 0x000405B8
		private Dictionary<int, AgentDeploymentWatcher.CacheItem> Items { get; set; }

		// Token: 0x06000921 RID: 2337 RVA: 0x000423C4 File Offset: 0x000405C4
		public static AgentDeploymentWatcher GetInstance(IAgentInfoDAL agentInfoDal)
		{
			if (AgentDeploymentWatcher.instance != null)
			{
				return AgentDeploymentWatcher.instance;
			}
			object obj = AgentDeploymentWatcher.syncLockInstance;
			lock (obj)
			{
				if (AgentDeploymentWatcher.instance == null)
				{
					AgentDeploymentWatcher.instance = new AgentDeploymentWatcher(agentInfoDal);
				}
			}
			return AgentDeploymentWatcher.instance;
		}

		// Token: 0x06000922 RID: 2338 RVA: 0x00042424 File Offset: 0x00040624
		public void Start()
		{
			AgentDeploymentWatcher.log.Debug("AgentDeploymentWatcher.Start");
			object obj = AgentDeploymentWatcher.syncLockItems;
			lock (obj)
			{
				this.CheckWatcher();
			}
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x00042474 File Offset: 0x00040674
		public void AddOrUpdateDeploymentInfo(AgentDeploymentInfo deploymentInfo)
		{
			if (deploymentInfo == null)
			{
				throw new ArgumentNullException("deploymentInfo");
			}
			if (deploymentInfo.Agent == null)
			{
				throw new ArgumentNullException("deploymentInfo.Agent");
			}
			AgentDeploymentWatcher.log.DebugFormat("AddOrUpdateDeploymentInfo started, agentId:{0}, status:{1}", deploymentInfo.Agent.AgentId, deploymentInfo.StatusInfo.Status);
			object obj = AgentDeploymentWatcher.syncLockItems;
			lock (obj)
			{
				AgentDeploymentWatcher.CacheItem cacheItem;
				if (this.Items.TryGetValue(deploymentInfo.Agent.AgentId, out cacheItem))
				{
					AgentDeploymentWatcher.log.Debug("AddOrUpdateDeploymentInfo - item found in cache, updating");
					cacheItem.DeploymentInfo = deploymentInfo;
				}
				else
				{
					AgentDeploymentWatcher.log.Debug("AddOrUpdateDeploymentInfo - item not found in cache, creating new item");
					cacheItem = new AgentDeploymentWatcher.CacheItem
					{
						DeploymentInfo = deploymentInfo
					};
					cacheItem.LastChecked = DateTime.Now;
					this.Items[deploymentInfo.Agent.AgentId] = cacheItem;
				}
				cacheItem.LastUpdated = DateTime.Now;
				cacheItem.RefreshNeeded = false;
				this.CheckWatcher();
			}
		}

		// Token: 0x06000924 RID: 2340 RVA: 0x00042588 File Offset: 0x00040788
		public void SetOnFinishedCallback(int agentId, Action<AgentDeploymentStatus> onFinished)
		{
			AgentDeploymentWatcher.log.DebugFormat("SetOnFinishedCallback entered, agentId:{0}", agentId);
			object obj = AgentDeploymentWatcher.syncLockItems;
			lock (obj)
			{
				AgentDeploymentWatcher.CacheItem cacheItem;
				if (this.Items.TryGetValue(agentId, out cacheItem))
				{
					cacheItem.OnFinishedCallback = onFinished;
				}
			}
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x000425F0 File Offset: 0x000407F0
		public AgentDeploymentInfo GetAgentDeploymentInfo(int agentId)
		{
			AgentDeploymentWatcher.log.DebugFormat("GetAgentDeploymentInfo started, agentId:{0}", agentId);
			AgentDeploymentInfo agentDeploymentInfo = null;
			object obj = AgentDeploymentWatcher.syncLockItems;
			lock (obj)
			{
				AgentDeploymentWatcher.CacheItem cacheItem;
				if (this.Items.TryGetValue(agentId, out cacheItem))
				{
					agentDeploymentInfo = cacheItem.DeploymentInfo;
					cacheItem.LastChecked = DateTime.Now;
					AgentDeploymentWatcher.log.DebugFormat("GetAgentDeploymentInfo - item found in cache, agentId:{0}, status:{1}", agentId, agentDeploymentInfo.StatusInfo.Status);
				}
			}
			if (agentDeploymentInfo == null)
			{
				agentDeploymentInfo = this.LoadAgentDeploymentInfo(agentId);
				AgentDeploymentWatcher.log.DebugFormat("GetAgentDeploymentInfo - item not found in cache, loading from db, agentId:{0}, status:{1}", agentId, agentDeploymentInfo.StatusInfo.Status);
			}
			return agentDeploymentInfo;
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x000426B8 File Offset: 0x000408B8
		private void CheckWatcher()
		{
			AgentDeploymentWatcher.log.Debug("Checking Watcher status");
			if (!this.NotificationSubscriber.IsSubscribed())
			{
				AgentDeploymentWatcher.log.Debug("Starting NotificationSubscriber");
				this.NotificationSubscriber.Subscribe();
			}
			if (this.watcherTimer == null)
			{
				AgentDeploymentWatcher.log.Debug("Starting Watcher Timer");
				this.watcherTimer = new Timer(new TimerCallback(this.CheckItems), null, TimeSpan.FromSeconds(5.0), TimeSpan.FromSeconds(5.0));
			}
		}

		// Token: 0x06000927 RID: 2343 RVA: 0x00042746 File Offset: 0x00040946
		private void StopWatcher()
		{
			if (this.watcherTimer != null)
			{
				this.watcherTimer.Dispose();
			}
			this.watcherTimer = null;
			if (this.NotificationSubscriber != null)
			{
				this.NotificationSubscriber.Unsubscribe();
			}
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x00042778 File Offset: 0x00040978
		private void CheckItems(object state)
		{
			AgentDeploymentWatcher.log.Debug("CheckItems started");
			DateTime ExpireTime = DateTime.Now.Subtract(TimeSpan.FromSeconds(120.0));
			new List<Action<AgentDeploymentStatus>>();
			object obj = AgentDeploymentWatcher.syncLockItems;
			IEnumerable<AgentDeploymentWatcher.CacheItem> enumerable;
			IEnumerable<int> enumerable2;
			lock (obj)
			{
				AgentDeploymentWatcher.log.Debug("CheckItems - looking for items to remove");
				enumerable = (from item in this.Items
				where item.Value.DeploymentInfo.StatusInfo.Status == 1 || item.Value.DeploymentInfo.StatusInfo.Status == 2 || item.Value.LastChecked < ExpireTime
				select item.Value).ToArray<AgentDeploymentWatcher.CacheItem>();
				foreach (AgentDeploymentWatcher.CacheItem cacheItem in enumerable)
				{
					AgentDeploymentWatcher.log.DebugFormat("CheckItems - removing item, AgentId:{0}", cacheItem.DeploymentInfo.Agent.AgentId);
					this.Items.Remove(cacheItem.DeploymentInfo.Agent.AgentId);
				}
				if (this.Items.Count == 0)
				{
					AgentDeploymentWatcher.log.Debug("CheckItems - No remaining items in the cache, stopping Watcher");
					this.StopWatcher();
				}
				AgentDeploymentWatcher.log.Debug("CheckItems - looking for items to refresh");
				enumerable2 = (from item in this.Items
				where item.Value.RefreshNeeded || item.Value.LastUpdated < ExpireTime
				select item.Key).ToArray<int>();
			}
			foreach (int num in enumerable2)
			{
				AgentDeploymentWatcher.log.DebugFormat("CheckItems - refreshing item AgentId:{0}", num);
				AgentDeploymentInfo agentDeploymentInfo = this.LoadAgentDeploymentInfo(num);
				obj = AgentDeploymentWatcher.syncLockItems;
				lock (obj)
				{
					AgentDeploymentWatcher.CacheItem cacheItem2;
					if (this.Items.TryGetValue(agentDeploymentInfo.Agent.AgentId, out cacheItem2))
					{
						AgentDeploymentWatcher.log.DebugFormat("CheckItems - updating item AgentId:{0}, Status:{1}", num, agentDeploymentInfo.StatusInfo.Status);
						cacheItem2.DeploymentInfo = agentDeploymentInfo;
						cacheItem2.LastUpdated = DateTime.Now;
						cacheItem2.RefreshNeeded = false;
					}
					else
					{
						AgentDeploymentWatcher.log.Debug("CheckItems - item not found in the cache");
					}
				}
			}
			foreach (AgentDeploymentWatcher.CacheItem cacheItem3 in enumerable)
			{
				if (cacheItem3.OnFinishedCallback != null && (cacheItem3.DeploymentInfo.StatusInfo.Status == 1 || cacheItem3.DeploymentInfo.StatusInfo.Status == 2))
				{
					cacheItem3.OnFinishedCallback(cacheItem3.DeploymentInfo.StatusInfo.Status);
				}
			}
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x00042AE8 File Offset: 0x00040CE8
		private void AgentNotification(int agentId)
		{
			AgentDeploymentWatcher.log.DebugFormat("AgentNotification started, AgentId:{0}", agentId);
			object obj = AgentDeploymentWatcher.syncLockItems;
			lock (obj)
			{
				AgentDeploymentWatcher.CacheItem cacheItem;
				if (this.Items.TryGetValue(agentId, out cacheItem))
				{
					AgentDeploymentWatcher.log.Debug("AgentNotification - item found, set refresh flag.");
					cacheItem.RefreshNeeded = true;
				}
				else
				{
					AgentDeploymentWatcher.log.Debug("AgentNotification - item not found");
				}
			}
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x00042B70 File Offset: 0x00040D70
		private AgentDeploymentInfo LoadAgentDeploymentInfo(int agentId)
		{
			AgentInfo agentInfo = new AgentManager(this.AgentInfoDal).GetAgentInfo(agentId);
			if (agentInfo != null)
			{
				string[] agentDiscoveryPluginIds = DiscoveryHelper.GetAgentDiscoveryPluginIds();
				return AgentDeploymentInfo.Calculate(agentInfo, agentDiscoveryPluginIds, null);
			}
			return new AgentDeploymentInfo
			{
				Agent = new AgentInfo
				{
					AgentId = agentId
				},
				StatusInfo = new AgentDeploymentStatusInfo(agentId, 2, "Agent not found.")
			};
		}

		// Token: 0x0400029A RID: 666
		private static readonly Log log = new Log();

		// Token: 0x0400029B RID: 667
		private const int MaxItemAge = 120;

		// Token: 0x0400029C RID: 668
		private const int CheckPeriod = 5;

		// Token: 0x0400029F RID: 671
		private Timer watcherTimer;

		// Token: 0x040002A1 RID: 673
		private static readonly object syncLockItems = new object();

		// Token: 0x040002A2 RID: 674
		private static AgentDeploymentWatcher instance;

		// Token: 0x040002A3 RID: 675
		private static readonly object syncLockInstance = new object();

		// Token: 0x020001BA RID: 442
		private class CacheItem
		{
			// Token: 0x1700016C RID: 364
			// (get) Token: 0x06000CDD RID: 3293 RVA: 0x0004C4C7 File Offset: 0x0004A6C7
			// (set) Token: 0x06000CDE RID: 3294 RVA: 0x0004C4CF File Offset: 0x0004A6CF
			public AgentDeploymentInfo DeploymentInfo { get; set; }

			// Token: 0x1700016D RID: 365
			// (get) Token: 0x06000CDF RID: 3295 RVA: 0x0004C4D8 File Offset: 0x0004A6D8
			// (set) Token: 0x06000CE0 RID: 3296 RVA: 0x0004C4E0 File Offset: 0x0004A6E0
			public DateTime LastUpdated { get; set; }

			// Token: 0x1700016E RID: 366
			// (get) Token: 0x06000CE1 RID: 3297 RVA: 0x0004C4E9 File Offset: 0x0004A6E9
			// (set) Token: 0x06000CE2 RID: 3298 RVA: 0x0004C4F1 File Offset: 0x0004A6F1
			public DateTime LastChecked { get; set; }

			// Token: 0x1700016F RID: 367
			// (get) Token: 0x06000CE3 RID: 3299 RVA: 0x0004C4FA File Offset: 0x0004A6FA
			// (set) Token: 0x06000CE4 RID: 3300 RVA: 0x0004C502 File Offset: 0x0004A702
			public bool RefreshNeeded { get; set; }

			// Token: 0x17000170 RID: 368
			// (get) Token: 0x06000CE5 RID: 3301 RVA: 0x0004C50B File Offset: 0x0004A70B
			// (set) Token: 0x06000CE6 RID: 3302 RVA: 0x0004C513 File Offset: 0x0004A713
			public Action<AgentDeploymentStatus> OnFinishedCallback { get; set; }
		}
	}
}
