﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SolarWinds.Logging;
using SolarWinds.Orion.PubSub;
using SolarWinds.Orion.Swis.PubSub.InformationService;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000BF RID: 191
	internal class AgentNotificationSubscriber : ISubscriber
	{
		// Token: 0x06000938 RID: 2360 RVA: 0x000430E0 File Offset: 0x000412E0
		public AgentNotificationSubscriber(Action<int> onIndication) : this(onIndication, SubscriptionManager.Instance)
		{
		}

		// Token: 0x06000939 RID: 2361 RVA: 0x000430F0 File Offset: 0x000412F0
		public AgentNotificationSubscriber(Action<int> onIndication, ISubscriptionManager subscriptionManager)
		{
			this.onIndication = onIndication;
			this._subscriptionManager = subscriptionManager;
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x00043170 File Offset: 0x00041370
		public void Subscribe()
		{
			this.Unsubscribe();
			foreach (Tuple<string, string> tuple in this._subscriptionQueriesDescriptionPairs)
			{
				SubscriptionId subscriptionId;
				subscriptionId..ctor("Core", typeof(AgentNotificationSubscriber).FullName + "." + tuple.Item2, 0);
				SubscriberConfiguration subscriberConfiguration = new SubscriberConfiguration
				{
					SubscriptionQuery = tuple.Item1
				};
				this.subscriptionIds.Add(this._subscriptionManager.Subscribe(subscriptionId, this, subscriberConfiguration).Id);
			}
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x000431FC File Offset: 0x000413FC
		public void Unsubscribe()
		{
			while (this.subscriptionIds.Count > 0)
			{
				SubscriptionId subscriptionId = this.subscriptionIds[0];
				try
				{
					this._subscriptionManager.Unsubscribe(subscriptionId);
				}
				catch (Exception ex)
				{
					AgentNotificationSubscriber.log.ErrorFormat("Error unsubscribing 'agent change' subscription '{0}'. {1}", subscriptionId, ex);
				}
				this.subscriptionIds.RemoveAt(0);
			}
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x0004326C File Offset: 0x0004146C
		public bool IsSubscribed()
		{
			return this.subscriptionIds.Count > 0;
		}

		// Token: 0x0600093D RID: 2365 RVA: 0x0004327C File Offset: 0x0004147C
		public Task OnNotificationAsync(Notification notification)
		{
			if (!this.subscriptionIds.Contains(notification.SubscriptionId))
			{
				return Task.CompletedTask;
			}
			try
			{
				int num = Convert.ToInt32(notification.SourceInstanceProperties["AgentId"]);
				if (this.onIndication != null && num != 0)
				{
					this.onIndication(num);
				}
			}
			catch (Exception ex)
			{
				AgentNotificationSubscriber.log.ErrorFormat("Error processing agent notification. {0}", ex);
				throw;
			}
			return Task.CompletedTask;
		}

		// Token: 0x040002A7 RID: 679
		private static readonly Log log = new Log();

		// Token: 0x040002A8 RID: 680
		private ISubscriptionManager _subscriptionManager;

		// Token: 0x040002A9 RID: 681
		private Action<int> onIndication;

		// Token: 0x040002AA RID: 682
		private List<SubscriptionId> subscriptionIds = new List<SubscriptionId>();

		// Token: 0x040002AB RID: 683
		private readonly Tuple<string, string>[] _subscriptionQueriesDescriptionPairs = new Tuple<string, string>[]
		{
			new Tuple<string, string>("SUBSCRIBE CHANGES TO Orion.AgentManagement.Agent INCLUDE AgentId WHEN AgentStatus CHANGES OR ConnectionStatus CHANGES", "AgentStatusOrConnectionChange"),
			new Tuple<string, string>("SUBSCRIBE CHANGES TO Orion.AgentManagement.Agent INCLUDE AgentId WHEN ADDED", "AgentAdded"),
			new Tuple<string, string>("SUBSCRIBE CHANGES TO Orion.AgentManagement.AgentPlugin INCLUDE AgentId WHEN Status CHANGES", "AgentPluginStatusChanged"),
			new Tuple<string, string>("SUBSCRIBE CHANGES TO Orion.AgentManagement.AgentPlugin INCLUDE AgentId WHEN ADDED", "AgentPluginAdded")
		};
	}
}
