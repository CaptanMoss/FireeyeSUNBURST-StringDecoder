﻿using System;
using System.Collections.Generic;
using SolarWinds.Orion.Core.BusinessLayer.Engines;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.JobEngine;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000C3 RID: 195
	internal class RemoteCollectorEngineInitiator : IEngineInitiator
	{
		// Token: 0x0600094A RID: 2378 RVA: 0x000436A4 File Offset: 0x000418A4
		public RemoteCollectorEngineInitiator(int engineId, string engineName, bool interfaceAvailable, IEngineDAL engineDal, IThrottlingStatusProvider throttlingStatusProvider, IEngineComponent engineComponent)
		{
			if (engineName == null)
			{
				throw new ArgumentNullException("engineName");
			}
			if (engineDal == null)
			{
				throw new ArgumentNullException("engineDal");
			}
			this._engineDal = engineDal;
			if (throttlingStatusProvider == null)
			{
				throw new ArgumentNullException("throttlingStatusProvider");
			}
			this._throttlingStatusProvider = throttlingStatusProvider;
			if (engineComponent == null)
			{
				throw new ArgumentNullException("engineComponent");
			}
			this._engineComponent = engineComponent;
			this.EngineId = engineId;
			this.ServerName = engineName.ToUpperInvariant();
			this._interfaceAvailable = interfaceAvailable;
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x0600094B RID: 2379 RVA: 0x00043724 File Offset: 0x00041924
		public int EngineId { get; }

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x0600094C RID: 2380 RVA: 0x0004372C File Offset: 0x0004192C
		public string ServerName { get; }

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600094D RID: 2381 RVA: 0x00043734 File Offset: 0x00041934
		public EngineComponentStatus ComponentStatus
		{
			get
			{
				return this._engineComponent.GetStatus();
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x0600094E RID: 2382 RVA: 0x00043741 File Offset: 0x00041941
		public bool AllowKeepAlive
		{
			get
			{
				return this.ComponentStatus == EngineComponentStatus.Up;
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x0600094F RID: 2383 RVA: 0x00043741 File Offset: 0x00041941
		public bool AllowPollingCompletion
		{
			get
			{
				return this.ComponentStatus == EngineComponentStatus.Up;
			}
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x0004374C File Offset: 0x0004194C
		public void InitializeEngine()
		{
			this._engineDal.UpdateEngineInfo(this.EngineId, RemoteCollectorEngineInitiator.DefaultValues, false, this._interfaceAvailable, this.AllowKeepAlive);
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x00043774 File Offset: 0x00041974
		public void UpdateInfo(bool updateJobEngineThrottleInfo)
		{
			float num = (this.AllowPollingCompletion && updateJobEngineThrottleInfo) ? this._throttlingStatusProvider.GetPollingCompletion() : 0f;
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					"PollingCompletion",
					num
				}
			};
			this._engineDal.UpdateEngineInfo(this.EngineId, dictionary, true, this._interfaceAvailable, this.AllowKeepAlive);
		}

		// Token: 0x040002B4 RID: 692
		private readonly bool _interfaceAvailable;

		// Token: 0x040002B5 RID: 693
		private readonly IEngineDAL _engineDal;

		// Token: 0x040002B6 RID: 694
		private readonly IThrottlingStatusProvider _throttlingStatusProvider;

		// Token: 0x040002B7 RID: 695
		private readonly IEngineComponent _engineComponent;

		// Token: 0x040002B8 RID: 696
		private const float DefaultPollingCompletion = 0f;

		// Token: 0x040002B9 RID: 697
		private static readonly Dictionary<string, object> DefaultValues = new Dictionary<string, object>
		{
			{
				"EngineVersion",
				RegistrySettings.GetVersionDisplayString()
			}
		};
	}
}
