﻿using System;
using System.Linq;
using System.Runtime.CompilerServices;
using SolarWinds.AgentManagement.Contract;
using SolarWinds.Orion.Core.BusinessLayer.Engines;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000C2 RID: 194
	internal class RemoteCollectorEngineComponent : IEngineComponent
	{
		// Token: 0x06000945 RID: 2373 RVA: 0x00043632 File Offset: 0x00041832
		public RemoteCollectorEngineComponent(int engineId, IRemoteCollectorAgentStatusProvider agentStatusProvider)
		{
			if (agentStatusProvider == null)
			{
				throw new ArgumentNullException("agentStatusProvider");
			}
			this._agentStatusProvider = agentStatusProvider;
			this.EngineId = engineId;
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000946 RID: 2374 RVA: 0x00043657 File Offset: 0x00041857
		public int EngineId { get; }

		// Token: 0x06000947 RID: 2375 RVA: 0x0004365F File Offset: 0x0004185F
		public EngineComponentStatus GetStatus()
		{
			return RemoteCollectorEngineComponent.ToEngineStatus(this._agentStatusProvider.GetStatus(this.EngineId));
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x00043677 File Offset: 0x00041877
		private static EngineComponentStatus ToEngineStatus(AgentStatus agentStatus)
		{
			if (!RemoteCollectorEngineComponent.EngineUpStatuses.Contains(agentStatus))
			{
				return EngineComponentStatus.Down;
			}
			return EngineComponentStatus.Up;
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x00043689 File Offset: 0x00041889
		// Note: this type is marked as 'beforefieldinit'.
		static RemoteCollectorEngineComponent()
		{
			AgentStatus[] array = new AgentStatus[9];
			RuntimeHelpers.InitializeArray(array, fieldof(<PrivateImplementationDetails>.AEC16ABA6566EC8C564489327314ABDEDB0431AB).FieldHandle);
			RemoteCollectorEngineComponent.EngineUpStatuses = array;
		}

		// Token: 0x040002B1 RID: 689
		private static readonly AgentStatus[] EngineUpStatuses;

		// Token: 0x040002B2 RID: 690
		private readonly IRemoteCollectorAgentStatusProvider _agentStatusProvider;
	}
}
