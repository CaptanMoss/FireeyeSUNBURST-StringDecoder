﻿using System;
using SolarWinds.AgentManagement.Contract;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000C0 RID: 192
	public interface IRemoteCollectorAgentStatusProvider
	{
		// Token: 0x0600093F RID: 2367
		AgentStatus GetStatus(int engineId);

		// Token: 0x06000940 RID: 2368
		void InvalidateCache();
	}
}
