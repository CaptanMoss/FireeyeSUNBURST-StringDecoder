﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using SolarWinds.AgentManagement.Contract;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Internals;
using SolarWinds.Orion.Core.Common.Swis;

namespace SolarWinds.Orion.Core.BusinessLayer.Agent
{
	// Token: 0x020000C4 RID: 196
	internal class RemoteCollectorStatusProvider : IRemoteCollectorAgentStatusProvider
	{
		// Token: 0x06000953 RID: 2387 RVA: 0x000437F4 File Offset: 0x000419F4
		public RemoteCollectorStatusProvider(ISwisConnectionProxyCreator swisProxyCreator, int masterEngineId, int cacheExpiration) : this(cacheExpiration, () => RemoteCollectorStatusProvider.GetCurrentStatuses(swisProxyCreator, masterEngineId), () => DateTime.UtcNow)
		{
			if (swisProxyCreator == null)
			{
				throw new ArgumentNullException("swisProxyCreator");
			}
		}

		// Token: 0x06000954 RID: 2388 RVA: 0x0004385A File Offset: 0x00041A5A
		internal RemoteCollectorStatusProvider(int cacheExpiration, Func<IDictionary<int, AgentStatus>> refreshFunc, Func<DateTime> currentTimeFunc)
		{
			if (currentTimeFunc == null)
			{
				throw new ArgumentNullException("currentTimeFunc");
			}
			this._statusCache = new CacheWithExpiration<IDictionary<int, AgentStatus>>(cacheExpiration, refreshFunc, currentTimeFunc);
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x00043880 File Offset: 0x00041A80
		public AgentStatus GetStatus(int engineId)
		{
			AgentStatus result;
			if (!this._statusCache.Get().TryGetValue(engineId, out result))
			{
				return 0;
			}
			return result;
		}

		// Token: 0x06000956 RID: 2390 RVA: 0x000438A5 File Offset: 0x00041AA5
		public void InvalidateCache()
		{
			this._statusCache.Invalidate();
		}

		// Token: 0x06000957 RID: 2391 RVA: 0x000438B4 File Offset: 0x00041AB4
		private static IDictionary<int, AgentStatus> GetCurrentStatuses(ISwisConnectionProxyCreator swisProxyCreator, int masterEngineId)
		{
			return RemoteCollectorStatusProvider.GetStatuses(swisProxyCreator, masterEngineId).ToDictionary((KeyValuePair<int, AgentStatus> i) => i.Key, (KeyValuePair<int, AgentStatus> i) => i.Value);
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x0004390B File Offset: 0x00041B0B
		internal static IEnumerable<KeyValuePair<int, AgentStatus>> GetStatuses(ISwisConnectionProxyCreator swisProxyCreator, int masterEngineId)
		{
			using (IInformationServiceProxy2 proxy = swisProxyCreator.Create())
			{
				DataTable dataTable = proxy.Query("SELECT e.EngineID, a.AgentStatus FROM Orion.EngineProperties (nolock=true) p\r\nINNER JOIN Orion.AgentManagement.Agent (nolock=true) a\r\nON p.PropertyName='AgentId' AND a.AgentId=p.PropertyValue\r\nINNER JOIN Orion.Engines (nolock=true) e\r\nON e.EngineID=p.EngineID AND e.MasterEngineID=@MasterEngineId", new Dictionary<string, object>
				{
					{
						"MasterEngineId",
						masterEngineId
					}
				});
				foreach (object obj in dataTable.Rows)
				{
					DataRow dataRow = (DataRow)obj;
					yield return new KeyValuePair<int, AgentStatus>((int)dataRow[0], (AgentStatus)dataRow[1]);
				}
				IEnumerator enumerator = null;
			}
			IInformationServiceProxy2 proxy = null;
			yield break;
			yield break;
		}

		// Token: 0x040002BC RID: 700
		private readonly CacheWithExpiration<IDictionary<int, AgentStatus>> _statusCache;
	}
}
