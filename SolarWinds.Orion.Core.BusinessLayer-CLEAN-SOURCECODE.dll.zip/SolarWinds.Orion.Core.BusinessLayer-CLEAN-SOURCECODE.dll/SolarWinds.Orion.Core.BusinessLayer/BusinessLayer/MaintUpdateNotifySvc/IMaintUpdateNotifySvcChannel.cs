﻿using System;
using System.CodeDom.Compiler;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x02000064 RID: 100
	[GeneratedCode("System.ServiceModel", "4.0.0.0")]
	public interface IMaintUpdateNotifySvcChannel : IMaintUpdateNotifySvc, IClientChannel, IContextChannel, IChannel, ICommunicationObject, IExtensibleObject<IContextChannel>, IDisposable
	{
	}
}
