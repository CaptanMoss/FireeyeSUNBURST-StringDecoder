﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x02000060 RID: 96
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public class VersionInfo : INotifyPropertyChanged
	{
		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x06000558 RID: 1368 RVA: 0x00021AE8 File Offset: 0x0001FCE8
		// (set) Token: 0x06000559 RID: 1369 RVA: 0x00021AF0 File Offset: 0x0001FCF0
		[XmlElement(Order = 0)]
		public string ModuleName
		{
			get
			{
				return this.moduleNameField;
			}
			set
			{
				this.moduleNameField = value;
				this.RaisePropertyChanged("ModuleName");
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x0600055A RID: 1370 RVA: 0x00021B04 File Offset: 0x0001FD04
		// (set) Token: 0x0600055B RID: 1371 RVA: 0x00021B0C File Offset: 0x0001FD0C
		[XmlElement(Order = 1)]
		public DateTime DateReleased
		{
			get
			{
				return this.dateReleasedField;
			}
			set
			{
				this.dateReleasedField = value;
				this.RaisePropertyChanged("DateReleased");
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x0600055C RID: 1372 RVA: 0x00021B20 File Offset: 0x0001FD20
		// (set) Token: 0x0600055D RID: 1373 RVA: 0x00021B28 File Offset: 0x0001FD28
		[XmlElement(Order = 2)]
		public string ProductTag
		{
			get
			{
				return this.productTagField;
			}
			set
			{
				this.productTagField = value;
				this.RaisePropertyChanged("ProductTag");
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x0600055E RID: 1374 RVA: 0x00021B3C File Offset: 0x0001FD3C
		// (set) Token: 0x0600055F RID: 1375 RVA: 0x00021B44 File Offset: 0x0001FD44
		[XmlElement(Order = 3)]
		public string Link
		{
			get
			{
				return this.linkField;
			}
			set
			{
				this.linkField = value;
				this.RaisePropertyChanged("Link");
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x06000560 RID: 1376 RVA: 0x00021B58 File Offset: 0x0001FD58
		// (set) Token: 0x06000561 RID: 1377 RVA: 0x00021B60 File Offset: 0x0001FD60
		[XmlElement(Order = 4)]
		public string ReleaseNotes
		{
			get
			{
				return this.releaseNotesField;
			}
			set
			{
				this.releaseNotesField = value;
				this.RaisePropertyChanged("ReleaseNotes");
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000562 RID: 1378 RVA: 0x00021B74 File Offset: 0x0001FD74
		// (set) Token: 0x06000563 RID: 1379 RVA: 0x00021B7C File Offset: 0x0001FD7C
		[XmlElement(Order = 5)]
		public UpdateMessage Message
		{
			get
			{
				return this.messageField;
			}
			set
			{
				this.messageField = value;
				this.RaisePropertyChanged("Message");
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x06000564 RID: 1380 RVA: 0x00021B90 File Offset: 0x0001FD90
		// (set) Token: 0x06000565 RID: 1381 RVA: 0x00021B98 File Offset: 0x0001FD98
		[XmlElement(Order = 6)]
		public ModuleStatusType ModuleStatus
		{
			get
			{
				return this.moduleStatusField;
			}
			set
			{
				this.moduleStatusField = value;
				this.RaisePropertyChanged("ModuleStatus");
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x06000566 RID: 1382 RVA: 0x00021BAC File Offset: 0x0001FDAC
		// (set) Token: 0x06000567 RID: 1383 RVA: 0x00021BB4 File Offset: 0x0001FDB4
		[XmlElement(Order = 7)]
		public string Version
		{
			get
			{
				return this.versionField;
			}
			set
			{
				this.versionField = value;
				this.RaisePropertyChanged("Version");
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x06000568 RID: 1384 RVA: 0x00021BC8 File Offset: 0x0001FDC8
		// (set) Token: 0x06000569 RID: 1385 RVA: 0x00021BD0 File Offset: 0x0001FDD0
		[XmlElement(Order = 8)]
		public string Hotfix
		{
			get
			{
				return this.hotfixField;
			}
			set
			{
				this.hotfixField = value;
				this.RaisePropertyChanged("Hotfix");
			}
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x0600056A RID: 1386 RVA: 0x00021BE4 File Offset: 0x0001FDE4
		// (remove) Token: 0x0600056B RID: 1387 RVA: 0x00021C1C File Offset: 0x0001FE1C
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x0600056C RID: 1388 RVA: 0x00021C54 File Offset: 0x0001FE54
		protected void RaisePropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000188 RID: 392
		private string moduleNameField;

		// Token: 0x04000189 RID: 393
		private DateTime dateReleasedField;

		// Token: 0x0400018A RID: 394
		private string productTagField;

		// Token: 0x0400018B RID: 395
		private string linkField;

		// Token: 0x0400018C RID: 396
		private string releaseNotesField;

		// Token: 0x0400018D RID: 397
		private UpdateMessage messageField;

		// Token: 0x0400018E RID: 398
		private ModuleStatusType moduleStatusField;

		// Token: 0x0400018F RID: 399
		private string versionField;

		// Token: 0x04000190 RID: 400
		private string hotfixField;
	}
}
