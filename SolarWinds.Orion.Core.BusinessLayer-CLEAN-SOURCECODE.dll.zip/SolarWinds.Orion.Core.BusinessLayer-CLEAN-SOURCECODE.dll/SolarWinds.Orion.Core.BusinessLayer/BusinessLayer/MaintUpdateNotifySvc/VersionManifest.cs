﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x02000062 RID: 98
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public class VersionManifest : INotifyPropertyChanged
	{
		// Token: 0x170000DC RID: 220
		// (get) Token: 0x0600056E RID: 1390 RVA: 0x00021C78 File Offset: 0x0001FE78
		// (set) Token: 0x0600056F RID: 1391 RVA: 0x00021C80 File Offset: 0x0001FE80
		[XmlArray(Order = 0)]
		public VersionInfo[] CurrentVersions
		{
			get
			{
				return this.currentVersionsField;
			}
			set
			{
				this.currentVersionsField = value;
				this.RaisePropertyChanged("CurrentVersions");
			}
		}

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000570 RID: 1392 RVA: 0x00021C94 File Offset: 0x0001FE94
		// (remove) Token: 0x06000571 RID: 1393 RVA: 0x00021CCC File Offset: 0x0001FECC
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000572 RID: 1394 RVA: 0x00021D04 File Offset: 0x0001FF04
		protected void RaisePropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000196 RID: 406
		private VersionInfo[] currentVersionsField;
	}
}
