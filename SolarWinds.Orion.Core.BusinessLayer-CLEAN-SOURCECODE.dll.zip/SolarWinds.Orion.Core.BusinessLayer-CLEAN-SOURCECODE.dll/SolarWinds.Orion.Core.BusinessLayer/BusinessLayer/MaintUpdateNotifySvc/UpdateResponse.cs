﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x02000063 RID: 99
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public class UpdateResponse : INotifyPropertyChanged
	{
		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000574 RID: 1396 RVA: 0x00021D28 File Offset: 0x0001FF28
		// (set) Token: 0x06000575 RID: 1397 RVA: 0x00021D30 File Offset: 0x0001FF30
		[XmlElement(Order = 0)]
		public string ContractVersion
		{
			get
			{
				return this.contractVersionField;
			}
			set
			{
				this.contractVersionField = value;
				this.RaisePropertyChanged("ContractVersion");
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000576 RID: 1398 RVA: 0x00021D44 File Offset: 0x0001FF44
		// (set) Token: 0x06000577 RID: 1399 RVA: 0x00021D4C File Offset: 0x0001FF4C
		[XmlElement(Order = 1)]
		public bool Success
		{
			get
			{
				return this.successField;
			}
			set
			{
				this.successField = value;
				this.RaisePropertyChanged("Success");
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x06000578 RID: 1400 RVA: 0x00021D60 File Offset: 0x0001FF60
		// (set) Token: 0x06000579 RID: 1401 RVA: 0x00021D68 File Offset: 0x0001FF68
		[XmlElement(Order = 2)]
		public VersionManifest Manifest
		{
			get
			{
				return this.manifestField;
			}
			set
			{
				this.manifestField = value;
				this.RaisePropertyChanged("Manifest");
			}
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x0600057A RID: 1402 RVA: 0x00021D7C File Offset: 0x0001FF7C
		// (remove) Token: 0x0600057B RID: 1403 RVA: 0x00021DB4 File Offset: 0x0001FFB4
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x0600057C RID: 1404 RVA: 0x00021DEC File Offset: 0x0001FFEC
		protected void RaisePropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000198 RID: 408
		private string contractVersionField;

		// Token: 0x04000199 RID: 409
		private bool successField;

		// Token: 0x0400019A RID: 410
		private VersionManifest manifestField;
	}
}
