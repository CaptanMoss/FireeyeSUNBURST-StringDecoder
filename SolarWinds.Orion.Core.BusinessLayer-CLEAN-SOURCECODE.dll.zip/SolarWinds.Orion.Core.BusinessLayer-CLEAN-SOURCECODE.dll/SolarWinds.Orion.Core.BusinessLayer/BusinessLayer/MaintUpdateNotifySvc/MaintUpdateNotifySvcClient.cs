﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading.Tasks;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x02000065 RID: 101
	[DebuggerStepThrough]
	[GeneratedCode("System.ServiceModel", "4.0.0.0")]
	public class MaintUpdateNotifySvcClient : ClientBase<IMaintUpdateNotifySvc>, IMaintUpdateNotifySvc
	{
		// Token: 0x0600057E RID: 1406 RVA: 0x00021E10 File Offset: 0x00020010
		public MaintUpdateNotifySvcClient()
		{
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00021E18 File Offset: 0x00020018
		public MaintUpdateNotifySvcClient(string endpointConfigurationName) : base(endpointConfigurationName)
		{
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x00021E21 File Offset: 0x00020021
		public MaintUpdateNotifySvcClient(string endpointConfigurationName, string remoteAddress) : base(endpointConfigurationName, remoteAddress)
		{
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x00021E2B File Offset: 0x0002002B
		public MaintUpdateNotifySvcClient(string endpointConfigurationName, EndpointAddress remoteAddress) : base(endpointConfigurationName, remoteAddress)
		{
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x00021E35 File Offset: 0x00020035
		public MaintUpdateNotifySvcClient(Binding binding, EndpointAddress remoteAddress) : base(binding, remoteAddress)
		{
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x00021E3F File Offset: 0x0002003F
		public UpdateResponse GetData(UpdateRequest request)
		{
			return base.Channel.GetData(request);
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x00021E4D File Offset: 0x0002004D
		public Task<UpdateResponse> GetDataAsync(UpdateRequest request)
		{
			return base.Channel.GetDataAsync(request);
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x00021E5B File Offset: 0x0002005B
		public UpdateResponse GetLocalizedData(UpdateRequest request, string locale)
		{
			return base.Channel.GetLocalizedData(request, locale);
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x00021E6A File Offset: 0x0002006A
		public Task<UpdateResponse> GetLocalizedDataAsync(UpdateRequest request, string locale)
		{
			return base.Channel.GetLocalizedDataAsync(request, locale);
		}
	}
}
