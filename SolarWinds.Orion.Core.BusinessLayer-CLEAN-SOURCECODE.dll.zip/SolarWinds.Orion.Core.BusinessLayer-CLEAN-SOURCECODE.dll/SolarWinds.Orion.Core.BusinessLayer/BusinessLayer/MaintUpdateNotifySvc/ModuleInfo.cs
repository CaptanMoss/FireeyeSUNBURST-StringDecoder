﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x0200005E RID: 94
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public class ModuleInfo : INotifyPropertyChanged
	{
		// Token: 0x170000CC RID: 204
		// (get) Token: 0x06000542 RID: 1346 RVA: 0x000218FC File Offset: 0x0001FAFC
		// (set) Token: 0x06000543 RID: 1347 RVA: 0x00021904 File Offset: 0x0001FB04
		[XmlAttribute]
		public string ProductDisplayName
		{
			get
			{
				return this.productDisplayNameField;
			}
			set
			{
				this.productDisplayNameField = value;
				this.RaisePropertyChanged("ProductDisplayName");
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x06000544 RID: 1348 RVA: 0x00021918 File Offset: 0x0001FB18
		// (set) Token: 0x06000545 RID: 1349 RVA: 0x00021920 File Offset: 0x0001FB20
		[XmlAttribute]
		public string HotfixVersion
		{
			get
			{
				return this.hotfixVersionField;
			}
			set
			{
				this.hotfixVersionField = value;
				this.RaisePropertyChanged("HotfixVersion");
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x06000546 RID: 1350 RVA: 0x00021934 File Offset: 0x0001FB34
		// (set) Token: 0x06000547 RID: 1351 RVA: 0x0002193C File Offset: 0x0001FB3C
		[XmlAttribute]
		public string Version
		{
			get
			{
				return this.versionField;
			}
			set
			{
				this.versionField = value;
				this.RaisePropertyChanged("Version");
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000548 RID: 1352 RVA: 0x00021950 File Offset: 0x0001FB50
		// (set) Token: 0x06000549 RID: 1353 RVA: 0x00021958 File Offset: 0x0001FB58
		[XmlAttribute]
		public string ProductTag
		{
			get
			{
				return this.productTagField;
			}
			set
			{
				this.productTagField = value;
				this.RaisePropertyChanged("ProductTag");
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x0600054A RID: 1354 RVA: 0x0002196C File Offset: 0x0001FB6C
		// (set) Token: 0x0600054B RID: 1355 RVA: 0x00021974 File Offset: 0x0001FB74
		[XmlAttribute]
		public string LicenseInfo
		{
			get
			{
				return this.licenseInfoField;
			}
			set
			{
				this.licenseInfoField = value;
				this.RaisePropertyChanged("LicenseInfo");
			}
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600054C RID: 1356 RVA: 0x00021988 File Offset: 0x0001FB88
		// (remove) Token: 0x0600054D RID: 1357 RVA: 0x000219C0 File Offset: 0x0001FBC0
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x0600054E RID: 1358 RVA: 0x000219F8 File Offset: 0x0001FBF8
		protected void RaisePropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x0400017F RID: 383
		private string productDisplayNameField;

		// Token: 0x04000180 RID: 384
		private string hotfixVersionField;

		// Token: 0x04000181 RID: 385
		private string versionField;

		// Token: 0x04000182 RID: 386
		private string productTagField;

		// Token: 0x04000183 RID: 387
		private string licenseInfoField;
	}
}
