﻿using System;
using System.CodeDom.Compiler;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x02000061 RID: 97
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public enum ModuleStatusType
	{
		// Token: 0x04000193 RID: 403
		Updated,
		// Token: 0x04000194 RID: 404
		Current,
		// Token: 0x04000195 RID: 405
		NotFound
	}
}
