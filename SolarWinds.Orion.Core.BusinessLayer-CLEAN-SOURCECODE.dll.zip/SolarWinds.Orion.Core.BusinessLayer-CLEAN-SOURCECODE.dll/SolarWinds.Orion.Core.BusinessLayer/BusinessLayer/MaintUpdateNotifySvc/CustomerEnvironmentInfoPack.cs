﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x0200005D RID: 93
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public class CustomerEnvironmentInfoPack : INotifyPropertyChanged
	{
		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000532 RID: 1330 RVA: 0x000217C0 File Offset: 0x0001F9C0
		// (set) Token: 0x06000533 RID: 1331 RVA: 0x000217C8 File Offset: 0x0001F9C8
		[XmlArray(Order = 0)]
		[XmlArrayItem("Module")]
		public ModuleInfo[] Modules
		{
			get
			{
				return this.modulesField;
			}
			set
			{
				this.modulesField = value;
				this.RaisePropertyChanged("Modules");
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000534 RID: 1332 RVA: 0x000217DC File Offset: 0x0001F9DC
		// (set) Token: 0x06000535 RID: 1333 RVA: 0x000217E4 File Offset: 0x0001F9E4
		[XmlAttribute]
		public string OSVersion
		{
			get
			{
				return this.oSVersionField;
			}
			set
			{
				this.oSVersionField = value;
				this.RaisePropertyChanged("OSVersion");
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000536 RID: 1334 RVA: 0x000217F8 File Offset: 0x0001F9F8
		// (set) Token: 0x06000537 RID: 1335 RVA: 0x00021800 File Offset: 0x0001FA00
		[XmlAttribute]
		public string OrionDBVersion
		{
			get
			{
				return this.orionDBVersionField;
			}
			set
			{
				this.orionDBVersionField = value;
				this.RaisePropertyChanged("OrionDBVersion");
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000538 RID: 1336 RVA: 0x00021814 File Offset: 0x0001FA14
		// (set) Token: 0x06000539 RID: 1337 RVA: 0x0002181C File Offset: 0x0001FA1C
		[XmlAttribute]
		public string SQLVersion
		{
			get
			{
				return this.sQLVersionField;
			}
			set
			{
				this.sQLVersionField = value;
				this.RaisePropertyChanged("SQLVersion");
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x0600053A RID: 1338 RVA: 0x00021830 File Offset: 0x0001FA30
		// (set) Token: 0x0600053B RID: 1339 RVA: 0x00021838 File Offset: 0x0001FA38
		[XmlAttribute]
		public Guid CustomerUniqueId
		{
			get
			{
				return this.customerUniqueIdField;
			}
			set
			{
				this.customerUniqueIdField = value;
				this.RaisePropertyChanged("CustomerUniqueId");
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x0600053C RID: 1340 RVA: 0x0002184C File Offset: 0x0001FA4C
		// (set) Token: 0x0600053D RID: 1341 RVA: 0x00021854 File Offset: 0x0001FA54
		[XmlAttribute]
		public DateTime LastUpdateCheck
		{
			get
			{
				return this.lastUpdateCheckField;
			}
			set
			{
				this.lastUpdateCheckField = value;
				this.RaisePropertyChanged("LastUpdateCheck");
			}
		}

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x0600053E RID: 1342 RVA: 0x00021868 File Offset: 0x0001FA68
		// (remove) Token: 0x0600053F RID: 1343 RVA: 0x000218A0 File Offset: 0x0001FAA0
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000540 RID: 1344 RVA: 0x000218D8 File Offset: 0x0001FAD8
		protected void RaisePropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000178 RID: 376
		private ModuleInfo[] modulesField;

		// Token: 0x04000179 RID: 377
		private string oSVersionField;

		// Token: 0x0400017A RID: 378
		private string orionDBVersionField;

		// Token: 0x0400017B RID: 379
		private string sQLVersionField;

		// Token: 0x0400017C RID: 380
		private Guid customerUniqueIdField;

		// Token: 0x0400017D RID: 381
		private DateTime lastUpdateCheckField;
	}
}
