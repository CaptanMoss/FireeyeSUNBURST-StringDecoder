﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x0200005F RID: 95
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public class UpdateMessage : INotifyPropertyChanged
	{
		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x06000550 RID: 1360 RVA: 0x00021A1C File Offset: 0x0001FC1C
		// (set) Token: 0x06000551 RID: 1361 RVA: 0x00021A24 File Offset: 0x0001FC24
		[XmlElement(Order = 0)]
		public DateTime PublishDate
		{
			get
			{
				return this.publishDateField;
			}
			set
			{
				this.publishDateField = value;
				this.RaisePropertyChanged("PublishDate");
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x06000552 RID: 1362 RVA: 0x00021A38 File Offset: 0x0001FC38
		// (set) Token: 0x06000553 RID: 1363 RVA: 0x00021A40 File Offset: 0x0001FC40
		[XmlElement(Order = 1)]
		public string MaintenanceMessage
		{
			get
			{
				return this.maintenanceMessageField;
			}
			set
			{
				this.maintenanceMessageField = value;
				this.RaisePropertyChanged("MaintenanceMessage");
			}
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x06000554 RID: 1364 RVA: 0x00021A54 File Offset: 0x0001FC54
		// (remove) Token: 0x06000555 RID: 1365 RVA: 0x00021A8C File Offset: 0x0001FC8C
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000556 RID: 1366 RVA: 0x00021AC4 File Offset: 0x0001FCC4
		protected void RaisePropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000185 RID: 389
		private DateTime publishDateField;

		// Token: 0x04000186 RID: 390
		private string maintenanceMessageField;
	}
}
