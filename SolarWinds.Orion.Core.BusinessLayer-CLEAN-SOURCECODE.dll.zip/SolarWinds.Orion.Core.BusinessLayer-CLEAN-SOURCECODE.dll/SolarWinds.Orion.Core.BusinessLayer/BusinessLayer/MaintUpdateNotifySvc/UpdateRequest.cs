﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintUpdateNotifySvc
{
	// Token: 0x0200005C RID: 92
	[GeneratedCode("System.Xml", "4.8.3761.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[XmlType(Namespace = "http://www.solarwinds.com/contracts/IMaintUpdateNotifySvc/2009/09")]
	[Serializable]
	public class UpdateRequest : INotifyPropertyChanged
	{
		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x0600052A RID: 1322 RVA: 0x000216F4 File Offset: 0x0001F8F4
		// (set) Token: 0x0600052B RID: 1323 RVA: 0x000216FC File Offset: 0x0001F8FC
		[XmlElement(Order = 0)]
		public string ContractVersion
		{
			get
			{
				return this.contractVersionField;
			}
			set
			{
				this.contractVersionField = value;
				this.RaisePropertyChanged("ContractVersion");
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x0600052C RID: 1324 RVA: 0x00021710 File Offset: 0x0001F910
		// (set) Token: 0x0600052D RID: 1325 RVA: 0x00021718 File Offset: 0x0001F918
		[XmlElement(Order = 1)]
		public CustomerEnvironmentInfoPack CustomerInfo
		{
			get
			{
				return this.customerInfoField;
			}
			set
			{
				this.customerInfoField = value;
				this.RaisePropertyChanged("CustomerInfo");
			}
		}

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600052E RID: 1326 RVA: 0x0002172C File Offset: 0x0001F92C
		// (remove) Token: 0x0600052F RID: 1327 RVA: 0x00021764 File Offset: 0x0001F964
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000530 RID: 1328 RVA: 0x0002179C File Offset: 0x0001F99C
		protected void RaisePropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000175 RID: 373
		private string contractVersionField;

		// Token: 0x04000176 RID: 374
		private CustomerEnvironmentInfoPack customerInfoField;
	}
}
