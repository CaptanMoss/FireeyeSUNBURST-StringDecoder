﻿using System;
using SolarWinds.Collector.Contract;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000033 RID: 51
	public interface IPollingControllerServiceHelper : IPollingControllerService, IDisposable
	{
	}
}
