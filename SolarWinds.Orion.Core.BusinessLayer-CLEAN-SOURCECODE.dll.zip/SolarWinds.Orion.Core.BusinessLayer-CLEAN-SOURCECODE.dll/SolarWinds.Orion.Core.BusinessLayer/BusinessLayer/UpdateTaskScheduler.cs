﻿using System;
using System.Collections.Generic;
using System.Threading;
using Amib.Threading;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.i18n;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000044 RID: 68
	public class UpdateTaskScheduler<TTaskKey, TCallbackArg> : IDisposable where TTaskKey : IComparable
	{
		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000434 RID: 1076 RVA: 0x0001CA54 File Offset: 0x0001AC54
		public bool ChangesActive
		{
			get
			{
				object obj = this.syncLock;
				bool result;
				lock (obj)
				{
					result = (this.ongoingChangesCounter > 0);
				}
				return result;
			}
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x0001CA9C File Offset: 0x0001AC9C
		public UpdateTaskScheduler(Action<TTaskKey> taskRoutine, int maxRunningTasks, TimeSpan postponeTaskDelay, TimeSpan mandatorySchedulerDelay)
		{
			this.taskRoutine = taskRoutine;
			this.postponeTaskDelay = postponeTaskDelay;
			this.mandatorySchedulerDelay = mandatorySchedulerDelay;
			this.ongoingChangesCounter = 0;
			this.ongoingTasks = new HashSet<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask>(UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.IdentityComparer.Instance);
			this.scheduledTasks = new PriorityQueue<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask>(UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.SchedulingComparer.Instance);
			this.schedulerThread = new Thread(new ThreadStart(this.SchedulerRoutine));
			this.schedulerThread.IsBackground = true;
			this.schedulerThread.Start();
			this.processingThreadPool = new SmartThreadPool(new STPStartInfo
			{
				MaxWorkerThreads = maxRunningTasks,
				MinWorkerThreads = 0,
				StartSuspended = false
			});
			this.processingGroup = this.processingThreadPool.CreateWorkItemsGroup(maxRunningTasks);
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x0001CB68 File Offset: 0x0001AD68
		public void BeginChanges()
		{
			object obj = this.syncLock;
			lock (obj)
			{
				this.ongoingChangesCounter++;
				if (this.log.IsDebugEnabled)
				{
					this.log.DebugFormat("BeginChanges {0}", this.ongoingChangesCounter);
				}
			}
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x0001CBD8 File Offset: 0x0001ADD8
		public void EndChanges()
		{
			object obj = this.syncLock;
			lock (obj)
			{
				if (this.ongoingChangesCounter <= 0)
				{
					throw new InvalidOperationException("Unable to find matching BeginChanges call");
				}
				this.ongoingChangesCounter--;
				if (this.log.IsDebugEnabled)
				{
					this.log.DebugFormat("EndChanges {0}", this.ongoingChangesCounter);
				}
				if (this.ongoingChangesCounter == 0)
				{
					this.log.Debug("EndChanges - waking up scheduler");
					Monitor.PulseAll(this.syncLock);
				}
			}
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0001CC80 File Offset: 0x0001AE80
		public void RequestUpdateAsync(TTaskKey taskKey, UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTaskCallback callback, TimeSpan waitForChangesDelay)
		{
			UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask scheduledTask = new UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask();
			scheduledTask.TaskKey = taskKey;
			scheduledTask.PlannedExecution = DateTime.UtcNow.Add(waitForChangesDelay);
			object callbacks;
			if (callback == null)
			{
				callbacks = null;
			}
			else
			{
				(callbacks = new List<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTaskCallback>()).Add(callback);
			}
			scheduledTask.Callbacks = callbacks;
			UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask scheduledTask2 = scheduledTask;
			if (this.log.IsDebugEnabled)
			{
				this.log.DebugFormat("RequestUpdate for Task {0} - Enter", taskKey);
			}
			object obj = this.syncLock;
			lock (obj)
			{
				UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask scheduledTask3;
				if (this.scheduledTasks.TryFind(scheduledTask2, UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.IdentityComparer.Instance, ref scheduledTask3))
				{
					if (scheduledTask2.PlannedExecution < scheduledTask3.PlannedExecution)
					{
						if (scheduledTask3.Callbacks != null)
						{
							if (scheduledTask2.Callbacks != null)
							{
								scheduledTask2.Callbacks.AddRange(scheduledTask3.Callbacks);
							}
							else
							{
								scheduledTask2.Callbacks = scheduledTask3.Callbacks;
							}
						}
						this.scheduledTasks.Remove(scheduledTask3, UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.IdentityComparer.Instance);
						this.scheduledTasks.Enqueue(scheduledTask2);
						if (this.log.IsInfoEnabled)
						{
							this.log.InfoFormat("Task {0} was rescheduled from {1} to {2}", scheduledTask2, scheduledTask3.PlannedExecution, scheduledTask2.PlannedExecution);
						}
						Monitor.PulseAll(this.syncLock);
					}
					else
					{
						if (scheduledTask2.Callbacks != null)
						{
							if (scheduledTask3.Callbacks != null)
							{
								scheduledTask3.Callbacks.AddRange(scheduledTask2.Callbacks);
							}
							else
							{
								scheduledTask3.Callbacks = scheduledTask2.Callbacks;
							}
						}
						if (this.log.IsInfoEnabled)
						{
							this.log.InfoFormat("Task {0} has been scheduled already at {1}, requested time {2}", scheduledTask2, scheduledTask3.PlannedExecution, scheduledTask2.PlannedExecution);
						}
					}
				}
				else
				{
					this.scheduledTasks.Enqueue(scheduledTask2);
					if (this.log.IsInfoEnabled)
					{
						this.log.InfoFormat("Task {0} has been scheduled for {1}", scheduledTask2, scheduledTask2.PlannedExecution);
					}
					Monitor.PulseAll(this.syncLock);
				}
			}
			if (this.log.IsDebugEnabled)
			{
				this.log.DebugFormat("RequestUpdate for Task {0} - Leave", taskKey);
			}
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0001CEB4 File Offset: 0x0001B0B4
		private void SchedulerRoutine()
		{
			this.log.Debug("Scheduler: scheduling thread started");
			for (;;)
			{
				UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask scheduledTask = null;
				object obj = this.syncLock;
				lock (obj)
				{
					if (this.ChangesActive)
					{
						this.log.Debug("Suspending Scheduler: ongoing changes detected");
						Monitor.Wait(this.syncLock);
					}
					else if (this.scheduledTasks.Count == 0)
					{
						this.log.Debug("Suspending Scheduler: no pending tasks to process");
						Monitor.Wait(this.syncLock);
					}
					else
					{
						DateTime utcNow = DateTime.UtcNow;
						scheduledTask = this.scheduledTasks.Peek();
						if (scheduledTask.PlannedExecution > utcNow)
						{
							TimeSpan timeSpan = scheduledTask.PlannedExecution.Subtract(utcNow);
							if (this.log.IsDebugEnabled)
							{
								this.log.DebugFormat("Suspending Scheduler: woke up too early, next task {0} is scheduled for {1}, will be suspended for {2}", scheduledTask, scheduledTask.PlannedExecution, timeSpan);
							}
							scheduledTask = null;
							Monitor.Wait(this.syncLock, timeSpan);
						}
						else if (this.ongoingTasks.Contains(scheduledTask))
						{
							this.scheduledTasks.Remove(scheduledTask, UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.IdentityComparer.Instance);
							scheduledTask.PlannedExecution = utcNow.Add(this.postponeTaskDelay);
							this.scheduledTasks.Enqueue(scheduledTask);
							if (this.log.IsDebugEnabled)
							{
								this.log.DebugFormat("Scheduler: task {0} is being executed, rescheduling its next execution to {1}", scheduledTask, scheduledTask.PlannedExecution);
							}
							scheduledTask = null;
						}
						else
						{
							scheduledTask = this.scheduledTasks.Dequeue();
							this.ongoingTasks.Add(scheduledTask);
							if (this.log.IsDebugEnabled)
							{
								this.log.DebugFormat("Scheduler: Task {0} is planed to get executed now", scheduledTask);
							}
						}
					}
				}
				if (scheduledTask != null)
				{
					this.processingGroup.QueueWorkItem(new WorkItemCallback(this.ThreadPoolRoutine), scheduledTask);
					if (this.log.IsDebugEnabled)
					{
						this.log.DebugFormat("Scheduler: Task {0} was executed", scheduledTask);
					}
				}
				Thread.Sleep(this.mandatorySchedulerDelay);
			}
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0001D0C4 File Offset: 0x0001B2C4
		private object ThreadPoolRoutine(object state)
		{
			UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask scheduledTask = state as UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask;
			if (scheduledTask == null)
			{
				throw new ArgumentException("Unexpected state object or null", "state");
			}
			try
			{
				bool taskExecuted = false;
				Exception ex = null;
				using (LocaleThreadState.EnsurePrimaryLocale())
				{
					if (!SmartThreadPool.IsWorkItemCanceled)
					{
						try
						{
							taskExecuted = true;
							this.taskRoutine(scheduledTask.TaskKey);
						}
						catch (Exception ex2)
						{
							ex = ex2;
							this.log.Error(string.Format("Task {0} cought unhandled exception from task routine", scheduledTask), ex2);
						}
					}
					if (scheduledTask.Callbacks != null)
					{
						foreach (UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTaskCallback scheduledTaskCallback in scheduledTask.Callbacks)
						{
							try
							{
								scheduledTaskCallback.Callback(new UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTaskCallbackEventArgs(scheduledTask.TaskKey, scheduledTaskCallback.State, ex, taskExecuted));
							}
							catch (Exception ex3)
							{
								this.log.Error(string.Format("Task {0} callback failed", scheduledTask), ex3);
							}
						}
					}
				}
			}
			catch (Exception ex4)
			{
				this.log.Error(string.Format("Task {0} cought unhandled exception during task processing", scheduledTask), ex4);
			}
			finally
			{
				object obj = this.syncLock;
				lock (obj)
				{
					this.ongoingTasks.Remove(scheduledTask);
				}
			}
			return null;
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0001D25C File Offset: 0x0001B45C
		private void Dispose(bool disposing)
		{
			if (!this.disposed)
			{
				if (disposing)
				{
					if (this.schedulerThread != null)
					{
						this.schedulerThread.Abort();
						this.schedulerThread = null;
					}
					if (this.processingGroup != null)
					{
						this.processingGroup.Cancel(false);
						this.processingGroup = null;
					}
					if (this.processingThreadPool != null)
					{
						this.processingThreadPool.Dispose();
						this.processingThreadPool = null;
					}
				}
				this.disposed = true;
			}
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x0001D2CA File Offset: 0x0001B4CA
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x0001D2DC File Offset: 0x0001B4DC
		~UpdateTaskScheduler()
		{
			this.Dispose(false);
		}

		// Token: 0x04000102 RID: 258
		private Log log = new Log();

		// Token: 0x04000103 RID: 259
		private object syncLock = new object();

		// Token: 0x04000104 RID: 260
		private TimeSpan postponeTaskDelay;

		// Token: 0x04000105 RID: 261
		private TimeSpan mandatorySchedulerDelay;

		// Token: 0x04000106 RID: 262
		private Action<TTaskKey> taskRoutine;

		// Token: 0x04000107 RID: 263
		private Thread schedulerThread;

		// Token: 0x04000108 RID: 264
		private SmartThreadPool processingThreadPool;

		// Token: 0x04000109 RID: 265
		private IWorkItemsGroup processingGroup;

		// Token: 0x0400010A RID: 266
		private int ongoingChangesCounter;

		// Token: 0x0400010B RID: 267
		private PriorityQueue<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask> scheduledTasks;

		// Token: 0x0400010C RID: 268
		private HashSet<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask> ongoingTasks;

		// Token: 0x0400010D RID: 269
		private bool disposed;

		// Token: 0x02000154 RID: 340
		public class ScheduledTaskCallbackEventArgs : EventArgs
		{
			// Token: 0x1700013E RID: 318
			// (get) Token: 0x06000B65 RID: 2917 RVA: 0x0004A0B2 File Offset: 0x000482B2
			// (set) Token: 0x06000B66 RID: 2918 RVA: 0x0004A0BA File Offset: 0x000482BA
			public TTaskKey TaskKey { get; private set; }

			// Token: 0x1700013F RID: 319
			// (get) Token: 0x06000B67 RID: 2919 RVA: 0x0004A0C3 File Offset: 0x000482C3
			// (set) Token: 0x06000B68 RID: 2920 RVA: 0x0004A0CB File Offset: 0x000482CB
			public TCallbackArg State { get; private set; }

			// Token: 0x17000140 RID: 320
			// (get) Token: 0x06000B69 RID: 2921 RVA: 0x0004A0D4 File Offset: 0x000482D4
			// (set) Token: 0x06000B6A RID: 2922 RVA: 0x0004A0DC File Offset: 0x000482DC
			public Exception TaskException { get; private set; }

			// Token: 0x17000141 RID: 321
			// (get) Token: 0x06000B6B RID: 2923 RVA: 0x0004A0E5 File Offset: 0x000482E5
			// (set) Token: 0x06000B6C RID: 2924 RVA: 0x0004A0ED File Offset: 0x000482ED
			public bool TaskExecuted { get; private set; }

			// Token: 0x17000142 RID: 322
			// (get) Token: 0x06000B6D RID: 2925 RVA: 0x0004A0F6 File Offset: 0x000482F6
			public bool TaskFailed
			{
				get
				{
					return this.TaskException != null;
				}
			}

			// Token: 0x06000B6E RID: 2926 RVA: 0x0004A101 File Offset: 0x00048301
			internal ScheduledTaskCallbackEventArgs(TTaskKey taskKey, TCallbackArg state, Exception ex, bool taskExecuted)
			{
				this.TaskKey = taskKey;
				this.State = state;
				this.TaskException = ex;
				this.TaskExecuted = taskExecuted;
			}
		}

		// Token: 0x02000155 RID: 341
		public class ScheduledTaskCallback
		{
			// Token: 0x17000143 RID: 323
			// (get) Token: 0x06000B6F RID: 2927 RVA: 0x0004A126 File Offset: 0x00048326
			// (set) Token: 0x06000B70 RID: 2928 RVA: 0x0004A12E File Offset: 0x0004832E
			public Action<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTaskCallbackEventArgs> Callback { get; private set; }

			// Token: 0x17000144 RID: 324
			// (get) Token: 0x06000B71 RID: 2929 RVA: 0x0004A137 File Offset: 0x00048337
			// (set) Token: 0x06000B72 RID: 2930 RVA: 0x0004A13F File Offset: 0x0004833F
			public TCallbackArg State { get; private set; }

			// Token: 0x06000B73 RID: 2931 RVA: 0x0004A148 File Offset: 0x00048348
			public ScheduledTaskCallback(Action<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTaskCallbackEventArgs> callback, TCallbackArg state)
			{
				this.Callback = callback;
				this.State = state;
			}
		}

		// Token: 0x02000156 RID: 342
		private class ScheduledTask
		{
			// Token: 0x06000B74 RID: 2932 RVA: 0x0004A15E File Offset: 0x0004835E
			public override string ToString()
			{
				return this.TaskKey.ToString();
			}

			// Token: 0x04000455 RID: 1109
			public TTaskKey TaskKey;

			// Token: 0x04000456 RID: 1110
			public List<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTaskCallback> Callbacks;

			// Token: 0x04000457 RID: 1111
			public DateTime PlannedExecution;

			// Token: 0x020001D5 RID: 469
			public class IdentityComparer : Comparer<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask>, IEqualityComparer<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask>
			{
				// Token: 0x06000D1B RID: 3355 RVA: 0x0004C8DA File Offset: 0x0004AADA
				public override int Compare(UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask x, UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask y)
				{
					return x.TaskKey.CompareTo(y.TaskKey);
				}

				// Token: 0x06000D1C RID: 3356 RVA: 0x0004C8F8 File Offset: 0x0004AAF8
				public bool Equals(UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask x, UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask y)
				{
					return x.TaskKey.CompareTo(y.TaskKey) == 0;
				}

				// Token: 0x06000D1D RID: 3357 RVA: 0x0004C919 File Offset: 0x0004AB19
				public int GetHashCode(UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask obj)
				{
					return obj.TaskKey.GetHashCode();
				}

				// Token: 0x040005DA RID: 1498
				public static readonly UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.IdentityComparer Instance = new UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.IdentityComparer();
			}

			// Token: 0x020001D6 RID: 470
			public class SchedulingComparer : Comparer<UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask>
			{
				// Token: 0x06000D20 RID: 3360 RVA: 0x0004C940 File Offset: 0x0004AB40
				public override int Compare(UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask x, UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask y)
				{
					return DateTime.Compare(y.PlannedExecution, x.PlannedExecution);
				}

				// Token: 0x040005DB RID: 1499
				public static readonly UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.SchedulingComparer Instance = new UpdateTaskScheduler<TTaskKey, TCallbackArg>.ScheduledTask.SchedulingComparer();
			}
		}
	}
}
