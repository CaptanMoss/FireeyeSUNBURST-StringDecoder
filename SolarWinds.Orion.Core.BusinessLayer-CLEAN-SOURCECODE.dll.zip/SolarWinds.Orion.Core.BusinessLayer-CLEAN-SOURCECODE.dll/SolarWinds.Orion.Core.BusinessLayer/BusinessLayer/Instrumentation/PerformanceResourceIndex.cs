﻿using System;
using System.Collections.Concurrent;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Instrumentation.Keys;

namespace SolarWinds.Orion.Core.BusinessLayer.Instrumentation
{
	// Token: 0x02000075 RID: 117
	internal class PerformanceResourceIndex : IPerformanceResourceIndex
	{
		// Token: 0x060005EC RID: 1516 RVA: 0x00023A90 File Offset: 0x00021C90
		public int GetResourceId(StringKeyBase resourceId)
		{
			if (resourceId == null)
			{
				throw new ArgumentNullException("resourceId");
			}
			PerformanceResourceIndex.log.Debug(string.Format("Identifying {0} - {1}", resourceId.ResourceType, resourceId.Id));
			PerformanceResourceKey key = new PerformanceResourceKey(resourceId);
			return this.cache.Value.GetOrAdd(key, new Func<PerformanceResourceKey, int>(this.AddToDatabase));
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x00023AF4 File Offset: 0x00021CF4
		private static ConcurrentDictionary<PerformanceResourceKey, int> InitFromDatabase()
		{
			PerformanceResourceIndex.log.Debug("Loading PerformanceResourceIndex from database");
			ConcurrentDictionary<PerformanceResourceKey, int> result;
			try
			{
				ConcurrentDictionary<PerformanceResourceKey, int> concurrentDictionary = new ConcurrentDictionary<PerformanceResourceKey, int>();
				using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT [ResourceTypeId], [ResourceName], [ResourceId] FROM [dbo].[WebsitePerformanceResource]"))
				{
					using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
					{
						while (dataReader.Read())
						{
							PerformanceResourceKey key = new PerformanceResourceKey(dataReader.GetInt32(0), dataReader.GetString(1));
							concurrentDictionary[key] = dataReader.GetInt32(2);
						}
					}
				}
				PerformanceResourceIndex.log.Debug(string.Format("Loaded {0} items into {1} from database", concurrentDictionary.Count, "PerformanceResourceIndex"));
				result = concurrentDictionary;
			}
			catch (Exception ex)
			{
				PerformanceResourceIndex.log.Error("Exception occurred when loading PerformanceResourceIndex from database", ex);
				throw;
			}
			return result;
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x00023BD4 File Offset: 0x00021DD4
		private int AddToDatabase(PerformanceResourceKey resourceId)
		{
			PerformanceResourceIndex.log.Debug(string.Format("Inserting performance resource key {0} into database", resourceId));
			int result;
			try
			{
				using (SqlCommand textCommand = SqlHelper.GetTextCommand("INSERT INTO [dbo].[WebsitePerformanceResource] \r\n         ([ResourceTypeId],[ResourceName]) \r\n         VALUES(@resourceTypeId, @resourceName)\r\n\r\nSELECT @@IDENTITY"))
				{
					textCommand.Parameters.AddWithValue("resourceTypeId", resourceId.ResourceType);
					textCommand.Parameters.AddWithValue("resourceName", resourceId.ResourceName);
					result = Convert.ToInt32(SqlHelper.ExecuteScalar(textCommand));
				}
			}
			catch (Exception ex)
			{
				PerformanceResourceIndex.log.Error(string.Format("Exception occurred when inserting performance resource key {0} to database", resourceId), ex);
				throw;
			}
			return result;
		}

		// Token: 0x040001D3 RID: 467
		private static readonly Log log = new Log();

		// Token: 0x040001D4 RID: 468
		private readonly Lazy<ConcurrentDictionary<PerformanceResourceKey, int>> cache = new Lazy<ConcurrentDictionary<PerformanceResourceKey, int>>(new Func<ConcurrentDictionary<PerformanceResourceKey, int>>(PerformanceResourceIndex.InitFromDatabase), LazyThreadSafetyMode.ExecutionAndPublication);
	}
}
