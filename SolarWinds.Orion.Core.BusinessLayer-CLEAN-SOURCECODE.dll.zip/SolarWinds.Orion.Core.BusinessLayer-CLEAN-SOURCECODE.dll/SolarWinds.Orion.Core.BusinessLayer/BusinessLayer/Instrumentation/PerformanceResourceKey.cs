﻿using System;
using SolarWinds.Orion.Core.Common.Instrumentation;
using SolarWinds.Orion.Core.Common.Instrumentation.Keys;

namespace SolarWinds.Orion.Core.BusinessLayer.Instrumentation
{
	// Token: 0x02000076 RID: 118
	internal class PerformanceResourceKey
	{
		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x060005F1 RID: 1521 RVA: 0x00023CB0 File Offset: 0x00021EB0
		public WebResourceType ResourceType { get; }

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x060005F2 RID: 1522 RVA: 0x00023CB8 File Offset: 0x00021EB8
		public string ResourceName { get; }

		// Token: 0x060005F3 RID: 1523 RVA: 0x00023CC0 File Offset: 0x00021EC0
		public PerformanceResourceKey(StringKeyBase stringKey) : this(stringKey.ResourceType, stringKey.Id)
		{
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x00023CD4 File Offset: 0x00021ED4
		public PerformanceResourceKey(WebResourceType resourceType, string resourceName)
		{
			if (string.IsNullOrEmpty(resourceName))
			{
				throw new ArgumentNullException("resourceName");
			}
			this.ResourceType = resourceType;
			this.ResourceName = resourceName;
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x00023CFD File Offset: 0x00021EFD
		public override string ToString()
		{
			return string.Format("{0}-{1}", this.ResourceType, this.ResourceName);
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00023D1A File Offset: 0x00021F1A
		public override int GetHashCode()
		{
			return this.ResourceType ^ 13 * (this.ResourceName ?? string.Empty).GetHashCode();
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x00023D3C File Offset: 0x00021F3C
		public override bool Equals(object obj)
		{
			PerformanceResourceKey performanceResourceKey;
			return (performanceResourceKey = (obj as PerformanceResourceKey)) != null && performanceResourceKey.ResourceType == this.ResourceType && performanceResourceKey.ResourceName == this.ResourceName;
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x00023D76 File Offset: 0x00021F76
		public static bool operator ==(PerformanceResourceKey left, PerformanceResourceKey right)
		{
			if (left == null)
			{
				return right == null;
			}
			return left.Equals(right);
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x00023D89 File Offset: 0x00021F89
		public static bool operator !=(PerformanceResourceKey left, PerformanceResourceKey right)
		{
			return !(left == right);
		}
	}
}
