﻿using System;
using SolarWinds.Orion.Core.Common.Instrumentation.Keys;

namespace SolarWinds.Orion.Core.BusinessLayer.Instrumentation
{
	// Token: 0x02000074 RID: 116
	internal interface IPerformanceResourceIndex
	{
		// Token: 0x060005EB RID: 1515
		int GetResourceId(StringKeyBase resourceId);
	}
}
