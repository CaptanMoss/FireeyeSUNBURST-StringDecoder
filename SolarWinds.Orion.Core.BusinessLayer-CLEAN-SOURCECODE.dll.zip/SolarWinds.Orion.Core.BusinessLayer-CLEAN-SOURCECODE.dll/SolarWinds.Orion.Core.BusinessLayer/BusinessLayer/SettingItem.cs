﻿using System;
using System.Data.SqlClient;
using SolarWinds.Orion.Common;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x0200003C RID: 60
	internal class SettingItem : SynchronizeItem
	{
		// Token: 0x06000401 RID: 1025 RVA: 0x0001BD95 File Offset: 0x00019F95
		public SettingItem(string settingID) : this(settingID, SettingItem.ColumnType.CurrentValue)
		{
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x0001BD9F File Offset: 0x00019F9F
		public SettingItem(string settingID, SettingItem.ColumnType columnType)
		{
			this.SettingID = settingID;
			this.Column = columnType;
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x0001BDB8 File Offset: 0x00019FB8
		public override object GetDatabaseValue()
		{
			object result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand(string.Format("SELECT {0} FROM Settings WHERE SettingID=@SettingID", this.Column.ToString())))
			{
				textCommand.Parameters.AddWithValue("SettingID", this.SettingID);
				result = SqlHelper.ExecuteScalar(textCommand);
			}
			return result;
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0001BE24 File Offset: 0x0001A024
		public override string ToString()
		{
			return string.Format("{0}/{1}", this.SettingID, this.Column);
		}

		// Token: 0x040000E9 RID: 233
		public SettingItem.ColumnType Column;

		// Token: 0x040000EA RID: 234
		public string SettingID;

		// Token: 0x02000148 RID: 328
		internal enum ColumnType
		{
			// Token: 0x0400041E RID: 1054
			CurrentValue,
			// Token: 0x0400041F RID: 1055
			Description
		}
	}
}
