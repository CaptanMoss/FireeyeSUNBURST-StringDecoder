﻿using System;
using System.ServiceModel;
using SolarWinds.JobEngine;
using SolarWinds.Orion.Core.BusinessLayer.Discovery;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.BusinessLayer;
using SolarWinds.Orion.Core.Common.Proxy.BusinessLayer;
using SolarWinds.ServiceDirectory.Client.Contract;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x0200000F RID: 15
	internal class CoreBusinessLayerServiceInstance : BusinessLayerServiceInstanceBase<CoreBusinessLayerService>
	{
		// Token: 0x06000249 RID: 585 RVA: 0x00010244 File Offset: 0x0000E444
		public CoreBusinessLayerServiceInstance(int engineId, IEngineInitiator engineInitiator, CoreBusinessLayerService serviceInstance, ServiceHostBase serviceHost, IServiceDirectoryClient serviceDirectoryClient) : base(engineId, engineInitiator.ServerName, serviceInstance, serviceHost, serviceDirectoryClient)
		{
			this._engineInitiator = engineInitiator;
			this.Service = serviceInstance;
			this.ServiceLogicalInstanceId = CoreBusinessLayerConfiguration.GetLogicalInstanceId(base.EngineId);
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x0600024A RID: 586 RVA: 0x00010277 File Offset: 0x0000E477
		public CoreBusinessLayerService Service { get; }

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x0600024B RID: 587 RVA: 0x0001027F File Offset: 0x0000E47F
		protected override string ServiceId
		{
			get
			{
				return "Core.BusinessLayer";
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600024C RID: 588 RVA: 0x00010286 File Offset: 0x0000E486
		protected override string ServiceLogicalInstanceId { get; }

		// Token: 0x0600024D RID: 589 RVA: 0x0001028E File Offset: 0x0000E48E
		public void RouteJobToEngine(JobDescription jobDescription)
		{
			if (!string.IsNullOrEmpty(jobDescription.LegacyEngine))
			{
				return;
			}
			jobDescription.LegacyEngine = base.EngineName;
		}

		// Token: 0x0600024E RID: 590 RVA: 0x000102AC File Offset: 0x0000E4AC
		public void StopRescheduleEngineDiscoveryJobsTask()
		{
			using (this._discoveryJobRescheduler)
			{
				this._discoveryJobRescheduler = null;
			}
		}

		// Token: 0x0600024F RID: 591 RVA: 0x000102E4 File Offset: 0x0000E4E4
		public void InitRescheduleEngineDiscoveryJobsTask(bool isMaster)
		{
			bool keepRunning = !isMaster;
			TimeSpan periodicRetryInterval = isMaster ? TimeSpan.FromSeconds(10.0) : TimeSpan.FromMinutes(10.0);
			this._discoveryJobRescheduler = new RescheduleDiscoveryJobsTask(new Func<int, bool>(this.Service.UpdateDiscoveryJobs), base.EngineId, keepRunning, periodicRetryInterval);
			this._discoveryJobRescheduler.StartPeriodicRescheduleTask();
		}

		// Token: 0x06000250 RID: 592 RVA: 0x00010347 File Offset: 0x0000E547
		public void RunRescheduleEngineDiscoveryJobsTask()
		{
			RescheduleDiscoveryJobsTask discoveryJobRescheduler = this._discoveryJobRescheduler;
			if (discoveryJobRescheduler == null)
			{
				return;
			}
			discoveryJobRescheduler.QueueRescheduleAttempt();
		}

		// Token: 0x06000251 RID: 593 RVA: 0x00010359 File Offset: 0x0000E559
		public void InitializeEngine()
		{
			this._engineInitiator.InitializeEngine();
		}

		// Token: 0x06000252 RID: 594 RVA: 0x00010366 File Offset: 0x0000E566
		public void UpdateEngine(bool updateJobEngineThrottleInfo)
		{
			this._engineInitiator.UpdateInfo(updateJobEngineThrottleInfo);
		}

		// Token: 0x04000066 RID: 102
		private RescheduleDiscoveryJobsTask _discoveryJobRescheduler;

		// Token: 0x04000067 RID: 103
		private readonly IEngineInitiator _engineInitiator;
	}
}
