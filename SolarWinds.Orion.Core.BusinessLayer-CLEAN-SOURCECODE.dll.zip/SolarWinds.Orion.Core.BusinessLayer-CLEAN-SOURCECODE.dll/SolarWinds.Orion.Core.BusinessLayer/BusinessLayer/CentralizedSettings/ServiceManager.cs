﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Threading.Tasks;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.BusinessLayer.ConfigurationSettings;
using SolarWinds.Orion.Core.Common.CentralizedSettings;

namespace SolarWinds.Orion.Core.BusinessLayer.CentralizedSettings
{
	// Token: 0x020000B7 RID: 183
	public class ServiceManager
	{
		// Token: 0x17000120 RID: 288
		// (get) Token: 0x060008E0 RID: 2272 RVA: 0x000406C0 File Offset: 0x0003E8C0
		public static ServiceManager Instance
		{
			get
			{
				ServiceManager result;
				if ((result = ServiceManager.instance) == null)
				{
					result = (ServiceManager.instance = new ServiceManager());
				}
				return result;
			}
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x000406D6 File Offset: 0x0003E8D6
		protected ServiceManager()
		{
			ServiceManager.services = ServiceManager.GetAllWindowsServices();
		}

		// Token: 0x060008E2 RID: 2274 RVA: 0x000406E8 File Offset: 0x0003E8E8
		protected ServiceManager(List<IWindowsServiceController> servicesLst)
		{
			ServiceManager.services = servicesLst;
		}

		// Token: 0x060008E3 RID: 2275 RVA: 0x000406F6 File Offset: 0x0003E8F6
		private static List<IWindowsServiceController> GetAllWindowsServices()
		{
			return new List<IWindowsServiceController>((from s in ServiceController.GetServices()
			select new WindowsServiceController(s.ServiceName)).ToList<WindowsServiceController>());
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x0004072C File Offset: 0x0003E92C
		public Dictionary<string, string> GetServicesDisplayNames(List<string> servicesNames)
		{
			return (from s in ServiceManager.services
			where servicesNames.Any((string x) => x.Equals(s.ServiceName, StringComparison.OrdinalIgnoreCase)) && s.Status != ServiceControllerStatus.StopPending && s.Status != ServiceControllerStatus.Stopped
			select s).Distinct<IWindowsServiceController>().ToDictionary((IWindowsServiceController s) => s.ServiceName, (IWindowsServiceController s) => s.DisplayName);
		}

		// Token: 0x060008E5 RID: 2277 RVA: 0x000407A4 File Offset: 0x0003E9A4
		public Dictionary<string, WindowsServiceRestartState> GetServicesStates(List<string> servicesNames)
		{
			return (from s in ServiceManager.services
			where servicesNames.Any((string x) => x.Equals(s.ServiceName, StringComparison.OrdinalIgnoreCase))
			select s).Distinct<IWindowsServiceController>().ToDictionary((IWindowsServiceController s) => s.ServiceName, (IWindowsServiceController s) => s.RestartState);
		}

		// Token: 0x060008E6 RID: 2278 RVA: 0x0004081C File Offset: 0x0003EA1C
		public void RestartServices(List<string> servicesNames)
		{
			Parallel.ForEach<IWindowsServiceController>(from s in ServiceManager.services
			where servicesNames.Any((string x) => x.Equals(s.ServiceName, StringComparison.OrdinalIgnoreCase))
			select s, delegate(IWindowsServiceController currentElement)
			{
				try
				{
					ServiceManager.Log.DebugFormat("Restarting service {0} started", currentElement.DisplayName);
					currentElement.RestartState = 0;
					int serviceTimeout = WindowsServiceSettings.Instance.ServiceTimeout;
					int tickCount = Environment.TickCount;
					TimeSpan timeSpan = TimeSpan.FromMilliseconds((double)serviceTimeout);
					if (currentElement.Status == ServiceControllerStatus.Running)
					{
						currentElement.Stop();
						currentElement.WaitForStatus(ServiceControllerStatus.Stopped, timeSpan);
					}
					int tickCount2 = Environment.TickCount;
					timeSpan = TimeSpan.FromMilliseconds((double)(serviceTimeout - (tickCount2 - tickCount)));
					if (currentElement.Status == ServiceControllerStatus.Stopped)
					{
						currentElement.Start();
						currentElement.WaitForStatus(ServiceControllerStatus.Running, timeSpan);
					}
					currentElement.RestartState = 1;
					ServiceManager.Log.DebugFormat("Restarting service {0} ended", currentElement.DisplayName);
				}
				catch (Exception ex)
				{
					currentElement.RestartState = 2;
					ServiceManager.Log.DebugFormat("Restarting service {0} failed. {1}", currentElement.DisplayName, ex);
				}
			});
		}

		// Token: 0x04000284 RID: 644
		private static readonly Log Log = new Log();

		// Token: 0x04000285 RID: 645
		protected static List<IWindowsServiceController> services;

		// Token: 0x04000286 RID: 646
		private static ServiceManager instance;
	}
}
