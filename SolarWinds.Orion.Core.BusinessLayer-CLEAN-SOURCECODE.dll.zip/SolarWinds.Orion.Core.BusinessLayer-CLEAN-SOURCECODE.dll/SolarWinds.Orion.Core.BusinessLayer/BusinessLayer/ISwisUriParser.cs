﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000012 RID: 18
	internal interface ISwisUriParser
	{
		// Token: 0x06000289 RID: 649
		string GetEntityId(string uriStr);
	}
}
