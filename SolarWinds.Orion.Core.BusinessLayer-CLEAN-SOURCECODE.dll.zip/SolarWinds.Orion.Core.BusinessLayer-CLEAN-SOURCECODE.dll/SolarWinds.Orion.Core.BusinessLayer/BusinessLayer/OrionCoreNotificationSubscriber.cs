﻿using System;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using SolarWinds.Common.Utility;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Indications;
using SolarWinds.Orion.PubSub;
using SolarWinds.Orion.Swis.PubSub.InformationService;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x0200002C RID: 44
	public class OrionCoreNotificationSubscriber : ISubscriber
	{
		// Token: 0x0600036A RID: 874 RVA: 0x000158F9 File Offset: 0x00013AF9
		public OrionCoreNotificationSubscriber(ISqlHelper sqlHelper) : this(sqlHelper, SubscriptionManager.Instance)
		{
		}

		// Token: 0x0600036B RID: 875 RVA: 0x00015907 File Offset: 0x00013B07
		public OrionCoreNotificationSubscriber(ISqlHelper sqlHelper, ISubscriptionManager subscriptionManager)
		{
			if (sqlHelper == null)
			{
				throw new ArgumentNullException("sqlHelper");
			}
			this._sqlHelper = sqlHelper;
			if (subscriptionManager == null)
			{
				throw new ArgumentNullException("subscriptionManager");
			}
			this._subscriptionManager = subscriptionManager;
		}

		// Token: 0x0600036C RID: 876 RVA: 0x0001593C File Offset: 0x00013B3C
		public Task OnNotificationAsync(Notification notification)
		{
			if (OrionCoreNotificationSubscriber.log.IsDebugEnabled)
			{
				OrionCoreNotificationSubscriber.log.DebugFormat("Indication of type \"{0}\" arrived.", notification.IndicationType);
			}
			try
			{
				object obj;
				if (notification.IndicationType == IndicationHelper.GetIndicationType(1) && notification.SourceInstanceProperties.TryGetValue("InstanceType", out obj) && string.Equals(obj as string, "Orion.Nodes", StringComparison.OrdinalIgnoreCase))
				{
					if (notification.SourceInstanceProperties.ContainsKey("NodeID"))
					{
						int nodeId = Convert.ToInt32(notification.SourceInstanceProperties["NodeID"]);
						this.InsertIntoDeletedTable(nodeId);
					}
					else
					{
						OrionCoreNotificationSubscriber.log.WarnFormat("Indication is type of {0} but does not contain NodeID", notification.IndicationType);
					}
				}
			}
			catch (Exception ex)
			{
				OrionCoreNotificationSubscriber.log.Error(string.Format("Exception occured when processing incoming indication of type \"{0}\"", notification.IndicationType), ex);
			}
			return Task.CompletedTask;
		}

		// Token: 0x0600036D RID: 877 RVA: 0x00015A20 File Offset: 0x00013C20
		public void Start()
		{
			Scheduler.Instance.Add(new ScheduledTask("OrionCoreIndications", new TimerCallback(this.Subscribe), null, TimeSpan.FromSeconds(1.0), TimeSpan.FromMinutes(1.0)));
		}

		// Token: 0x0600036E RID: 878 RVA: 0x00015A5F File Offset: 0x00013C5F
		public void Stop()
		{
			Scheduler.Instance.Remove("OrionCoreIndications");
		}

		// Token: 0x0600036F RID: 879 RVA: 0x00015A70 File Offset: 0x00013C70
		private void Subscribe(object state)
		{
			OrionCoreNotificationSubscriber.log.Debug("Subscribing indications..");
			try
			{
				this.DeleteOldSubscriptions();
			}
			catch (Exception ex)
			{
				OrionCoreNotificationSubscriber.log.Warn("Exception deleting old subscriptions:", ex);
			}
			try
			{
				SubscriberConfiguration subscriberConfiguration = new SubscriberConfiguration
				{
					SubscriptionQuery = "SUBSCRIBE System.InstanceDeleted"
				};
				SubscriptionId subscriptionId;
				subscriptionId..ctor("Core", typeof(OrionCoreNotificationSubscriber).FullName, 0);
				this._subscription = this._subscriptionManager.Subscribe(subscriptionId, this, subscriberConfiguration);
				if (OrionCoreNotificationSubscriber.log.IsDebugEnabled)
				{
					OrionCoreNotificationSubscriber.log.DebugFormat("PubSub Subscription succeeded. ID:'{0}'", this._subscription.Id);
				}
				Scheduler.Instance.Remove("OrionCoreIndications");
			}
			catch (Exception ex2)
			{
				OrionCoreNotificationSubscriber.log.Error("Subscription did not succeed, retrying .. (Is SWIS v3 running ?)", ex2);
			}
		}

		// Token: 0x06000370 RID: 880 RVA: 0x00015B54 File Offset: 0x00013D54
		private void InsertIntoDeletedTable(int nodeId)
		{
			using (SqlCommand textCommand = this._sqlHelper.GetTextCommand("IF NOT EXISTS (SELECT NodeId FROM [dbo].[DeletedNodes] WHERE NodeId=@NodeId)  BEGIN   INSERT INTO [dbo].[DeletedNodes](NodeId)    VALUES(@NodeId)  END "))
			{
				textCommand.Parameters.AddWithValue("@NodeId", nodeId);
				this._sqlHelper.ExecuteNonQuery(textCommand);
			}
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00015BB4 File Offset: 0x00013DB4
		private void DeleteOldSubscriptions()
		{
			if (this._subscription != null)
			{
				this._subscriptionManager.Unsubscribe(this._subscription.Id);
			}
		}

		// Token: 0x040000B2 RID: 178
		public const string OrionCoreIndications = "OrionCoreIndications";

		// Token: 0x040000B3 RID: 179
		public const string NodeIndications = "NodeIndications";

		// Token: 0x040000B4 RID: 180
		private static readonly Log log = new Log(typeof(OrionCoreNotificationSubscriber));

		// Token: 0x040000B5 RID: 181
		private readonly ISqlHelper _sqlHelper;

		// Token: 0x040000B6 RID: 182
		private readonly ISubscriptionManager _subscriptionManager;

		// Token: 0x040000B7 RID: 183
		private ISubscription _subscription;
	}
}
