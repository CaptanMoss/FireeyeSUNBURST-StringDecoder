﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using SolarWinds.InformationService.Contract2;
using SolarWinds.InformationService.Contract2.PubSub;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Interfaces;

namespace SolarWinds.Orion.Core.BusinessLayer.InformationService
{
	// Token: 0x02000058 RID: 88
	internal class InformationServiceSubscriptionProvider : IInformationServiceSubscriptionProvider
	{
		// Token: 0x0600051C RID: 1308 RVA: 0x000214E0 File Offset: 0x0001F6E0
		private InformationServiceSubscriptionProvider(Func<string, InfoServiceProxy> proxyFactory, string netObjectOperationEndpoint)
		{
			if (!RegistrySettings.IsFullOrion())
			{
				throw new InvalidOperationException("Subscription of Indications on non primary poller.");
			}
			if (string.IsNullOrEmpty(netObjectOperationEndpoint))
			{
				throw new ArgumentException("netObjectOperationEndpoint");
			}
			this.netObjectOperationEndpoint = netObjectOperationEndpoint;
			this.swisProxy = proxyFactory("localhost");
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x00021546 File Offset: 0x0001F746
		internal static InformationServiceSubscriptionProvider CreateV3()
		{
			return new InformationServiceSubscriptionProvider(new Func<string, InfoServiceProxy>(InformationServiceConnectionProvider.CreateProxyForCertificateV3), "net.tcp://localhost:17777/Orion/Core/BusinessLayer/OperationSubscriber");
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x0002155E File Offset: 0x0001F75E
		public static InformationServiceSubscriptionProvider CreateV3(string netObjectOperationEndpoint)
		{
			return new InformationServiceSubscriptionProvider(new Func<string, InfoServiceProxy>(InformationServiceConnectionProvider.CreateProxyForCertificateV3), netObjectOperationEndpoint);
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x00021574 File Offset: 0x0001F774
		public string Subscribe(string subscribeQuery, INotificationSubscriber notificationSubscriber)
		{
			if (string.IsNullOrEmpty(subscribeQuery))
			{
				throw new ArgumentException("subscribeQuery");
			}
			if (notificationSubscriber == null)
			{
				throw new ArgumentNullException("notificationSubscriber");
			}
			ServiceHost serviceHost = new ServiceHost(notificationSubscriber, Array.Empty<Uri>());
			serviceHost.AddServiceEndpoint(typeof(INotificationSubscriber), new NetTcpBinding
			{
				PortSharingEnabled = true
			}, this.netObjectOperationEndpoint);
			serviceHost.Open();
			PropertyBag propertyBag = new PropertyBag();
			propertyBag.Add("Query", subscribeQuery);
			propertyBag.Add("EndpointAddress", this.netObjectOperationEndpoint);
			PropertyBag propertyBag2 = propertyBag;
			string text = this.swisProxy.Create("System.Subscription", propertyBag2);
			this.subscriptionUriList.Add(text);
			this.log.DebugFormat("Swis subscribed with subscriptionUri: {0}", text);
			this.log.DebugFormat("Swis subscribed with query: {0}", subscribeQuery);
			return text;
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x00021639 File Offset: 0x0001F839
		public void Unsubscribe(string subscriptionUri)
		{
			this.swisProxy.Delete(subscriptionUri);
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x00021647 File Offset: 0x0001F847
		public void UnsubscribeAll()
		{
			this.swisProxy.BulkDelete(this.subscriptionUriList.ToArray());
		}

		// Token: 0x0400016E RID: 366
		private readonly Log log = new Log();

		// Token: 0x0400016F RID: 367
		private readonly InfoServiceProxy swisProxy;

		// Token: 0x04000170 RID: 368
		private readonly string netObjectOperationEndpoint;

		// Token: 0x04000171 RID: 369
		private readonly List<string> subscriptionUriList = new List<string>();

		// Token: 0x04000172 RID: 370
		private const string SubscriptionEntity = "System.Subscription";
	}
}
