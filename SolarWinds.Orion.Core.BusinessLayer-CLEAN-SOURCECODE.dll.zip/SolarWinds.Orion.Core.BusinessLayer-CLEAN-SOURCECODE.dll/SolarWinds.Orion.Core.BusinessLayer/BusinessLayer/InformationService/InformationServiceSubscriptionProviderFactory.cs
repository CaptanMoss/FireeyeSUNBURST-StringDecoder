﻿using System;
using SolarWinds.Orion.Core.Common.Interfaces;

namespace SolarWinds.Orion.Core.BusinessLayer.InformationService
{
	// Token: 0x02000059 RID: 89
	public class InformationServiceSubscriptionProviderFactory
	{
		// Token: 0x06000522 RID: 1314 RVA: 0x0002165F File Offset: 0x0001F85F
		public static IInformationServiceSubscriptionProvider GetInformationServiceSubscriptionProviderFactoryV3(string netObjectOperationEndpoint)
		{
			return InformationServiceSubscriptionProvider.CreateV3(netObjectOperationEndpoint);
		}
	}
}
