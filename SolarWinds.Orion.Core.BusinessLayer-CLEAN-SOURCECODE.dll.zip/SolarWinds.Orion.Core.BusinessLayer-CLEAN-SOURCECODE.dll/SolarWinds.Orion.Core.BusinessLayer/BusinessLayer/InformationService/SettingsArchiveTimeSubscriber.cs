﻿using System;
using System.Threading.Tasks;
using SolarWinds.Common.Utility;
using SolarWinds.Logging;
using SolarWinds.Orion.PubSub;

namespace SolarWinds.Orion.Core.BusinessLayer.InformationService
{
	// Token: 0x0200005A RID: 90
	internal class SettingsArchiveTimeSubscriber : ISubscriber
	{
		// Token: 0x06000524 RID: 1316 RVA: 0x00021667 File Offset: 0x0001F867
		public SettingsArchiveTimeSubscriber(ScheduledTaskInExactTime task)
		{
			if (task == null)
			{
				throw new ArgumentNullException("task");
			}
			this.task = task;
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x00021690 File Offset: 0x0001F890
		public Task OnNotificationAsync(Notification notification)
		{
			try
			{
				this.task.ExactRunTime = DateTime.FromOADate(double.Parse(notification.SourceInstanceProperties["CurrentValue"].ToString()));
			}
			catch (Exception ex)
			{
				this.log.Error("Error when getting Archive time from SWIS.", ex);
			}
			return Task.CompletedTask;
		}

		// Token: 0x04000173 RID: 371
		private readonly Log log = new Log();

		// Token: 0x04000174 RID: 372
		private readonly ScheduledTaskInExactTime task;
	}
}
