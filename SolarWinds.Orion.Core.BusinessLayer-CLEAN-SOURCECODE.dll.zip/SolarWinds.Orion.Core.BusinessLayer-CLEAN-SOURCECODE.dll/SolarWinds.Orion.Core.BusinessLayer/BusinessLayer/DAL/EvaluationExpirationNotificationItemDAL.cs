﻿using System;
using System.Collections.Generic;
using System.Linq;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000090 RID: 144
	internal sealed class EvaluationExpirationNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x060006DA RID: 1754 RVA: 0x0002BAA8 File Offset: 0x00029CA8
		public static EvaluationExpirationNotificationItemDAL GetItem()
		{
			return NotificationItemDAL.GetItemById<EvaluationExpirationNotificationItemDAL>(EvaluationExpirationNotificationItemDAL.EvaluationExpirationNotificationItemId);
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x0002BAB4 File Offset: 0x00029CB4
		public void Show(IEnumerable<ModuleLicenseInfo> expiringModules)
		{
			if (expiringModules == null)
			{
				throw new ArgumentNullException("expiringModules");
			}
			Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> dictionary = new Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>();
			foreach (ModuleLicenseInfo moduleLicenseInfo in expiringModules)
			{
				dictionary[moduleLicenseInfo.ModuleName] = new EvaluationExpirationNotificationItemDAL.ExpirationInfo
				{
					ModuleName = moduleLicenseInfo.ModuleName,
					LastRemindMeLater = null,
					DaysToExpire = moduleLicenseInfo.DaysRemaining
				};
			}
			this.Show(dictionary);
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x0002BB48 File Offset: 0x00029D48
		private void Show(IDictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> expirations)
		{
			EvaluationExpirationNotificationItemDAL item = EvaluationExpirationNotificationItemDAL.GetItem();
			if (item == null)
			{
				string description = EvaluationExpirationNotificationItemDAL.Serialize(expirations);
				NotificationItemDAL.Insert(EvaluationExpirationNotificationItemDAL.EvaluationExpirationNotificationItemId, EvaluationExpirationNotificationItemDAL.EvaluationExpirationNotificationTypeGuid, Resources.LIBCODE_LC0_1, description, false, "javascript:SW.Core.SalesTrigger.ShowEvalPopupAsync();", null, null);
				return;
			}
			Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> previousExpirations = EvaluationExpirationNotificationItemDAL.Deserialize(item.Description);
			int showExpiredAgainAt = BusinessLayerSettings.Instance.EvaluationExpirationShowAgainAtDays;
			IEnumerable<KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>> previousExpirations2 = previousExpirations;
			Func<KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>, bool> <>9__1;
			Func<KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>, bool> predicate;
			if ((predicate = <>9__1) == null)
			{
				predicate = (<>9__1 = ((KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> previousExpiration) => expirations.ContainsKey(previousExpiration.Key)));
			}
			foreach (KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> keyValuePair in previousExpirations2.Where(predicate))
			{
				expirations[keyValuePair.Key].LastRemindMeLater = keyValuePair.Value.LastRemindMeLater;
			}
			int daysFromLastRemindMeLater = (int)DateTime.UtcNow.Subtract(item.AcknowledgedAt ?? DateTime.UtcNow).TotalDays;
			DateTime? acknowledgedAt = item.AcknowledgedAt;
			if (expirations.Any((KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> module) => !previousExpirations.ContainsKey(module.Key) || (previousExpirations.ContainsKey(module.Key) && module.Value.DaysToExpire > 0 && daysFromLastRemindMeLater == showExpiredAgainAt) || (previousExpirations.ContainsKey(module.Key) && previousExpirations[module.Key].DaysToExpire > 0 && module.Value.DaysToExpire <= 0) || (int)DateTime.UtcNow.Subtract(module.Value.LastRemindMeLater ?? DateTime.UtcNow).TotalDays == showExpiredAgainAt))
			{
				item.SetNotAcknowledged();
			}
			if (acknowledgedAt != null)
			{
				IEnumerable<KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>> expirations2 = expirations;
				Func<KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>, bool> <>9__2;
				Func<KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>, bool> predicate2;
				if ((predicate2 = <>9__2) == null)
				{
					predicate2 = (<>9__2 = ((KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> m) => m.Value.DaysToExpire <= 0 && m.Value.LastRemindMeLater == null && previousExpirations.ContainsKey(m.Key) && previousExpirations[m.Key].DaysToExpire <= 0));
				}
				foreach (KeyValuePair<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> keyValuePair2 in expirations2.Where(predicate2))
				{
					keyValuePair2.Value.LastRemindMeLater = acknowledgedAt;
				}
			}
			item.TypeId = EvaluationExpirationNotificationItemDAL.EvaluationExpirationNotificationTypeGuid;
			item.Description = EvaluationExpirationNotificationItemDAL.Serialize(expirations);
			item.Url = "javascript:SW.Core.SalesTrigger.ShowEvalPopupAsync();";
			item.Title = Resources.LIBCODE_LC0_1;
			item.Update();
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x0002BD5C File Offset: 0x00029F5C
		public void Hide()
		{
			NotificationItemDAL.Delete(EvaluationExpirationNotificationItemDAL.EvaluationExpirationNotificationItemId);
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x0002BD6C File Offset: 0x00029F6C
		public void CheckEvaluationExpiration()
		{
			ILicensingDAL licensing = new LicensingDAL();
			List<LicenseInfoModel> list = (from license in licensing.GetLicenses()
			where license.IsEvaluation && (license.IsExpired || license.DaysRemainingCount <= BusinessLayerSettings.Instance.EvaluationExpirationNotificationDays) && !string.Equals("DPI", license.ProductName, StringComparison.OrdinalIgnoreCase)
			select license).ToList<LicenseInfoModel>();
			licensing.FilterHiddenEvalLicenses(list);
			if (list.All((LicenseInfoModel lic) => licensing.DefaultLicenseFilter.Any((string module) => string.Equals(module, lic.ProductName, StringComparison.OrdinalIgnoreCase))))
			{
				this.Hide();
				return;
			}
			Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> dictionary = new Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>();
			foreach (LicenseInfoModel licenseInfoModel in list)
			{
				dictionary[licenseInfoModel.LicenseName] = new EvaluationExpirationNotificationItemDAL.ExpirationInfo
				{
					ModuleName = licenseInfoModel.LicenseName,
					LastRemindMeLater = null,
					DaysToExpire = licenseInfoModel.DaysRemainingCount
				};
			}
			this.Show(dictionary);
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x0002BE6C File Offset: 0x0002A06C
		private static string Serialize(IDictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> moduleExpirations)
		{
			return string.Join("|", (from m in moduleExpirations
			select string.Format("{0};{1};{2};{3}", new object[]
			{
				m.Key,
				m.Value.DaysToExpire,
				m.Value.ModuleName,
				m.Value.LastRemindMeLater
			})).ToArray<string>());
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x0002BEA4 File Offset: 0x0002A0A4
		private static Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> Deserialize(string moduleExpirations)
		{
			Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo> dictionary = new Dictionary<string, EvaluationExpirationNotificationItemDAL.ExpirationInfo>();
			if (!string.IsNullOrEmpty(moduleExpirations))
			{
				foreach (string text in moduleExpirations.Split(new char[]
				{
					'|'
				}))
				{
					try
					{
						string[] array2 = text.Split(new char[]
						{
							';'
						});
						EvaluationExpirationNotificationItemDAL.ExpirationInfo expirationInfo = new EvaluationExpirationNotificationItemDAL.ExpirationInfo();
						expirationInfo.DaysToExpire = Convert.ToInt32(array2[1]);
						if (array2.Length > 2 && !string.IsNullOrWhiteSpace(array2[2]))
						{
							expirationInfo.ModuleName = array2[2];
						}
						if (array2.Length > 3 && !string.IsNullOrWhiteSpace(array2[3]))
						{
							expirationInfo.LastRemindMeLater = new DateTime?(DateTime.Parse(array2[3]));
						}
						dictionary[array2[0]] = expirationInfo;
					}
					catch (Exception ex)
					{
						NotificationItemDAL.log.Warn("Unable to parse evaluation expiration notification panel data", ex);
					}
				}
			}
			return dictionary;
		}

		// Token: 0x04000229 RID: 553
		public static readonly Guid EvaluationExpirationNotificationItemId = new Guid("{AFA69A0B-2313-48C6-A8EA-BF6A0A256A1C}");

		// Token: 0x0400022A RID: 554
		public static readonly Guid EvaluationExpirationNotificationTypeGuid = new Guid("{6EE3D05F-7555-4E3E-9338-AA338834FE36}");

		// Token: 0x02000183 RID: 387
		private class ExpirationInfo
		{
			// Token: 0x1700015F RID: 351
			// (get) Token: 0x06000C37 RID: 3127 RVA: 0x0004B0DB File Offset: 0x000492DB
			// (set) Token: 0x06000C38 RID: 3128 RVA: 0x0004B0E3 File Offset: 0x000492E3
			public string ModuleName { get; set; }

			// Token: 0x17000160 RID: 352
			// (get) Token: 0x06000C39 RID: 3129 RVA: 0x0004B0EC File Offset: 0x000492EC
			// (set) Token: 0x06000C3A RID: 3130 RVA: 0x0004B0F4 File Offset: 0x000492F4
			public DateTime? LastRemindMeLater { get; set; }

			// Token: 0x17000161 RID: 353
			// (get) Token: 0x06000C3B RID: 3131 RVA: 0x0004B0FD File Offset: 0x000492FD
			// (set) Token: 0x06000C3C RID: 3132 RVA: 0x0004B105 File Offset: 0x00049305
			public int DaysToExpire { get; set; }
		}
	}
}
