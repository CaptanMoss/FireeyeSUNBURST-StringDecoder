﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using SolarWinds.InformationService.Contract2;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Alerting.DAL;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Federation;
using SolarWinds.Orion.Core.Common.Indications;
using SolarWinds.Orion.Core.Common.InformationService;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Common.Models.Alerts;
using SolarWinds.Orion.Core.Common.Notification;
using SolarWinds.Orion.Core.Common.Swis;
using SolarWinds.Orion.Core.Models.Alerting;
using SolarWinds.Orion.Core.Strings;
using SolarWinds.Shared;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x0200008B RID: 139
	public class ActiveAlertDAL
	{
		// Token: 0x06000697 RID: 1687 RVA: 0x0002776C File Offset: 0x0002596C
		public ActiveAlertDAL() : this(SwisConnectionProxyPool.GetCreator())
		{
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x00027779 File Offset: 0x00025979
		public ActiveAlertDAL(IInformationServiceProxyCreator swisProxyCreator) : this(swisProxyCreator, new AlertHistoryDAL(swisProxyCreator))
		{
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x00027788 File Offset: 0x00025988
		public ActiveAlertDAL(IInformationServiceProxyCreator swisProxyCreator, IAlertHistoryDAL alertHistoryDAL)
		{
			this._swisProxyCreator = swisProxyCreator;
			this._alertHistoryDAL = alertHistoryDAL;
			this._alertPropertiesProvider = new Lazy<AlertObjectPropertiesProvider>(() => new AlertObjectPropertiesProvider(swisProxyCreator));
			StatusInfo.Init(new DefaultStatusInfoProvider(), ActiveAlertDAL.log);
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x000277E4 File Offset: 0x000259E4
		public int AcknowledgeActiveAlerts(IEnumerable<int> alertObjectIds, string accountId, string notes, DateTime acknowledgeDateTime)
		{
			if (!alertObjectIds.Any<int>())
			{
				return 0;
			}
			int result = 0;
			bool flag = !string.IsNullOrEmpty(notes);
			string format = "UPDATE AlertObjects SET AlertNote = CASE WHEN (AlertNote IS NULL) THEN @alertNote ELSE AlertNote + CHAR(13) + CHAR(10) + @alertNote END WHERE AlertObjectId IN ({0})";
			string text = "UPDATE AlertActive SET Acknowledged=1, AcknowledgedBy=@acknowledgedBy, AcknowledgedDateTime=@acknowledgedDateTime";
			text += " WHERE AlertObjectID IN ({0})";
			string text2 = string.Empty;
			int num = 0;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand(text))
			{
				foreach (int num2 in alertObjectIds)
				{
					string text3 = string.Format("@alertObjectID{0}", num++);
					if (!string.IsNullOrEmpty(text2))
					{
						text2 += ",";
					}
					if (num < 1000)
					{
						textCommand.Parameters.AddWithValue(text3, num2);
						text2 += text3;
					}
					else
					{
						text2 += num2;
					}
				}
				textCommand.Parameters.AddWithValue("@acknowledgedBy", accountId);
				textCommand.Parameters.AddWithValue("@acknowledgedDateTime", acknowledgeDateTime.ToUniversalTime());
				using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
				{
					using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction(IsolationLevel.ReadCommitted))
					{
						textCommand.CommandText = string.Format(text, text2);
						SqlHelper.ExecuteNonQuery(textCommand, sqlConnection, sqlTransaction);
						if (flag)
						{
							textCommand.Parameters.AddWithValue("@alertNote", notes);
							textCommand.CommandText = string.Format(format, text2);
							SqlHelper.ExecuteNonQuery(textCommand, sqlConnection, sqlTransaction);
						}
						textCommand.CommandText = string.Format("SELECT AlertObjectID, AlertActiveID FROM AlertActive WHERE AlertObjectID IN ({0})", text2);
						DataTable dataTable = SqlHelper.ExecuteDataTable(textCommand, sqlConnection, null);
						result = dataTable.Rows.Count;
						foreach (object obj in dataTable.Rows)
						{
							DataRow dataRow = (DataRow)obj;
							AlertHistory alertHistory = new AlertHistory();
							alertHistory.EventType = 2;
							alertHistory.AccountID = accountId;
							alertHistory.Message = notes;
							alertHistory.TimeStamp = acknowledgeDateTime.ToUniversalTime();
							int num3 = (dataRow["AlertObjectID"] != DBNull.Value) ? Convert.ToInt32(dataRow["AlertObjectID"]) : 0;
							long num4 = (dataRow["AlertActiveID"] != DBNull.Value) ? Convert.ToInt64(dataRow["AlertActiveID"]) : 0L;
							this._alertHistoryDAL.InsertHistoryItem(alertHistory, num4, num3, sqlConnection, sqlTransaction);
						}
						sqlTransaction.Commit();
					}
				}
			}
			return result;
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x00027B04 File Offset: 0x00025D04
		public static bool UnacknowledgeAlerts(int[] alertObjectIds, string accountId)
		{
			bool result = true;
			for (int i = 0; i < alertObjectIds.Length; i++)
			{
				if (!ActiveAlertDAL.UnacknowledgeAlert(alertObjectIds[i], accountId))
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00027B34 File Offset: 0x00025D34
		private static bool UnacknowledgeAlert(int alertObjectId, string accountId)
		{
			string text = "UPDATE AlertActive SET Acknowledged= null, \r\n                                     AcknowledgedBy=null, \r\n                                     AcknowledgedDateTime = null\r\n                                     WHERE [AlertObjectID] = @alertObjectId";
			AlertHistoryDAL alertHistoryDAL = new AlertHistoryDAL();
			int num = -1;
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlCommand textCommand = SqlHelper.GetTextCommand(text))
				{
					using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction(IsolationLevel.ReadCommitted))
					{
						textCommand.Parameters.AddWithValue("@alertObjectId", alertObjectId);
						num = SqlHelper.ExecuteNonQuery(textCommand, sqlConnection, sqlTransaction);
						textCommand.CommandText = "SELECT AlertObjectID, AlertActiveID FROM AlertActive WHERE [AlertObjectID] = @alertObjectId";
						foreach (object obj in SqlHelper.ExecuteDataTable(textCommand, sqlConnection, null).Rows)
						{
							DataRow dataRow = (DataRow)obj;
							int num2 = (dataRow["AlertObjectID"] != DBNull.Value) ? Convert.ToInt32(dataRow["AlertObjectID"]) : 0;
							long num3 = (dataRow["AlertActiveID"] != DBNull.Value) ? Convert.ToInt64(dataRow["AlertActiveID"]) : 0L;
							alertHistoryDAL.InsertHistoryItem(new AlertHistory
							{
								EventType = 7,
								AccountID = accountId,
								TimeStamp = DateTime.UtcNow
							}, num3, num2, sqlConnection, sqlTransaction);
						}
						sqlTransaction.Commit();
					}
				}
			}
			return num == 1;
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x00027D00 File Offset: 0x00025F00
		private string GetActiveAlertQuery(IEnumerable<CustomProperty> customProperties, bool includeNotTriggered = false)
		{
			string text = string.Empty;
			if (customProperties != null)
			{
				StringBuilder stringBuilder = new StringBuilder();
				foreach (CustomProperty customProperty in customProperties)
				{
					stringBuilder.AppendFormat(", AlertConfigurations.CustomProperties.[{0}]", customProperty.PropertyName);
				}
				text = stringBuilder.ToString();
			}
			string arg = "CASE WHEN IsNull(AlertObjects.EntityCaption,'') <> '' AND IsNull(AlertObjects.RelatedNodeCaption, '') <> '' AND IsNull(AlertObjects.EntityType, '') <> 'Orion.Nodes'\r\n                                                                        THEN CONCAT(AlertObjects.EntityCaption, '" + Resources.TriggeringObjectOnNode + "', AlertObjects.RelatedNodeCaption) \r\n                                                                        ELSE CASE WHEN IsNull(AlertObjects.EntityCaption,'') <> '' THEN AlertObjects.EntityCaption ELSE AlertObjects.RelatedNodeCaption END\r\n                                                                       END AS ObjectTriggeredThisAlertDisplayName";
			string text2 = " SELECT DISTINCT OrionSite.SiteID, OrionSite.Name AS SiteName,\r\n                                 Data.AlertActiveID, Data.AlertObjectID, Data.Name,\r\n                                Data.AlertConfigurationMessage, Data.Severity, Data.ObjectType, Data.ObjectTriggeredThisAlertDisplayName,\r\n                                Data.EntityUri, Data.EntityType, Data.EntityCaption, Data.EntityDetailsUrl,\r\n                                Data.RelatedNodeUri, Data.RelatedNodeDetailsUrl, Data.RelatedNodeCaption, Data.AlertID, \r\n                                Data.TriggeredDateTime, Data.LastTriggeredDateTime, Data.Message, Data.AccountID, \r\n                                Data.LastExecutedEscalationLevel, Data.AcknowledgedDateTime, Data.Acknowledged, Data.AcknowledgedBy, Data.NumberOfNotes, \r\n                                Data.TriggeredCount, Data.AcknowledgedNote, Data.Canned, Data.Category {1},\r\n                                '' AS IncidentNumber, '' AS IncidentUrl, '' AS AssignedTo\r\n                                FROM (\r\n\r\n                                SELECT AlertActive.InstanceSiteID, AlertActive.InstanceSiteID AS SiteID, AlertActive.AlertActiveID, AlertObjects.AlertObjectID, AlertObjects.AlertObjectID AS ActiveAlertID, AlertConfigurations.Name, AlertConfigurations.Name AS AlertName,\r\n                                AlertConfigurations.AlertMessage AS AlertConfigurationMessage, AlertConfigurations.Severity, AlertConfigurations.Severity AS SeverityOrder, AlertConfigurations.ObjectType,\r\n                                AlertObjects.EntityUri, AlertObjects.EntityUri AS TriggeringObjectEntityUri, AlertObjects.EntityType, AlertObjects.EntityType AS TriggeringObjectEntityName, AlertObjects.EntityCaption, AlertObjects.EntityDetailsUrl,\r\n                                AlertObjects.RelatedNodeUri, AlertObjects.RelatedNodeUri AS RelatedNodeEntityUri, AlertObjects.RelatedNodeDetailsUrl, \r\n                                AlertObjects.RelatedNodeCaption, AlertObjects.RelatedNodeCaption AS RelatedNode, AlertObjects.AlertID, AlertObjects.AlertID AS AlertDefId, \r\n                                AlertActive.TriggeredDateTime, AlertActive.TriggeredDateTime AS TriggerTime,\r\n                                SecondDiff(AlertActive.TriggeredDateTime, getUtcDate()) AS ActiveTimeDisplay, SecondDiff(AlertActive.TriggeredDateTime, getUtcDate()) AS ActiveTimeSort,\r\n                                AlertObjects.LastTriggeredDateTime, AlertActive.TriggeredMessage AS Message,\r\n                                AlertActive.TriggeredMessage AS AlertMessage, AlertActive.AcknowledgedBy AS AccountID, \r\n                                AlertActive.LastExecutedEscalationLevel, AlertActive.AcknowledgedDateTime, AlertActive.AcknowledgedDateTime AS AcknowledgeTime, AlertActive.Acknowledged, AlertActive.AcknowledgedBy, AlertActive.NumberOfNotes, {2},\r\n                                AlertObjects.TriggeredCount, AlertObjects.TriggeredCount AS TriggerCount, AlertObjects.AlertNote as AcknowledgedNote, AlertObjects.AlertNote as Notes, AlertConfigurations.Canned, AlertConfigurations.Category {0}\r\n                                FROM Orion.AlertObjects AlertObjects";
			if (includeNotTriggered)
			{
				text2 += " LEFT JOIN Orion.AlertActive (nolock=true) AlertActive ON AlertObjects.AlertObjectID=AlertActive.AlertObjectID AND AlertObjects.InstanceSiteID=AlertActive.InstanceSiteID";
			}
			else
			{
				text2 += " INNER JOIN Orion.AlertActive (nolock=true) AlertActive ON AlertObjects.AlertObjectID=AlertActive.AlertObjectID AND AlertObjects.InstanceSiteID=AlertActive.InstanceSiteID";
			}
			text2 += " INNER JOIN Orion.AlertConfigurations (nolock=true) AlertConfigurations ON AlertConfigurations.AlertID=AlertObjects.AlertID AND AlertConfigurations.InstanceSiteID=AlertObjects.InstanceSiteID";
			text2 += ") AS Data";
			text2 += " LEFT JOIN Orion.Sites AS OrionSite ON OrionSite.SiteID=Data.InstanceSiteID";
			return string.Format(text2, text, text.Replace("AlertConfigurations.CustomProperties", "Data"), arg);
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x00027DE8 File Offset: 0x00025FE8
		private string GetActiveAlertTableByDateQuery()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("SELECT AlertHistory.AlertHistoryID, AlertHistory.TimeStamp, AlertObjects.AlertID, AlertObjects.EntityCaption, AlertActive.AlertObjectID, AlertActive.AlertActiveID, AlertActive.Acknowledged, AlertActive.AcknowledgedBy, AlertActive.AcknowledgedDateTime, AlertConfigurations.ObjectType,");
			stringBuilder.Append(" AlertConfigurations.Name, AlertConfigurations.AlertMessage, AlertConfigurations.AlertRefID, AlertConfigurations.Description, AlertObjects.EntityType, AlertObjects.EntityDetailsUrl, AlertActive.TriggeredDateTime, AlertObjects.EntityUri, AlertActiveObjects.EntityUri as ActiveObjectEntityUri, AlertObjects.RelatedNodeUri,");
			stringBuilder.Append(" Actions.ActionTypeID, AlertConfigurations.LastEdit, AlertConfigurations.Severity, ActionsProperties.PropertyName, ActionsProperties.PropertyValue, AlertActive.AcknowledgedNote, AlertConfigurations.Canned, AlertConfigurations.Category ");
			stringBuilder.Append(" FROM Orion.AlertObjects AlertObjects");
			stringBuilder.Append(" LEFT JOIN Orion.AlertActive (nolock=true) AlertActive ON AlertObjects.AlertObjectID=AlertActive.AlertObjectID");
			stringBuilder.Append(" INNER JOIN Orion.AlertHistory (nolock=true) AlertHistory ON AlertObjects.AlertObjectID=AlertHistory.AlertObjectID");
			stringBuilder.Append(" INNER JOIN Orion.Actions (nolock=true) Actions ON AlertHistory.ActionID = Actions.ActionID");
			stringBuilder.Append(" INNER JOIN Orion.ActionsProperties (nolock=true) ActionsProperties ON Actions.ActionID = ActionsProperties.ActionID");
			stringBuilder.Append(" INNER JOIN Orion.AlertConfigurations (nolock=true) AlertConfigurations ON AlertConfigurations.AlertID=AlertObjects.AlertID");
			stringBuilder.Append(" LEFT JOIN Orion.AlertActiveObjects (nolock=true) AlertActiveObjects ON AlertActiveObjects.AlertActiveID=AlertActive.AlertActiveID");
			stringBuilder.Append(" WHERE Actions.ActionTypeID IN ('PlaySound', 'TextToSpeech') AND ActionsProperties.PropertyName IN ('Message', 'Text') AND (AlertActive.Acknowledged IS NULL OR AlertActive.Acknowledged = false)");
			return stringBuilder.ToString();
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x00027E84 File Offset: 0x00026084
		private ActiveAlert GetActiveAlertFromDataRow(DataRow rActiveAlert, IEnumerable<CustomProperty> customProperties)
		{
			ActiveAlert activeAlert = new ActiveAlert();
			activeAlert.CustomProperties = new Dictionary<string, object>();
			activeAlert.TriggeringObjectEntityUri = ((rActiveAlert["EntityUri"] != DBNull.Value) ? Convert.ToString(rActiveAlert["EntityUri"]) : string.Empty);
			activeAlert.SiteID = ((rActiveAlert["SiteID"] != DBNull.Value) ? Convert.ToInt32(rActiveAlert["SiteID"]) : -1);
			activeAlert.SiteName = ((rActiveAlert["SiteName"] != DBNull.Value) ? Convert.ToString(rActiveAlert["SiteName"]) : string.Empty);
			string linkPrefix = FederationUrlHelper.GetLinkPrefix(activeAlert.SiteID);
			activeAlert.TriggerDateTime = ((rActiveAlert["TriggeredDateTime"] != DBNull.Value) ? DateTime.SpecifyKind(Convert.ToDateTime(rActiveAlert["TriggeredDateTime"]), DateTimeKind.Utc).ToLocalTime() : DateTime.MinValue);
			activeAlert.ActiveTime = DateTime.Now - activeAlert.TriggerDateTime;
			activeAlert.LastTriggeredDateTime = ((rActiveAlert["LastTriggeredDateTime"] != DBNull.Value) ? Convert.ToDateTime(rActiveAlert["LastTriggeredDateTime"]).ToLocalTime() : DateTime.MinValue);
			activeAlert.ActiveTimeDisplay = this.ActiveTimeToDisplayFormat(activeAlert.ActiveTime);
			activeAlert.TriggeringObjectCaption = ((rActiveAlert["EntityCaption"] != DBNull.Value) ? Convert.ToString(rActiveAlert["EntityCaption"]) : string.Empty);
			activeAlert.TriggeringObjectDetailsUrl = linkPrefix + ((rActiveAlert["EntityDetailsUrl"] != DBNull.Value) ? Convert.ToString(rActiveAlert["EntityDetailsUrl"]) : string.Empty);
			activeAlert.TriggeringObjectEntityName = ((rActiveAlert["EntityType"] != DBNull.Value) ? Convert.ToString(rActiveAlert["EntityType"]) : string.Empty);
			activeAlert.RelatedNodeCaption = ((rActiveAlert["RelatedNodeCaption"] != DBNull.Value) ? Convert.ToString(rActiveAlert["RelatedNodeCaption"]) : string.Empty);
			activeAlert.RelatedNodeDetailsUrl = linkPrefix + ((rActiveAlert["RelatedNodeDetailsUrl"] != DBNull.Value) ? Convert.ToString(rActiveAlert["RelatedNodeDetailsUrl"]) : string.Empty);
			activeAlert.RelatedNodeEntityUri = ((rActiveAlert["RelatedNodeUri"] != DBNull.Value) ? Convert.ToString(rActiveAlert["RelatedNodeUri"]) : string.Empty);
			activeAlert.ObjectTriggeredThisAlertDisplayName = ((rActiveAlert["ObjectTriggeredThisAlertDisplayName"] != DBNull.Value) ? Convert.ToString(rActiveAlert["ObjectTriggeredThisAlertDisplayName"]) : string.Empty);
			bool flag = rActiveAlert["Acknowledged"] != DBNull.Value && Convert.ToBoolean(rActiveAlert["Acknowledged"]);
			activeAlert.Canned = (rActiveAlert["Canned"] != DBNull.Value && Convert.ToBoolean(rActiveAlert["Canned"]));
			activeAlert.Category = ((rActiveAlert["Category"] != DBNull.Value) ? Convert.ToString(rActiveAlert["Category"]) : string.Empty);
			if (flag)
			{
				activeAlert.AcknowledgedBy = ((rActiveAlert["AcknowledgedBy"] != DBNull.Value) ? Convert.ToString(rActiveAlert["AcknowledgedBy"]) : string.Empty);
				activeAlert.AcknowledgedByFullName = activeAlert.AcknowledgedBy;
				activeAlert.AcknowledgedDateTime = ((rActiveAlert["AcknowledgedDateTime"] != DBNull.Value) ? DateTime.SpecifyKind(Convert.ToDateTime(rActiveAlert["AcknowledgedDateTime"]), DateTimeKind.Utc).ToLocalTime() : DateTime.MinValue);
				activeAlert.Notes = ((rActiveAlert["AcknowledgedNote"] != DBNull.Value) ? Convert.ToString(rActiveAlert["AcknowledgedNote"]) : string.Empty);
			}
			activeAlert.NumberOfNotes = ((rActiveAlert["NumberOfNotes"] != DBNull.Value) ? Convert.ToInt32(rActiveAlert["NumberOfNotes"]) : 0);
			activeAlert.Id = ((rActiveAlert["AlertObjectID"] != DBNull.Value) ? Convert.ToInt32(rActiveAlert["AlertObjectID"]) : 0);
			activeAlert.AlertDefId = ((rActiveAlert["AlertID"] != DBNull.Value) ? Convert.ToString(rActiveAlert["AlertID"]) : string.Empty);
			activeAlert.LegacyAlert = false;
			activeAlert.Message = ((rActiveAlert["Message"] != DBNull.Value) ? Convert.ToString(rActiveAlert["Message"]) : string.Empty);
			activeAlert.Name = ((rActiveAlert["Name"] != DBNull.Value) ? Convert.ToString(rActiveAlert["Name"]) : string.Empty);
			activeAlert.ObjectType = ((rActiveAlert["ObjectType"] != DBNull.Value) ? Convert.ToString(rActiveAlert["ObjectType"]) : string.Empty);
			activeAlert.Severity = ((rActiveAlert["Severity"] != DBNull.Value) ? Convert.ToInt32(rActiveAlert["Severity"]) : 1);
			activeAlert.TriggeringObjectEntityName = ((rActiveAlert["EntityType"] != DBNull.Value) ? Convert.ToString(rActiveAlert["EntityType"]) : string.Empty);
			activeAlert.TriggeringObjectCaption = ((rActiveAlert["EntityCaption"] != DBNull.Value) ? Convert.ToString(rActiveAlert["EntityCaption"]) : string.Empty);
			activeAlert.Status = ((rActiveAlert["AlertActiveID"] != DBNull.Value) ? 1 : 0);
			if (activeAlert.Status == null)
			{
				activeAlert.ActiveTimeDisplay = Resources.LIBCODE_PS0_11;
			}
			activeAlert.RelatedNodeEntityUri = ((rActiveAlert["RelatedNodeUri"] != DBNull.Value) ? Convert.ToString(rActiveAlert["RelatedNodeUri"]) : string.Empty);
			activeAlert.TriggerCount = ((rActiveAlert["TriggeredCount"] != DBNull.Value) ? Convert.ToInt32(rActiveAlert["TriggeredCount"]) : 0);
			activeAlert.EscalationLevel = ((rActiveAlert["LastExecutedEscalationLevel"] != DBNull.Value) ? Convert.ToInt32(rActiveAlert["LastExecutedEscalationLevel"]) : 0);
			activeAlert.IncidentNumber = ((rActiveAlert["IncidentNumber"] != DBNull.Value) ? Convert.ToString(rActiveAlert["IncidentNumber"]) : string.Empty);
			activeAlert.IncidentUrl = ((rActiveAlert["IncidentUrl"] != DBNull.Value) ? Convert.ToString(rActiveAlert["IncidentUrl"]) : string.Empty);
			activeAlert.AssignedTo = ((rActiveAlert["AssignedTo"] != DBNull.Value) ? Convert.ToString(rActiveAlert["AssignedTo"]) : string.Empty);
			this.FillCustomPropertiesFromRow(rActiveAlert, customProperties, activeAlert);
			return activeAlert;
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x00028540 File Offset: 0x00026740
		private void FillCustomPropertiesFromRow(DataRow rActiveAlert, IEnumerable<CustomProperty> customProperties, ActiveAlert activeAlert)
		{
			foreach (CustomProperty customProperty in customProperties)
			{
				object value = null;
				if (rActiveAlert[customProperty.PropertyName] != DBNull.Value)
				{
					if (customProperty.PropertyType == typeof(string))
					{
						value = Convert.ToString(rActiveAlert[customProperty.PropertyName]);
					}
					else if (customProperty.PropertyType == typeof(DateTime))
					{
						value = DateTime.SpecifyKind(Convert.ToDateTime(rActiveAlert[customProperty.PropertyName]), DateTimeKind.Local);
					}
					else if (customProperty.PropertyType == typeof(int))
					{
						value = Convert.ToInt32(rActiveAlert[customProperty.PropertyName]);
					}
					else if (customProperty.PropertyType == typeof(float))
					{
						value = Convert.ToSingle(rActiveAlert[customProperty.PropertyName]);
					}
					else if (customProperty.PropertyType == typeof(bool))
					{
						value = Convert.ToBoolean(rActiveAlert[customProperty.PropertyName]);
					}
				}
				activeAlert.CustomProperties.Add(customProperty.PropertyName, value);
			}
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x000286B4 File Offset: 0x000268B4
		private int GetAlertObjectIdByAlertActiveId(long alertActiveId)
		{
			int result = 0;
			string text = "SELECT TOP 1 AlertObjectID FROM Orion.AlertHistory (nolock=true) WHERE AlertActiveID=@alertActiveID";
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				DataTable dataTable = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, text, new Dictionary<string, object>
				{
					{
						"alertActiveID",
						alertActiveId
					}
				});
				if (dataTable.Rows.Count > 0)
				{
					result = ((dataTable.Rows[0]["AlertObjectID"] != DBNull.Value) ? Convert.ToInt32(dataTable.Rows[0]["AlertObjectID"]) : 0);
				}
			}
			return result;
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0002875C File Offset: 0x0002695C
		private ActiveAlertStatus GetTriggeredStatusForActiveAlert(int alertObjectId)
		{
			if (!SqlHelper.ExecuteExistsParams("SELECT AlertActiveID FROM dbo.AlertActive WITH(NOLOCK) WHERE AlertObjectID=@alertObjectId", new SqlParameter[]
			{
				new SqlParameter("@alertObjectId", alertObjectId)
			}))
			{
				return 0;
			}
			return 1;
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x00028786 File Offset: 0x00026986
		internal DataTable GetAlertResetOrUpdateNotificationPropertiesTableByAlertObjectIds(IEnumerable<int> alertObjectIds)
		{
			return this._alertPropertiesProvider.Value.GetAlertNotificationProperties(alertObjectIds);
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x00028799 File Offset: 0x00026999
		private string GetQueryWithViewLimitations(string query, int viewLimitationId)
		{
			if (viewLimitationId != 0)
			{
				return string.Format("{0} WITH LIMITATION {1}", query, viewLimitationId);
			}
			return query;
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x000287B4 File Offset: 0x000269B4
		private IEnumerable<string> GetUrisForGlobalAlert(int id, bool federationEnabled)
		{
			IEnumerable<string> result;
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				result = from item in InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, "SELECT a.AlertActiveObjects.EntityUri\r\n                                              FROM Orion.AlertActive (nolock=true) AS a\r\n                                              WHERE a.AlertObjectID=@objectId", new Dictionary<string, object>
				{
					{
						"objectId",
						id
					}
				}, federationEnabled).AsEnumerable()
				where item["EntityUri"] != DBNull.Value
				select Convert.ToString(item["EntityUri"]);
			}
			return result;
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x0002885C File Offset: 0x00026A5C
		public ActiveAlert GetActiveAlert(int alertObjectId, IEnumerable<int> limitationIDs, bool includeNotTriggered = true)
		{
			ActiveAlert activeAlert = null;
			IEnumerable<CustomProperty> customPropertiesForEntity = CustomPropertyMgr.GetCustomPropertiesForEntity("Orion.AlertConfigurationsCustomProperties");
			string text = this.GetActiveAlertQuery(customPropertiesForEntity, includeNotTriggered);
			text += " WHERE Data.AlertObjectID=@alertObjectId";
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				DataTable dataTable = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, text, new Dictionary<string, object>
				{
					{
						"alertObjectId",
						alertObjectId
					}
				});
				if (dataTable.Rows.Count > 0)
				{
					activeAlert = this.GetActiveAlertFromDataRow(dataTable.Rows[0], customPropertiesForEntity);
					AlertIncidentCache.Build(informationServiceProxy, new int?(activeAlert.Id), false).FillIncidentInfo(activeAlert);
					if (!string.IsNullOrEmpty(activeAlert.RelatedNodeEntityUri))
					{
						text = "SELECT NodeID, Status FROM Orion.Nodes (nolock=true) WHERE Uri=@uri";
						DataTable dataTable2 = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, text, new Dictionary<string, object>
						{
							{
								"uri",
								activeAlert.RelatedNodeEntityUri
							}
						});
						if (dataTable2.Rows.Count > 0)
						{
							activeAlert.RelatedNodeID = ((dataTable2.Rows[0]["NodeID"] != DBNull.Value) ? Convert.ToInt32(dataTable2.Rows[0]["NodeID"]) : 0);
							activeAlert.RelatedNodeStatus = ((dataTable2.Rows[0]["Status"] != DBNull.Value) ? Convert.ToInt32(dataTable2.Rows[0]["Status"]) : 0);
							activeAlert.RelatedNodeDetailsUrl = string.Format("/Orion/View.aspx?NetObject=N:{0}", activeAlert.RelatedNodeID);
						}
					}
					if (activeAlert.TriggeringObjectEntityName == "Orion.Nodes")
					{
						activeAlert.ActiveNetObject = Convert.ToString(activeAlert.RelatedNodeID);
					}
					if (!string.IsNullOrEmpty(activeAlert.TriggeringObjectEntityUri))
					{
						text = "SELECT TME.Status, TME.Uri FROM System.ManagedEntity (nolock=true) TME WHERE TME.Uri=@uri";
						DataTable dataTable3 = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, text, new Dictionary<string, object>
						{
							{
								"uri",
								activeAlert.TriggeringObjectEntityUri
							}
						});
						if (dataTable3.Rows.Count > 0)
						{
							activeAlert.TriggeringObjectStatus = ((dataTable3.Rows[0]["Status"] != DBNull.Value) ? Convert.ToInt32(dataTable3.Rows[0]["Status"]) : 0);
						}
					}
					else
					{
						activeAlert.TriggeringObjectStatus = this.GetRollupStatusForGlobalAlert(activeAlert.TriggeringObjectEntityName, alertObjectId, false);
					}
					activeAlert.Status = this.GetTriggeredStatusForActiveAlert(alertObjectId);
				}
			}
			return activeAlert;
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x00028AD0 File Offset: 0x00026CD0
		private int GetRollupStatusForGlobalAlert(string entity, int alertObjectId, bool federationEnabled = false)
		{
			if (!this.EntityHasStatusProperty(entity, federationEnabled))
			{
				return 0;
			}
			IEnumerable<string> urisForGlobalAlert = this.GetUrisForGlobalAlert(alertObjectId, federationEnabled);
			if (!urisForGlobalAlert.Any<string>())
			{
				return 0;
			}
			List<int> statuses = new List<int>();
			StringBuilder sbCondition = new StringBuilder();
			Action<Dictionary<string, object>> action = delegate(Dictionary<string, object> swqlParameters)
			{
				string text = string.Format("SELECT Status FROM {0} (nolock=true) WHERE {1}", entity, sbCondition);
				using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
				{
					foreach (object obj in InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, text, swqlParameters, federationEnabled).Rows)
					{
						DataRow dataRow = (DataRow)obj;
						int item = 0;
						if (dataRow["Status"] == DBNull.Value || !int.TryParse(Convert.ToString(dataRow["Status"]), out item))
						{
							item = 0;
						}
						statuses.Add(item);
					}
				}
			};
			int num = 0;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			foreach (string value in urisForGlobalAlert)
			{
				if (num > 0)
				{
					sbCondition.Append(" OR ");
				}
				sbCondition.AppendFormat("Uri=@uri{0}", num);
				dictionary.Add(string.Format("uri{0}", num), value);
				num++;
				if (num % 1000 == 0)
				{
					action(dictionary);
					dictionary = new Dictionary<string, object>();
					sbCondition.Clear();
					num = 0;
				}
			}
			if (num > 0)
			{
				action(dictionary);
			}
			return StatusInfo.RollupStatus(statuses, 2);
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x00028C18 File Offset: 0x00026E18
		private bool EntityHasStatusProperty(string entity, bool federationEnabled = false)
		{
			bool result;
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				result = (InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, "SELECT Name FROM Metadata.Property WHERE EntityName=@entityName AND Name='Status'", new Dictionary<string, object>
				{
					{
						"entityName",
						entity
					}
				}, federationEnabled).Rows.Count > 0);
			}
			return result;
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x00028C7C File Offset: 0x00026E7C
		public Tuple<IEnumerable<ActiveAlert>, int> GetActiveAlerts(IEnumerable<CustomProperty> customProperties, IEnumerable<int> limitationIDs, out List<ErrorMessage> errors, bool federationEnabled, bool includeNotTriggered = false, bool showAcknowledgedAlerts = true, bool showOnlyAcknowledgedAlerts = false, string relatedNodeEntityUri = "", string filterStatement = "", string orderByClause = "", int fromRow = 1, int toRow = 2147483647)
		{
			List<ActiveAlert> list = new List<ActiveAlert>();
			string text = this.GetActiveAlertQuery(customProperties, includeNotTriggered);
			text += " WHERE 1=1";
			if (!string.IsNullOrEmpty(filterStatement))
			{
				text = text + " AND (" + filterStatement + ")";
			}
			if (OrionConfiguration.IsDemoServer)
			{
				text += " AND (Data.TriggeredDateTime <= GETUTCDATE())";
			}
			if (!string.IsNullOrEmpty(relatedNodeEntityUri))
			{
				text = text + " AND RelatedNodeEntityUri='" + relatedNodeEntityUri + "'";
			}
			if (!showAcknowledgedAlerts)
			{
				if (showOnlyAcknowledgedAlerts)
				{
					text += " AND (AcknowledgedBy IS NOT NULL AND AcknowledgedBy <> '')";
				}
				else
				{
					text += " AND (AcknowledgedBy IS NULL OR AcknowledgedBy = '')";
				}
			}
			if (string.IsNullOrEmpty(orderByClause))
			{
				orderByClause = "AlertObjectID";
			}
			if (fromRow != 1 || toRow != 2147483647)
			{
				text += string.Format(" ORDER BY {0} WITH ROWS {1} TO {2} WITH TOTALROWS", orderByClause, fromRow, toRow);
			}
			string queryWithViewLimitations = this.GetQueryWithViewLimitations(text, Limitation.GetOnlyViewLimitation(limitationIDs, AccountContext.GetAccountID(), this._swisProxyCreator, federationEnabled));
			int num = 0;
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				DataTable dataTable = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, queryWithViewLimitations, federationEnabled);
				errors = FederatedResultTableParser.GetErrorsFromDataTable(dataTable);
				num = Convert.ToInt32(dataTable.ExtendedProperties["TotalRows"]);
				AlertIncidentCache alertIncidentCache = AlertIncidentCache.Build(informationServiceProxy, null, false);
				foreach (object obj in dataTable.Rows)
				{
					DataRow rActiveAlert = (DataRow)obj;
					ActiveAlert activeAlertFromDataRow = this.GetActiveAlertFromDataRow(rActiveAlert, customProperties);
					alertIncidentCache.FillIncidentInfo(activeAlertFromDataRow);
					if (string.IsNullOrEmpty(activeAlertFromDataRow.TriggeringObjectEntityUri))
					{
						activeAlertFromDataRow.TriggeringObjectStatus = this.GetRollupStatusForGlobalAlert(activeAlertFromDataRow.TriggeringObjectEntityName, activeAlertFromDataRow.Id, false);
					}
					list.Add(activeAlertFromDataRow);
				}
			}
			return new Tuple<IEnumerable<ActiveAlert>, int>(list, (num > 0) ? num : list.Count);
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x00028E7C File Offset: 0x0002707C
		public List<ActiveAlertDetailed> GetAlertTableByDate(DateTime dateTime, int? lastAlertHistoryId, List<int> limitationIDs)
		{
			List<ActiveAlert> list = new List<ActiveAlert>();
			StringBuilder stringBuilder = new StringBuilder(this.GetActiveAlertTableByDateQuery());
			object value;
			if (lastAlertHistoryId != null)
			{
				value = lastAlertHistoryId.Value;
				stringBuilder.Append("AND (AlertHistory.AlertHistoryID > @param)");
			}
			else
			{
				value = dateTime;
				stringBuilder.Append("AND (AlertHistory.TimeStamp > @param)");
			}
			string queryWithViewLimitations = this.GetQueryWithViewLimitations(stringBuilder.ToString(), Limitation.GetOnlyViewLimitation(limitationIDs, AccountContext.GetAccountID(), this._swisProxyCreator, false));
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				foreach (object obj in InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, queryWithViewLimitations, new Dictionary<string, object>
				{
					{
						"param",
						value
					}
				}).Rows)
				{
					DataRow dataRow = (DataRow)obj;
					ActiveAlertDetailed activeAlertDetailed = new ActiveAlertDetailed
					{
						Id = ((dataRow["AlertActiveID"] != DBNull.Value) ? Convert.ToInt32(dataRow["AlertActiveID"]) : 0),
						AlertHistoryId = ((dataRow["AlertHistoryID"] != DBNull.Value) ? Convert.ToInt32(dataRow["AlertHistoryID"]) : 0),
						AlertDefId = ((dataRow["AlertID"] != DBNull.Value) ? Convert.ToString(dataRow["AlertID"]) : string.Empty),
						AlertRefID = ((dataRow["AlertRefID"] != DBNull.Value) ? new Guid(Convert.ToString(dataRow["AlertRefID"])) : Guid.Empty),
						ActiveNetObject = ((dataRow["AlertObjectID"] != DBNull.Value) ? Convert.ToString(dataRow["AlertObjectID"]) : string.Empty),
						ObjectType = ((dataRow["ObjectType"] != DBNull.Value) ? Convert.ToString(dataRow["ObjectType"]) : string.Empty),
						Name = ((dataRow["Name"] != DBNull.Value) ? Convert.ToString(dataRow["Name"]) : string.Empty),
						TriggeringObjectDetailsUrl = ((dataRow["EntityDetailsUrl"] != DBNull.Value) ? Convert.ToString(dataRow["EntityDetailsUrl"]) : string.Empty),
						TriggerDateTime = ((dataRow["TriggeredDateTime"] != DBNull.Value) ? DateTime.SpecifyKind(Convert.ToDateTime(dataRow["TriggeredDateTime"]), DateTimeKind.Utc) : ((dataRow["TimeStamp"] != DBNull.Value) ? Convert.ToDateTime(dataRow["TimeStamp"]) : DateTime.MinValue)).ToLocalTime(),
						TriggeringObjectEntityUri = ((dataRow["EntityUri"] != DBNull.Value) ? Convert.ToString(dataRow["EntityUri"]) : ((dataRow["ActiveObjectEntityUri"] != DBNull.Value) ? Convert.ToString(dataRow["ActiveObjectEntityUri"]) : string.Empty)),
						RelatedNodeEntityUri = ((dataRow["RelatedNodeUri"] != DBNull.Value) ? Convert.ToString(dataRow["RelatedNodeUri"]) : string.Empty),
						TriggeringObjectEntityName = ((dataRow["EntityType"] != DBNull.Value) ? Convert.ToString(dataRow["EntityType"]) : string.Empty),
						Message = ((dataRow["PropertyValue"] != DBNull.Value) ? Convert.ToString(dataRow["PropertyValue"]) : string.Empty),
						TriggeringObjectCaption = ((dataRow["EntityCaption"] != DBNull.Value) ? Convert.ToString(dataRow["EntityCaption"]) : string.Empty),
						ActionType = ((dataRow["ActionTypeID"] != DBNull.Value) ? Convert.ToString(dataRow["ActionTypeID"]) : string.Empty),
						AlertDefDescription = ((dataRow["Description"] != DBNull.Value) ? Convert.ToString(dataRow["Description"]) : string.Empty),
						AlertDefLastEdit = ((dataRow["LastEdit"] != DBNull.Value) ? DateTime.SpecifyKind(Convert.ToDateTime(dataRow["LastEdit"]), DateTimeKind.Utc) : DateTime.MinValue),
						AlertDefSeverity = ((dataRow["Severity"] != DBNull.Value) ? Convert.ToInt32(dataRow["Severity"]) : 2),
						Severity = ((dataRow["Severity"] != DBNull.Value) ? Convert.ToInt32(dataRow["Severity"]) : 2),
						AlertDefMessage = ((dataRow["AlertMessage"] != DBNull.Value) ? Convert.ToString(dataRow["AlertMessage"]) : string.Empty)
					};
					if (dataRow["Acknowledged"] != DBNull.Value && Convert.ToBoolean(dataRow["Acknowledged"]))
					{
						activeAlertDetailed.AcknowledgedBy = ((dataRow["AcknowledgedBy"] != DBNull.Value) ? Convert.ToString(dataRow["AcknowledgedBy"]) : string.Empty);
						activeAlertDetailed.AcknowledgedByFullName = activeAlertDetailed.AcknowledgedBy;
						activeAlertDetailed.AcknowledgedDateTime = ((dataRow["AcknowledgedDateTime"] != DBNull.Value) ? DateTime.SpecifyKind(Convert.ToDateTime(dataRow["AcknowledgedDateTime"]), DateTimeKind.Utc).ToLocalTime() : DateTime.MinValue);
						activeAlertDetailed.Notes = ((dataRow["AcknowledgedNote"] != DBNull.Value) ? Convert.ToString(dataRow["AcknowledgedNote"]) : string.Empty);
					}
					list.Add(activeAlertDetailed);
				}
			}
			return list.Cast<ActiveAlertDetailed>().ToList<ActiveAlertDetailed>();
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x000294BC File Offset: 0x000276BC
		public int ClearTriggeredActiveAlerts(IEnumerable<int> alertObjectIds, string accountId)
		{
			if (!alertObjectIds.Any<int>())
			{
				return 0;
			}
			string text = string.Empty;
			int result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand(string.Empty))
			{
				using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
				{
					using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction(IsolationLevel.ReadCommitted))
					{
						textCommand.Transaction = sqlTransaction;
						for (int i = 0; i < alertObjectIds.Count<int>(); i++)
						{
							if (i < 1000)
							{
								string text2 = string.Format("@alertObjectID{0}", i);
								textCommand.Parameters.AddWithValue(text2, alertObjectIds.ElementAt(i));
								if (text != string.Empty)
								{
									text += ",";
								}
								text += text2;
							}
							else
							{
								if (text != string.Empty)
								{
									text += ",";
								}
								text += alertObjectIds.ElementAt(i);
							}
						}
						textCommand.CommandText = string.Format("SELECT AlertObjectID, AlertActiveID FROM AlertActive WHERE [AlertObjectID] IN ({0})", text);
						foreach (object obj in SqlHelper.ExecuteDataTable(textCommand, sqlConnection, null).Rows)
						{
							DataRow dataRow = (DataRow)obj;
							int num = (dataRow["AlertObjectID"] != DBNull.Value) ? Convert.ToInt32(dataRow["AlertObjectID"]) : 0;
							long num2 = (dataRow["AlertActiveID"] != DBNull.Value) ? Convert.ToInt64(dataRow["AlertActiveID"]) : 0L;
							AlertHistory alertHistory = new AlertHistory();
							alertHistory.EventType = 8;
							alertHistory.AccountID = accountId;
							alertHistory.TimeStamp = DateTime.UtcNow;
							this._alertHistoryDAL.InsertHistoryItem(alertHistory, num2, num, sqlConnection, sqlTransaction);
						}
						foreach (int alertObjectId in alertObjectIds)
						{
							this.UpdateAlertCaptionAfterReset(alertObjectId, sqlTransaction);
						}
						textCommand.CommandText = string.Format("DELETE FROM AlertActive WHERE AlertObjectID IN ({0})", text);
						int num3 = SqlHelper.ExecuteNonQuery(textCommand, sqlConnection, sqlTransaction);
						sqlTransaction.Commit();
						result = num3;
					}
				}
			}
			return result;
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x00029778 File Offset: 0x00027978
		public IEnumerable<AlertClearedNotificationProperties> GetAlertClearedNotificationPropertiesByAlertObjectIds(IEnumerable<int> alertObjectIds)
		{
			if (!alertObjectIds.Any<int>())
			{
				return Enumerable.Empty<AlertClearedNotificationProperties>();
			}
			List<AlertClearedNotificationProperties> list = new List<AlertClearedNotificationProperties>();
			foreach (object obj in this.GetAlertResetOrUpdateNotificationPropertiesTableByAlertObjectIds(alertObjectIds).Rows)
			{
				DataRow dataRow = (DataRow)obj;
				AlertClearedNotificationProperties alertClearedNotificationProperties = new AlertClearedNotificationProperties();
				alertClearedNotificationProperties.ClearedTime = DateTime.UtcNow;
				AlertSeverity alertSeverity = (dataRow["Severity"] != DBNull.Value) ? Convert.ToInt32(dataRow["Severity"]) : 2;
				alertClearedNotificationProperties.AlertId = ((dataRow["AlertID"] != DBNull.Value) ? Convert.ToInt32(dataRow["AlertID"]) : 0);
				alertClearedNotificationProperties.AlertName = ((dataRow["Name"] != DBNull.Value) ? Convert.ToString(dataRow["Name"]) : string.Empty);
				alertClearedNotificationProperties.AlertObjectId = ((dataRow["AlertObjectID"] != DBNull.Value) ? Convert.ToInt32(dataRow["AlertObjectID"]) : 0);
				alertClearedNotificationProperties.AlertDefinitionId = ((dataRow["AlertRefID"] != DBNull.Value) ? new Guid(Convert.ToString(dataRow["AlertRefID"])) : Guid.Empty);
				alertClearedNotificationProperties.DetailsUrl = ((dataRow["EntityDetailsUrl"] != DBNull.Value) ? Convert.ToString(dataRow["EntityDetailsUrl"]) : string.Empty);
				alertClearedNotificationProperties.Message = ((dataRow["TriggeredMessage"] != DBNull.Value) ? Convert.ToString(dataRow["TriggeredMessage"]) : string.Empty);
				alertClearedNotificationProperties.ObjectId = ((dataRow["EntityUri"] != DBNull.Value) ? Convert.ToString(dataRow["EntityUri"]) : string.Empty);
				alertClearedNotificationProperties.ObjectName = ((dataRow["EntityType"] != DBNull.Value) ? Convert.ToString(dataRow["EntityType"]) : string.Empty);
				alertClearedNotificationProperties.NetObject = ((dataRow["EntityNetObjectId"] != DBNull.Value) ? Convert.ToString(dataRow["EntityNetObjectId"]) : string.Empty);
				alertClearedNotificationProperties.EntityCaption = ((dataRow["EntityCaption"] != DBNull.Value) ? Convert.ToString(dataRow["EntityCaption"]) : string.Empty);
				alertClearedNotificationProperties.ObjectType = alertClearedNotificationProperties.ObjectName;
				alertClearedNotificationProperties.TriggerTimeStamp = ((dataRow["TriggeredDateTime"] != DBNull.Value) ? DateTime.SpecifyKind(Convert.ToDateTime(dataRow["TriggeredDateTime"]), DateTimeKind.Utc) : DateTime.MinValue);
				AlertClearedNotificationProperties alertClearedNotificationProperties2 = alertClearedNotificationProperties;
				IEnumerable<string> objectUris;
				if (!string.IsNullOrWhiteSpace(alertClearedNotificationProperties.ObjectId))
				{
					IEnumerable<string> enumerable = new List<string>();
					objectUris = enumerable;
				}
				else
				{
					objectUris = this.GetGlobalAlertRelatedUris(alertClearedNotificationProperties.AlertId);
				}
				alertClearedNotificationProperties2.ObjectUris = objectUris;
				alertClearedNotificationProperties.Severity = alertSeverity.ToString();
				list.Add(alertClearedNotificationProperties);
			}
			return list;
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x00029A8C File Offset: 0x00027C8C
		private IEnumerable<string> GetGlobalAlertRelatedUris(int AlertID)
		{
			DataTable dataTable;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT ObjectId FROM [AlertConditionState] WHERE [AlertID]=@alertID AND [Type] = 0 AND [Resolved] = 1"))
			{
				textCommand.Parameters.AddWithValue("alertID", AlertID);
				dataTable = SqlHelper.ExecuteDataTable(textCommand);
			}
			List<string> list = new List<string>();
			foreach (object obj in dataTable.Rows)
			{
				DataRow dataRow = (DataRow)obj;
				list.Add(dataRow[0].ToString());
			}
			return list;
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x00029B40 File Offset: 0x00027D40
		public IEnumerable<AlertUpdatedNotification> GetAlertUpdatedNotificationPropertiesByAlertObjectIds(IEnumerable<int> alertObjectIds, string accountId, string notes, DateTime acknowledgedDateTime, bool acknowledge)
		{
			if (!alertObjectIds.Any<int>())
			{
				return Enumerable.Empty<AlertUpdatedNotification>();
			}
			return this._alertPropertiesProvider.Value.GetAlertUpdatedNotificationProperties(alertObjectIds, accountId, notes, acknowledgedDateTime, acknowledge);
		}

		// Token: 0x060006AF RID: 1711 RVA: 0x00029B67 File Offset: 0x00027D67
		public IEnumerable<AlertUpdatedNotification> GetAlertUpdatedNotificationPropertiesByAlertObjectIds(IEnumerable<int> alertObjectIds, string accountId, string notes, DateTime acknowledgedDateTime, bool acknowledge, string method)
		{
			if (!alertObjectIds.Any<int>())
			{
				return Enumerable.Empty<AlertUpdatedNotification>();
			}
			return this._alertPropertiesProvider.Value.GetAlertUpdatedNotificationProperties(alertObjectIds, accountId, notes, acknowledgedDateTime, acknowledge, method);
		}

		// Token: 0x060006B0 RID: 1712 RVA: 0x00029B90 File Offset: 0x00027D90
		public IEnumerable<int> LimitAlertAckStateUpdateCandidates(IEnumerable<int> alertObjectIds, bool requestedAcknowledgedState)
		{
			if (!alertObjectIds.Any<int>())
			{
				return Enumerable.Empty<int>();
			}
			return (from DataRow row in this.GetAlertResetOrUpdateNotificationPropertiesTableByAlertObjectIds(alertObjectIds).Rows
			where row["AlertObjectId"] != DBNull.Value
			let ackState = row["Acknowledged"] != DBNull.Value && Convert.ToBoolean(row["Acknowledged"])
			where ackState != requestedAcknowledgedState
			select Convert.ToInt32(row["AlertObjectId"])).ToList<int>();
		}

		// Token: 0x060006B1 RID: 1713 RVA: 0x00029C4C File Offset: 0x00027E4C
		internal string ActiveTimeToDisplayFormat(TimeSpan activeTime)
		{
			string text = string.Empty;
			if (activeTime.Days > 0)
			{
				text = string.Concat(new object[]
				{
					text,
					activeTime.Days,
					Resources.WEBCODE_PS0_30,
					" "
				});
			}
			if (activeTime.Hours > 0)
			{
				text = string.Concat(new object[]
				{
					text,
					activeTime.Hours,
					Resources.WEBCODE_PS0_31,
					" "
				});
			}
			if (activeTime.Minutes > 0)
			{
				text = string.Concat(new object[]
				{
					text,
					activeTime.Minutes,
					Resources.WEBCODE_PS0_32,
					" "
				});
			}
			return text;
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x00029D0C File Offset: 0x00027F0C
		public ActiveAlertObjectPage GetPageableActiveAlertObjects(PageableActiveAlertObjectRequest request)
		{
			ActiveAlertObjectPage activeAlertObjectPage = new ActiveAlertObjectPage();
			List<ActiveAlertObject> list = new List<ActiveAlertObject>();
			int totalRow;
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				string arg = (!string.IsNullOrEmpty(request.OrderByClause)) ? ("ORDER BY " + request.OrderByClause) : "ORDER BY AlertObjectID";
				string text = string.Format("SELECT a.AlertActiveObjects.EntityUri, a.AlertActiveObjects.EntityCaption, a.AlertActiveObjects.EntityDetailsUrl,\r\n                                             a.AcknowledgedBy, a.TriggeredDateTime, SecondDiff(a.TriggeredDateTime, getUtcDate()) AS ActiveTime\r\n                                              FROM Orion.AlertActive (nolock=true) AS a\r\n                                              WHERE a.AlertObjectID=@objectId\r\n                                              {0}", arg);
				text += string.Format(" WITH ROWS {0} TO {1} WITH TOTALROWS", request.StartRow + 1, request.StartRow + request.PageSize + 1);
				string queryWithViewLimitations = this.GetQueryWithViewLimitations(text, Limitation.GetOnlyViewLimitation(request.LimitationIDs, AccountContext.GetAccountID(), this._swisProxyCreator, false));
				DataTable dataTable = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, queryWithViewLimitations, new Dictionary<string, object>
				{
					{
						"objectId",
						request.AlertObjectId
					}
				});
				foreach (object obj in dataTable.Rows)
				{
					DataRow dataRow = (DataRow)obj;
					if (dataRow["EntityUri"] != DBNull.Value)
					{
						string uri = Convert.ToString(dataRow["EntityUri"]);
						string caption = (dataRow["EntityCaption"] != DBNull.Value) ? Convert.ToString(dataRow["EntityCaption"]) : "";
						string detailsUrl = (dataRow["EntityDetailsUrl"] != DBNull.Value) ? Convert.ToString(dataRow["EntityDetailsUrl"]) : "";
						ActiveAlertObject item = new ActiveAlertObject
						{
							Caption = caption,
							Uri = uri,
							DetailsUrl = detailsUrl,
							Entity = request.TriggeringEntityName
						};
						list.Add(item);
					}
				}
				totalRow = Convert.ToInt32(dataTable.ExtendedProperties["TotalRows"]);
			}
			this.FillAlertObjectStatus(request.TriggeringEntityName, list);
			activeAlertObjectPage.TotalRow = totalRow;
			activeAlertObjectPage.ActiveAlertObjects = list;
			return activeAlertObjectPage;
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x00029F4C File Offset: 0x0002814C
		private void FillAlertObjectStatus(string entity, List<ActiveAlertObject> objects)
		{
			if (!objects.Any<ActiveAlertObject>() || !this.EntityHasStatusProperty(entity, false))
			{
				return;
			}
			Dictionary<string, ActiveAlertObject> lookupUri = objects.ToDictionary((ActiveAlertObject item) => item.Uri, (ActiveAlertObject item) => item);
			StringBuilder sbCondition = new StringBuilder();
			Action<Dictionary<string, object>> action = delegate(Dictionary<string, object> swqlParameters)
			{
				string text = string.Format("SELECT Status, Uri FROM {0} (nolock=true) WHERE {1}", entity, sbCondition);
				using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
				{
					foreach (object obj in InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, text, swqlParameters).Rows)
					{
						DataRow dataRow = (DataRow)obj;
						int status = (dataRow["Status"] != DBNull.Value) ? Convert.ToInt32(dataRow["Status"]) : 0;
						string key = (dataRow["Uri"] != DBNull.Value) ? Convert.ToString(dataRow["Uri"]) : "";
						ActiveAlertObject activeAlertObject2;
						if (lookupUri.TryGetValue(key, out activeAlertObject2))
						{
							activeAlertObject2.Status = status;
						}
					}
				}
			};
			int num = 0;
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			foreach (ActiveAlertObject activeAlertObject in objects)
			{
				if (num > 0)
				{
					sbCondition.Append(" OR ");
				}
				sbCondition.AppendFormat("Uri=@uri{0}", num);
				dictionary.Add(string.Format("uri{0}", num), activeAlertObject.Uri);
				num++;
				if (num % 1000 == 0)
				{
					action(dictionary);
					dictionary = new Dictionary<string, object>();
					sbCondition.Clear();
					num = 0;
				}
			}
			if (num > 0)
			{
				action(dictionary);
			}
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x0002A0AC File Offset: 0x000282AC
		private bool UpdateAlertCaptionAfterReset(int alertObjectId, SqlTransaction transaction)
		{
			string value;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT TOP 1 [EntityType] FROM [AlertObjects]\r\n                WHERE [AlertObjectID] = @alertObjectId\r\n                AND [EntityUri] IS NULL"))
			{
				textCommand.Parameters.AddWithValue("alertObjectId", alertObjectId);
				object obj = SqlHelper.ExecuteScalar(textCommand, transaction.Connection, transaction);
				if (obj == DBNull.Value)
				{
					return false;
				}
				value = (obj as string);
				if (string.IsNullOrWhiteSpace(value))
				{
					return false;
				}
			}
			string text = "SELECT DisplayNamePlural FROM Metadata.Entity WHERE FullName = @entityName";
			string arg2;
			using (IInformationServiceProxy2 informationServiceProxy = this._swisProxyCreator.Create())
			{
				DataTable dataTable = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, text, new Dictionary<string, object>
				{
					{
						"entityName",
						value
					}
				});
				if (dataTable.Rows.Count <= 0)
				{
					return false;
				}
				string arg = dataTable.Rows[0][0] as string;
				arg2 = string.Format("{0} {1}", 0, arg);
			}
			bool result;
			using (SqlCommand textCommand2 = SqlHelper.GetTextCommand(string.Format("UPDATE [AlertObjects] SET EntityCaption = '{0}' \r\n                                                                           WHERE EntityUri IS NULL AND AlertObjectID = @alertObjectId", arg2)))
			{
				textCommand2.Parameters.AddWithValue("alertObjectId", alertObjectId);
				result = (SqlHelper.ExecuteNonQuery(textCommand2, transaction.Connection, transaction) == 1);
			}
			return result;
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x0002A214 File Offset: 0x00028414
		public string GetAlertNote(int alertObjectId)
		{
			string result;
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT AlertNote FROM AlertObjects WHERE AlertObjectID = @alertObjectId");
				textCommand.Parameters.AddWithValue("@alertObjectId", alertObjectId);
				DataTable dataTable = SqlHelper.ExecuteDataTable(textCommand, sqlConnection, null);
				if (dataTable.Rows.Count > 0)
				{
					result = (dataTable.Rows[0][0] as string);
				}
				else
				{
					result = string.Empty;
				}
			}
			return result;
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x0002A29C File Offset: 0x0002849C
		public bool SetAlertNote(int alertObjectId, string accountId, string note, DateTime modificationDateTime)
		{
			if (alertObjectId < 0 || string.IsNullOrEmpty(accountId))
			{
				return false;
			}
			bool result;
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction(IsolationLevel.ReadCommitted))
				{
					using (SqlCommand textCommand = SqlHelper.GetTextCommand("UPDATE AlertObjects SET AlertNote = @AlertNote WHERE AlertObjectId=@alertObjectId"))
					{
						textCommand.Parameters.AddWithValue("@alertObjectId", alertObjectId);
						textCommand.Parameters.AddWithValue("@AlertNote", note);
						SqlHelper.ExecuteNonQuery(textCommand, sqlConnection, sqlTransaction);
						textCommand.CommandText = "SELECT AlertActiveId FROM AlertActive WHERE AlertObjectId=@alertObjectId";
						object obj = SqlHelper.ExecuteScalar(textCommand, sqlConnection);
						AlertHistory alertHistory = new AlertHistory();
						int num = 0;
						if (obj != null && obj != DBNull.Value)
						{
							num = Convert.ToInt32(obj);
						}
						alertHistory.EventType = 3;
						alertHistory.AccountID = accountId;
						alertHistory.Message = note;
						alertHistory.TimeStamp = modificationDateTime.ToUniversalTime();
						this._alertHistoryDAL.InsertHistoryItem(alertHistory, (long)num, alertObjectId, sqlConnection, sqlTransaction);
					}
					sqlTransaction.Commit();
					result = true;
				}
			}
			return result;
		}

		// Token: 0x04000218 RID: 536
		private static readonly Log log = new Log();

		// Token: 0x04000219 RID: 537
		private readonly Lazy<AlertObjectPropertiesProvider> _alertPropertiesProvider;

		// Token: 0x0400021A RID: 538
		private readonly IInformationServiceProxyCreator _swisProxyCreator;

		// Token: 0x0400021B RID: 539
		private readonly IAlertHistoryDAL _alertHistoryDAL;
	}
}
