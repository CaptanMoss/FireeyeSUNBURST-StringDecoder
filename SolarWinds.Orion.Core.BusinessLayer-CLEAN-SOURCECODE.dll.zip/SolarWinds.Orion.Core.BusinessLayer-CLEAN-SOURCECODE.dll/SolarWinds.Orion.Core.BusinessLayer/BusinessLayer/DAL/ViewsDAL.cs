﻿using System;
using System.Data;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000B0 RID: 176
	public class ViewsDAL
	{
		// Token: 0x06000882 RID: 2178 RVA: 0x0003D6FC File Offset: 0x0003B8FC
		public static Views GetSummaryDetailsViews()
		{
			string text = "SELECT * FROM Views WHERE (NOT(ViewType LIKE 'Volume%')) AND ((ViewType LIKE 'Summary') OR (ViewType LIKE '%Details'))";
			return Collection<int, WebView>.FillCollection<Views>(new Collection<int, WebView>.CreateElement(ViewsDAL.CreateView), text, null);
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x0003D724 File Offset: 0x0003B924
		private static WebView CreateView(IDataReader reader)
		{
			return new WebView
			{
				ViewType = reader["ViewType"].ToString().Trim(),
				ViewID = Convert.ToInt32(reader["ViewID"]),
				ViewTitle = reader["ViewTitle"].ToString().Trim(),
				ViewGroupName = reader["ViewGroupName"].ToString().Trim()
			};
		}

		// Token: 0x0400026E RID: 622
		private static readonly Log log = new Log();
	}
}
