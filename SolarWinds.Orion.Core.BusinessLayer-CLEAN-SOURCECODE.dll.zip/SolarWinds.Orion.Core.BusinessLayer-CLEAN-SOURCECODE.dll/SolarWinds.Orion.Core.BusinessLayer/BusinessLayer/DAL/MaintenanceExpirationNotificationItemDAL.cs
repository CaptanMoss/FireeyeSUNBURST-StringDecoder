﻿using System;
using System.Collections.Generic;
using System.Linq;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000097 RID: 151
	public sealed class MaintenanceExpirationNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x06000710 RID: 1808 RVA: 0x0002D114 File Offset: 0x0002B314
		public static MaintenanceExpirationNotificationItemDAL GetItem()
		{
			return NotificationItemDAL.GetItemById<MaintenanceExpirationNotificationItemDAL>(MaintenanceExpirationNotificationItemDAL.MaintenanceExpirationNotificationItemId);
		}

		// Token: 0x06000711 RID: 1809 RVA: 0x0002D120 File Offset: 0x0002B320
		public static void Show(Dictionary<string, int> moduleExpirations)
		{
			Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> dictionary = new Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>();
			foreach (KeyValuePair<string, int> keyValuePair in moduleExpirations)
			{
				dictionary[keyValuePair.Key] = new MaintenanceExpirationNotificationItemDAL.ExpirationInfo
				{
					LicenseName = string.Empty,
					DaysToExpire = keyValuePair.Value,
					LastRemindMeLaterDate = null
				};
			}
			MaintenanceExpirationNotificationItemDAL.Show(dictionary);
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x0002D1AC File Offset: 0x0002B3AC
		internal static void Show(Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> moduleExpirations)
		{
			bool flag = moduleExpirations.Any((KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> m) => m.Value.DaysToExpire <= 0);
			int daysToExpire = moduleExpirations.Min((KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> x) => x.Value.DaysToExpire);
			string url = "javascript:SW.Core.SalesTrigger.ShowMaintenancePopupAsync();";
			Guid typeId = flag ? MaintenanceExpirationNotificationItemDAL.MaintenanceExpiredNotificationTypeGuid : MaintenanceExpirationNotificationItemDAL.MaintenanceExpirationWarningNotificationTypeGuid;
			int maintenanceExpiredShowAgainAtDays = BusinessLayerSettings.Instance.MaintenanceExpiredShowAgainAtDays;
			MaintenanceExpirationNotificationItemDAL item = MaintenanceExpirationNotificationItemDAL.GetItem();
			if (item == null)
			{
				string description = MaintenanceExpirationNotificationItemDAL.Serialize(moduleExpirations);
				NotificationItemDAL.Insert(MaintenanceExpirationNotificationItemDAL.MaintenanceExpirationNotificationItemId, typeId, MaintenanceExpirationNotificationItemDAL.GetNotificationMessage(flag, daysToExpire), description, false, url, null, null);
				return;
			}
			Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> previousExpirations = MaintenanceExpirationNotificationItemDAL.Deserialize(item.Description);
			IEnumerable<KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>> previousExpirations2 = previousExpirations;
			Func<KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>, bool> <>9__2;
			Func<KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>, bool> predicate;
			if ((predicate = <>9__2) == null)
			{
				predicate = (<>9__2 = ((KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> previousExpiration) => moduleExpirations.ContainsKey(previousExpiration.Key)));
			}
			foreach (KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> keyValuePair in previousExpirations2.Where(predicate))
			{
				moduleExpirations[keyValuePair.Key].LastRemindMeLaterDate = keyValuePair.Value.LastRemindMeLaterDate;
			}
			DateTime utcNow = DateTime.UtcNow;
			int num = (int)utcNow.Subtract(item.AcknowledgedAt ?? DateTime.UtcNow).TotalDays;
			DateTime? acknowledgedAt = item.AcknowledgedAt;
			foreach (KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> keyValuePair2 in moduleExpirations)
			{
				if ((previousExpirations.ContainsKey(keyValuePair2.Key) || num != maintenanceExpiredShowAgainAtDays) && (!previousExpirations.ContainsKey(keyValuePair2.Key) || keyValuePair2.Value.DaysToExpire <= 0 || num != maintenanceExpiredShowAgainAtDays) && (!previousExpirations.ContainsKey(keyValuePair2.Key) || previousExpirations[keyValuePair2.Key].DaysToExpire <= 0 || keyValuePair2.Value.DaysToExpire > 0))
				{
					utcNow = DateTime.UtcNow;
					if ((int)utcNow.Subtract(keyValuePair2.Value.LastRemindMeLaterDate ?? DateTime.UtcNow).TotalDays != maintenanceExpiredShowAgainAtDays)
					{
						continue;
					}
				}
				item.SetNotAcknowledged();
				break;
			}
			if (acknowledgedAt != null)
			{
				IEnumerable<KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>> moduleExpirations2 = moduleExpirations;
				Func<KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>, bool> <>9__3;
				Func<KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>, bool> predicate2;
				if ((predicate2 = <>9__3) == null)
				{
					predicate2 = (<>9__3 = ((KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> m) => m.Value.DaysToExpire <= 0 && m.Value.LastRemindMeLaterDate == null && previousExpirations.ContainsKey(m.Key) && previousExpirations[m.Key].DaysToExpire <= 0));
				}
				foreach (KeyValuePair<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> keyValuePair3 in moduleExpirations2.Where(predicate2))
				{
					keyValuePair3.Value.LastRemindMeLaterDate = acknowledgedAt;
				}
			}
			item.TypeId = typeId;
			item.Description = MaintenanceExpirationNotificationItemDAL.Serialize(moduleExpirations);
			item.Url = url;
			item.Title = MaintenanceExpirationNotificationItemDAL.GetNotificationMessage(flag, daysToExpire);
			item.Update();
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x0002D51C File Offset: 0x0002B71C
		public static void Hide()
		{
			NotificationItemDAL.Delete(MaintenanceExpirationNotificationItemDAL.MaintenanceExpirationNotificationItemId);
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x0002D529 File Offset: 0x0002B729
		private static string GetNotificationMessage(bool expired, int daysToExpire)
		{
			if (!expired)
			{
				return string.Format(Resources.COREBUSINESSLAYERDAL_CODE_YK0_4, daysToExpire, "https://www.solarwinds.com/embedded_in_products/productLink.aspx?id=online_quote");
			}
			return string.Format(Resources.COREBUSINESSLAYERDAL_CODE_YK0_3, "https://www.solarwinds.com/embedded_in_products/productLink.aspx?id=online_quote");
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x0002D553 File Offset: 0x0002B753
		private static string Serialize(Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> moduleExpirations)
		{
			return string.Join("|", (from m in moduleExpirations
			select string.Format("{0};{1};{2};{3};{4}", new object[]
			{
				m.Key,
				m.Value.DaysToExpire,
				m.Value.LicenseName,
				m.Value.LastRemindMeLaterDate,
				m.Value.ActivationKey
			})).ToArray<string>());
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x0002D58C File Offset: 0x0002B78C
		private static Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> Deserialize(string moduleExpirations)
		{
			Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo> dictionary = new Dictionary<string, MaintenanceExpirationNotificationItemDAL.ExpirationInfo>();
			if (!string.IsNullOrEmpty(moduleExpirations))
			{
				foreach (string text in moduleExpirations.Split(new char[]
				{
					'|'
				}))
				{
					try
					{
						string[] array2 = text.Split(new char[]
						{
							';'
						});
						MaintenanceExpirationNotificationItemDAL.ExpirationInfo expirationInfo = new MaintenanceExpirationNotificationItemDAL.ExpirationInfo();
						expirationInfo.DaysToExpire = Convert.ToInt32(array2[1]);
						if (array2.Length > 2 && !string.IsNullOrWhiteSpace(array2[2]))
						{
							expirationInfo.LicenseName = array2[2];
						}
						if (array2.Length > 3 && !string.IsNullOrWhiteSpace(array2[3]))
						{
							expirationInfo.LastRemindMeLaterDate = new DateTime?(DateTime.Parse(array2[3]));
						}
						if (array2.Length > 4 && !string.IsNullOrWhiteSpace(array2[4]))
						{
							expirationInfo.ActivationKey = array2[4];
						}
						dictionary[array2[0]] = expirationInfo;
					}
					catch (Exception ex)
					{
						NotificationItemDAL.log.Warn("Unable to parse maintenance expiration notification panel data", ex);
					}
				}
			}
			return dictionary;
		}

		// Token: 0x04000239 RID: 569
		public static readonly Guid MaintenanceExpirationNotificationItemId = new Guid("{561BE782-187F-4977-B5C4-B8666E73E582}");

		// Token: 0x0400023A RID: 570
		public static readonly Guid MaintenanceExpirationWarningNotificationTypeGuid = new Guid("{93465286-2E85-411D-8980-EFD32F04F0EE}");

		// Token: 0x0400023B RID: 571
		public static readonly Guid MaintenanceExpiredNotificationTypeGuid = new Guid("{ED77CD80-345D-4D51-B6A7-4AB3728F2200}");

		// Token: 0x0200018C RID: 396
		internal class ExpirationInfo
		{
			// Token: 0x17000164 RID: 356
			// (get) Token: 0x06000C55 RID: 3157 RVA: 0x0004B5CD File Offset: 0x000497CD
			// (set) Token: 0x06000C56 RID: 3158 RVA: 0x0004B5DF File Offset: 0x000497DF
			[Obsolete("Use LicenseName instead", true)]
			public string ModuleName
			{
				get
				{
					return this._moduleNameLegacy ?? this.LicenseName;
				}
				set
				{
					this._moduleNameLegacy = value;
				}
			}

			// Token: 0x17000165 RID: 357
			// (get) Token: 0x06000C57 RID: 3159 RVA: 0x0004B5E8 File Offset: 0x000497E8
			// (set) Token: 0x06000C58 RID: 3160 RVA: 0x0004B5F0 File Offset: 0x000497F0
			public string LicenseName { get; set; }

			// Token: 0x17000166 RID: 358
			// (get) Token: 0x06000C59 RID: 3161 RVA: 0x0004B5F9 File Offset: 0x000497F9
			// (set) Token: 0x06000C5A RID: 3162 RVA: 0x0004B601 File Offset: 0x00049801
			public int DaysToExpire { get; set; }

			// Token: 0x17000167 RID: 359
			// (get) Token: 0x06000C5B RID: 3163 RVA: 0x0004B60A File Offset: 0x0004980A
			// (set) Token: 0x06000C5C RID: 3164 RVA: 0x0004B612 File Offset: 0x00049812
			public DateTime? LastRemindMeLaterDate { get; set; }

			// Token: 0x17000168 RID: 360
			// (get) Token: 0x06000C5D RID: 3165 RVA: 0x0004B61B File Offset: 0x0004981B
			// (set) Token: 0x06000C5E RID: 3166 RVA: 0x0004B623 File Offset: 0x00049823
			public string ActivationKey { get; set; }

			// Token: 0x040004F5 RID: 1269
			private string _moduleNameLegacy;
		}
	}
}
