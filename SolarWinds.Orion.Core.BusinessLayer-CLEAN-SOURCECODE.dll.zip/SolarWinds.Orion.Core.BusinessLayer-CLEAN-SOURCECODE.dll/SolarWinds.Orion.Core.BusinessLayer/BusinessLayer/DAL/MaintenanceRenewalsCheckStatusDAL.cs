﻿using System;
using System.Data;
using System.Data.SqlClient;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Discovery.DataAccess;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000A5 RID: 165
	public sealed class MaintenanceRenewalsCheckStatusDAL
	{
		// Token: 0x17000101 RID: 257
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x000383DC File Offset: 0x000365DC
		// (set) Token: 0x060007D1 RID: 2001 RVA: 0x000383E4 File Offset: 0x000365E4
		public DateTime? LastUpdateCheck { get; set; }

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x060007D2 RID: 2002 RVA: 0x000383ED File Offset: 0x000365ED
		// (set) Token: 0x060007D3 RID: 2003 RVA: 0x000383F5 File Offset: 0x000365F5
		public DateTime? NextUpdateCheck { get; set; }

		// Token: 0x060007D4 RID: 2004 RVA: 0x00038400 File Offset: 0x00036600
		public MaintenanceRenewalsCheckStatusDAL()
		{
			this.LastUpdateCheck = null;
			this.NextUpdateCheck = null;
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x00038434 File Offset: 0x00036634
		public static MaintenanceRenewalsCheckStatusDAL GetCheckStatus()
		{
			MaintenanceRenewalsCheckStatusDAL result;
			try
			{
				MaintenanceRenewalsCheckStatusDAL maintenanceRenewalsCheckStatusDAL = new MaintenanceRenewalsCheckStatusDAL();
				maintenanceRenewalsCheckStatusDAL.LoadFromDB();
				result = maintenanceRenewalsCheckStatusDAL;
			}
			catch (ResultCountException)
			{
				MaintenanceRenewalsCheckStatusDAL.log.DebugFormat("Can't find maintenance renewals check status record in DB.", Array.Empty<object>());
				result = null;
			}
			return result;
		}

		// Token: 0x060007D6 RID: 2006 RVA: 0x0003847C File Offset: 0x0003667C
		public static MaintenanceRenewalsCheckStatusDAL Insert(DateTime? lastCheck, DateTime? nextCheck)
		{
			MaintenanceRenewalsCheckStatusDAL result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("INSERT INTO MaintenanceRenewalsCheckStatus (LastUpdateCheck, NextUpdateCheck)\r\n                                                        VALUES (@LastUpdateCheck, @NextUpdateCheck)"))
			{
				textCommand.Parameters.AddWithValue("@LastUpdateCheck", (lastCheck != null) ? lastCheck : DBNull.Value);
				textCommand.Parameters.AddWithValue("@NextUpdateCheck", (nextCheck != null) ? nextCheck : DBNull.Value);
				if (SqlHelper.ExecuteNonQuery(textCommand) == 0)
				{
					result = null;
				}
				else
				{
					result = new MaintenanceRenewalsCheckStatusDAL
					{
						LastUpdateCheck = lastCheck,
						NextUpdateCheck = nextCheck
					};
				}
			}
			return result;
		}

		// Token: 0x060007D7 RID: 2007 RVA: 0x00038520 File Offset: 0x00036720
		public bool Update()
		{
			bool result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("UPDATE MaintenanceRenewalsCheckStatus SET LastUpdateCheck=@LastUpdateCheck, NextUpdateCheck=@NextUpdateCheck"))
			{
				textCommand.Parameters.AddWithValue("@LastUpdateCheck", (this.LastUpdateCheck != null) ? this.LastUpdateCheck : DBNull.Value);
				textCommand.Parameters.AddWithValue("@NextUpdateCheck", (this.NextUpdateCheck != null) ? this.NextUpdateCheck : DBNull.Value);
				result = (SqlHelper.ExecuteNonQuery(textCommand) > 0);
			}
			return result;
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x000385C8 File Offset: 0x000367C8
		public static void SetLastUpdateCheck(double timeout, bool forceCheck)
		{
			DateTime utcNow = DateTime.UtcNow;
			MaintenanceRenewalsCheckStatusDAL checkStatus = MaintenanceRenewalsCheckStatusDAL.GetCheckStatus();
			if (checkStatus == null)
			{
				MaintenanceRenewalsCheckStatusDAL.Insert(new DateTime?(utcNow), new DateTime?(utcNow.AddMinutes(timeout)));
				return;
			}
			checkStatus.LastUpdateCheck = new DateTime?(utcNow);
			if (forceCheck)
			{
				checkStatus.NextUpdateCheck = new DateTime?(utcNow.AddMinutes(timeout));
			}
			checkStatus.Update();
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x00038627 File Offset: 0x00036827
		private void LoadFromReader(IDataReader rd)
		{
			if (rd == null)
			{
				throw new ArgumentNullException("rd");
			}
			this.LastUpdateCheck = new DateTime?(DatabaseFunctions.GetDateTime(rd, "LastUpdateCheck"));
			this.NextUpdateCheck = new DateTime?(DatabaseFunctions.GetDateTime(rd, "NextUpdateCheck"));
		}

		// Token: 0x060007DA RID: 2010 RVA: 0x00038664 File Offset: 0x00036864
		private void LoadFromDB()
		{
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT * FROM MaintenanceRenewalsCheckStatus"))
			{
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
				{
					if (!dataReader.Read())
					{
						throw new ResultCountException(1, 0);
					}
					this.LoadFromReader(dataReader);
				}
			}
		}

		// Token: 0x04000256 RID: 598
		private static readonly Log log = new Log();
	}
}
