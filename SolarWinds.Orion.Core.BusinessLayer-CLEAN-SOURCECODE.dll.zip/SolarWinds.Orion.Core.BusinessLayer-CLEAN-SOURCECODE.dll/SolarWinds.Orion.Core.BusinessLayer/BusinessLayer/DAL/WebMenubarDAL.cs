﻿using System;
using System.Data;
using System.Data.SqlClient;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000B2 RID: 178
	internal static class WebMenubarDAL
	{
		// Token: 0x06000896 RID: 2198 RVA: 0x0003F320 File Offset: 0x0003D520
		public static int InsertItem(WebMenuItem item)
		{
			int result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("INSERT MenuItems (Title, Link, System, NewWindow, Description)\r\nVALUES (@title, @link, 'N', @newwindow, @description)\r\nSELECT scope_identity()"))
			{
				textCommand.Parameters.AddWithValue("title", item.Title);
				textCommand.Parameters.AddWithValue("link", item.Link);
				textCommand.Parameters.AddWithValue("newwindow", item.NewWindow ? "Y" : "N");
				textCommand.Parameters.AddWithValue("description", item.Description);
				result = Convert.ToInt32(SqlHelper.ExecuteScalar(textCommand));
			}
			return result;
		}

		// Token: 0x06000897 RID: 2199 RVA: 0x0003F3CC File Offset: 0x0003D5CC
		public static void AppendItemToMenu(string menuName, int itemId)
		{
			int num;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT MAX(Position) FROM MenuBars WHERE MenuName=@menu"))
			{
				textCommand.Parameters.AddWithValue("menu", menuName);
				num = Convert.ToInt32(SqlHelper.ExecuteScalar(textCommand));
			}
			num++;
			using (SqlCommand textCommand2 = SqlHelper.GetTextCommand("INSERT MenuBars (MenuName, MenuItemID, Position)\r\nVALUES (@menu, @item, @position)"))
			{
				textCommand2.Parameters.AddWithValue("menu", menuName);
				textCommand2.Parameters.AddWithValue("item", itemId);
				textCommand2.Parameters.AddWithValue("position", num);
				SqlHelper.ExecuteNonQuery(textCommand2);
			}
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x0003F48C File Offset: 0x0003D68C
		public static bool MenuItemExists(string link)
		{
			bool result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT TOP 1 1 FROM [dbo].[MenuItems] WHERE Link = @link"))
			{
				textCommand.Parameters.AddWithValue("@link", link);
				object obj = SqlHelper.ExecuteScalar(textCommand);
				if (obj == DBNull.Value)
				{
					result = false;
				}
				else
				{
					result = Convert.ToBoolean(obj);
				}
			}
			return result;
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x0003F4F0 File Offset: 0x0003D6F0
		private static WebMenuItem Create(IDataReader reader)
		{
			return new WebMenuItem
			{
				ID = (int)reader["MenuItemID"],
				Title = (string)reader["Title"],
				Link = (string)reader["Link"],
				NewWindow = ((string)reader["NewWindow"] == "Y"),
				Description = (string)reader["Description"]
			};
		}

		// Token: 0x0600089A RID: 2202 RVA: 0x0003F57C File Offset: 0x0003D77C
		internal static void DeleteItemByLink(string link)
		{
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("DELETE MenuBars FROM MenuBars, MenuItems\r\nWHERE MenuItems.Link=@link\r\nAND MenuBars.MenuItemID=MenuItems.MenuItemID\r\n\r\nDELETE MenuItems FROM MenuItems WHERE MenuItems.Link=@link"))
			{
				textCommand.Parameters.AddWithValue("link", link);
				SqlHelper.ExecuteNonQuery(textCommand);
			}
		}

		// Token: 0x0600089B RID: 2203 RVA: 0x0003F5CC File Offset: 0x0003D7CC
		internal static void RenameItemByLink(string newName, string newDescription, string newMenuBar, string link)
		{
			using (SqlCommand textCommand = SqlHelper.GetTextCommand(" declare @position int\r\n\t\t\t\t\t\t\tdeclare @oldMenuBar varchar(200)\r\n\t\t\t\t\t\t\tdeclare @menuItemID int\r\n\r\n\t\t\t\t\t\t\tSELECT TOP 1 @oldMenuBar = MenuBars.MenuName, @menuItemID = MenuItems.MenuItemID FROM MenuBars\r\n\t\t\t\t\t\t\tINNER JOIN MenuItems ON MenuItems.MenuItemID = MenuBars.MenuItemID\r\n\t\t\t\t\t\t\tWHERE MenuItems.Link=@link\r\n\r\n\t\t\t\t\t\t\tIF @oldMenuBar = @menuName\r\n\t\t\t\t\t\t\t\tBEGIN\r\n\t\t\t\t\t\t\t\t\tUPDATE MenuItems SET Title=@title, Description=@description WHERE Link=@link\r\n\t\t\t\t\t\t\t\tEND\r\n\t\t\t\t\t\t\tELSE\r\n\t\t\t\t\t\t\t\tBEGIN\r\n\t\t\t\t\t\t\t\t\tSELECT @position = (SELECT MAX(Position) FROM MenuBars WHERE MenuName LIKE @menuName) + 1\r\n\r\n\t\t\t\t\t\t\t\t\tUPDATE MenuItems SET Title=@title, Description=@description WHERE Link=@link\r\n\t\t\t\t\t\t\t\t\tUPDATE MenuBars SET MenuName=@menuName, Position=@position WHERE MenuItemID=@menuItemID\r\n\t\t\t\t\t\t\t\tEND"))
			{
				textCommand.Parameters.AddWithValue("title", newName);
				textCommand.Parameters.AddWithValue("description", newDescription);
				textCommand.Parameters.AddWithValue("menuName", newMenuBar);
				textCommand.Parameters.AddWithValue("link", link);
				SqlHelper.ExecuteNonQuery(textCommand);
			}
		}

		// Token: 0x020001A8 RID: 424
		private static class Fields
		{
			// Token: 0x0400055D RID: 1373
			public const string ID = "MenuItemID";

			// Token: 0x0400055E RID: 1374
			public const string Title = "Title";

			// Token: 0x0400055F RID: 1375
			public const string Link = "Link";

			// Token: 0x04000560 RID: 1376
			public const string NewWindow = "NewWindow";

			// Token: 0x04000561 RID: 1377
			public const string Description = "Description";
		}
	}
}
