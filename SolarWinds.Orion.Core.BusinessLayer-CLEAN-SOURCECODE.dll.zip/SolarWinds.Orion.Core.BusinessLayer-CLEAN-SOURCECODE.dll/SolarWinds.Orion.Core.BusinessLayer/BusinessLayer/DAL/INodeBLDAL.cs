﻿using System;
using System.Collections.Generic;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000A6 RID: 166
	public interface INodeBLDAL
	{
		// Token: 0x060007DC RID: 2012
		Node GetNode(int nodeId);

		// Token: 0x060007DD RID: 2013
		Node GetNodeWithOptions(int nodeId, bool includeInterfaces, bool includeVolumes);

		// Token: 0x060007DE RID: 2014
		void UpdateNode(Node node);

		// Token: 0x060007DF RID: 2015
		Nodes GetNodes(bool includeInterfaces, bool includeVolumes);

		// Token: 0x060007E0 RID: 2016
		void UpdateNode(IDictionary<string, object> properties, int nodeId);
	}
}
