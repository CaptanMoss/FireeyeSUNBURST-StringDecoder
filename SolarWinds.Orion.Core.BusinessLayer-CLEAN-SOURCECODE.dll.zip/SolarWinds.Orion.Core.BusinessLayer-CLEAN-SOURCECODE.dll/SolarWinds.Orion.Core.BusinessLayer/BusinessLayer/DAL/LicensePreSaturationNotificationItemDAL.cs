﻿using System;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000087 RID: 135
	public sealed class LicensePreSaturationNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000680 RID: 1664 RVA: 0x000271EA File Offset: 0x000253EA
		private static string NotificationMessage
		{
			get
			{
				return string.Format(Resources.Notification_LicensePreSaturation, Settings.LicenseSaturationPercentage);
			}
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x00027200 File Offset: 0x00025400
		protected override Guid GetNotificationItemTypeId()
		{
			return GenericNotificationItem.LicensePreSaturationNotificationTypeGuid;
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x00027207 File Offset: 0x00025407
		public static LicensePreSaturationNotificationItemDAL GetItem()
		{
			return NotificationItemDAL.GetItemById<LicensePreSaturationNotificationItemDAL>(LicensePreSaturationNotificationItemDAL.LicensePreSaturationNotificationItemId);
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x00027214 File Offset: 0x00025414
		public static void Show()
		{
			LicensePreSaturationNotificationItemDAL item = LicensePreSaturationNotificationItemDAL.GetItem();
			if (item == null)
			{
				NotificationItemDAL.Insert<LicensePreSaturationNotificationItemDAL>(LicensePreSaturationNotificationItemDAL.LicensePreSaturationNotificationItemId, LicensePreSaturationNotificationItemDAL.NotificationMessage, string.Empty, false, "javascript:SW.Core.SalesTrigger.ShowLicensePopupAsync();", null, null);
				return;
			}
			item.SetNotAcknowledged();
			item.Update();
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x0002725D File Offset: 0x0002545D
		public static void Hide()
		{
			NotificationItemDAL.Delete(LicensePreSaturationNotificationItemDAL.LicensePreSaturationNotificationItemId);
		}

		// Token: 0x04000213 RID: 531
		public static readonly Guid LicensePreSaturationNotificationItemId = new Guid("{C95EC3BD-9CBB-D82A-824C-482d6B138550}");

		// Token: 0x04000214 RID: 532
		private const string popupCallFunction = "javascript:SW.Core.SalesTrigger.ShowLicensePopupAsync();";
	}
}
