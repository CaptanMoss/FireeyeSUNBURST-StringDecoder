﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000A9 RID: 169
	public class NotificationItemFilter
	{
		// Token: 0x17000103 RID: 259
		// (get) Token: 0x0600081A RID: 2074 RVA: 0x0003AAA9 File Offset: 0x00038CA9
		// (set) Token: 0x0600081B RID: 2075 RVA: 0x0003AAB1 File Offset: 0x00038CB1
		public bool IncludeAcknowledged { get; set; }

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x0600081C RID: 2076 RVA: 0x0003AABA File Offset: 0x00038CBA
		// (set) Token: 0x0600081D RID: 2077 RVA: 0x0003AAC2 File Offset: 0x00038CC2
		public bool IncludeIgnored { get; set; }

		// Token: 0x0600081E RID: 2078 RVA: 0x0003AACB File Offset: 0x00038CCB
		public NotificationItemFilter(bool includeAcknowledged, bool includeIgnored)
		{
			this.IncludeAcknowledged = includeAcknowledged;
			this.IncludeIgnored = includeIgnored;
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x0003AAE1 File Offset: 0x00038CE1
		public NotificationItemFilter() : this(false, false)
		{
		}
	}
}
