﻿using System;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000AD RID: 173
	public sealed class ScheduledDiscoveryNotificationItemDAL : GenericPopupNotificationItemDAL
	{
		// Token: 0x06000874 RID: 2164 RVA: 0x0003CF14 File Offset: 0x0003B114
		public ScheduledDiscoveryNotificationItemDAL GetItem()
		{
			return NotificationItemDAL.GetItemById<ScheduledDiscoveryNotificationItemDAL>(ScheduledDiscoveryNotificationItemDAL.ScheduledDiscoveryNotificationItemId);
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x0003CF20 File Offset: 0x0003B120
		protected override Guid GetNotificationItemTypeId()
		{
			return GenericNotificationItem.ScheduledDiscoveryNotificationTypeGuid;
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x0003CF27 File Offset: 0x0003B127
		protected override Guid GetPopupNotificationItemId()
		{
			return ScheduledDiscoveryNotificationItemDAL.ScheduledDiscoveryNotificationItemId;
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x0003CF2E File Offset: 0x0003B12E
		public static ScheduledDiscoveryNotificationItemDAL Create(string title, string url)
		{
			return GenericPopupNotificationItemDAL.Create<ScheduledDiscoveryNotificationItemDAL>(title, url);
		}

		// Token: 0x0400026D RID: 621
		public static readonly Guid ScheduledDiscoveryNotificationItemId = new Guid("3D28249D-EFE1-462e-B1A7-C55273D09AE8");
	}
}
