﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Auditing;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Auditing;
using SolarWinds.Orion.Core.Common.Indications;
using SolarWinds.Orion.Core.Common.InformationService;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Common.Swis;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x0200008D RID: 141
	public class AuditingDAL
	{
		// Token: 0x060006C2 RID: 1730 RVA: 0x0002A950 File Offset: 0x00028B50
		public List<AuditActionTypeInfo> GetAuditingActionTypes()
		{
			object obj = this.locker;
			List<AuditActionTypeInfo> result;
			lock (obj)
			{
				if (this.actionTypes.Count == 0)
				{
					this.LoadKeys();
				}
				result = (from i in this.actionTypes
				select new AuditActionTypeInfo
				{
					ActionType = i.Key.ToString(),
					ActionTypeId = i.Value
				}).ToList<AuditActionTypeInfo>();
			}
			return result;
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x0002A9D0 File Offset: 0x00028BD0
		public bool LoadKeys()
		{
			AuditingDAL.log.Verbose("LoadKeys...");
			bool result = false;
			object obj = this.locker;
			lock (obj)
			{
				this.actionTypes.Clear();
				try
				{
					using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT ActionTypeID, ActionType FROM AuditingActionTypes;"))
					{
						using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
						{
							while (dataReader.Read())
							{
								try
								{
									this.actionTypes.Add(new AuditActionType(dataReader["ActionType"].ToString()), Convert.ToInt32(dataReader["ActionTypeID"]));
								}
								catch (ArgumentException ex)
								{
									AuditingDAL.log.ErrorFormat("AuditingDAL had problems with loading list of actionTypes. Exception: {0}", ex);
								}
								result = true;
							}
						}
					}
				}
				catch (Exception ex2)
				{
					AuditingDAL.log.ErrorFormat("AuditingDAL couldn't get list of actionTypes. Exception: {0}", ex2);
				}
			}
			AuditingDAL.log.Verbose("LoadKeys finished.");
			return result;
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x0002AB00 File Offset: 0x00028D00
		protected int GetActionIdFromActionType(AuditActionType actionType)
		{
			if (AuditingDAL.log.IsDebugEnabled)
			{
				AuditingDAL.log.DebugFormat("GetActionIdFromActionType for {0}", actionType);
			}
			int result = -1;
			object obj = this.locker;
			lock (obj)
			{
				if (this.actionTypes.TryGetValue(actionType, out result))
				{
					return result;
				}
			}
			if (this.LoadKeys())
			{
				obj = this.locker;
				lock (obj)
				{
					if (this.actionTypes.TryGetValue(actionType, out result))
					{
						return result;
					}
				}
			}
			throw new ArgumentException(string.Format("ActionType {0} was not found in dictionary.", actionType));
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x0002ABC4 File Offset: 0x00028DC4
		public AuditActionType GetActionTypeFromActionId(int actionTypeId)
		{
			if (AuditingDAL.log.IsDebugEnabled)
			{
				AuditingDAL.log.DebugFormat("GetActionTypeFromActionId for {0}", actionTypeId);
			}
			object obj = this.locker;
			lock (obj)
			{
				IEnumerable<KeyValuePair<AuditActionType, int>> source = this.actionTypes;
				Func<KeyValuePair<AuditActionType, int>, bool> <>9__0;
				Func<KeyValuePair<AuditActionType, int>, bool> predicate;
				if ((predicate = <>9__0) == null)
				{
					predicate = (<>9__0 = ((KeyValuePair<AuditActionType, int> actionType) => actionType.Value == actionTypeId));
				}
				using (IEnumerator<KeyValuePair<AuditActionType, int>> enumerator = source.Where(predicate).GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						KeyValuePair<AuditActionType, int> keyValuePair = enumerator.Current;
						return keyValuePair.Key;
					}
				}
			}
			if (this.LoadKeys())
			{
				obj = this.locker;
				lock (obj)
				{
					IEnumerable<KeyValuePair<AuditActionType, int>> source2 = this.actionTypes;
					Func<KeyValuePair<AuditActionType, int>, bool> <>9__1;
					Func<KeyValuePair<AuditActionType, int>, bool> predicate2;
					if ((predicate2 = <>9__1) == null)
					{
						predicate2 = (<>9__1 = ((KeyValuePair<AuditActionType, int> actionType) => actionType.Value == actionTypeId));
					}
					using (IEnumerator<KeyValuePair<AuditActionType, int>> enumerator = source2.Where(predicate2).GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							KeyValuePair<AuditActionType, int> keyValuePair2 = enumerator.Current;
							return keyValuePair2.Key;
						}
					}
				}
			}
			throw new ArgumentException(string.Format("ActionTypeId {0} was not found in dictionary.", actionTypeId));
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x0002AD4C File Offset: 0x00028F4C
		public static string GetNodeCaption(int nodeId)
		{
			string text = string.Format("SELECT Caption FROM Nodes WHERE NodeId = @NodeId", Array.Empty<object>());
			string result;
			try
			{
				using (SqlCommand textCommand = SqlHelper.GetTextCommand(text))
				{
					textCommand.Parameters.AddWithValue("@NodeId", nodeId);
					result = (string)SqlHelper.ExecuteScalar(textCommand);
				}
			}
			catch (Exception ex)
			{
				AuditingDAL.log.Warn("GetNodeCaption failed.", ex);
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x0002ADD8 File Offset: 0x00028FD8
		public static KeyValuePair<string, string> GetNodeCaptionAndStatus(int nodeId)
		{
			string text = string.Format("SELECT Caption, Status FROM Nodes WHERE NodeId = @NodeId", Array.Empty<object>());
			try
			{
				using (SqlCommand textCommand = SqlHelper.GetTextCommand(text))
				{
					textCommand.Parameters.AddWithValue("@NodeId", nodeId);
					using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
					{
						if (dataReader.Read())
						{
							return new KeyValuePair<string, string>(dataReader["Caption"].ToString(), dataReader["Status"].ToString());
						}
					}
				}
			}
			catch (Exception ex)
			{
				AuditingDAL.log.Warn("GetNodeCaptionAndStatus failed.", ex);
			}
			return default(KeyValuePair<string, string>);
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x0002AEB0 File Offset: 0x000290B0
		public int StoreNotification(AuditDatabaseDecoratedContainer container)
		{
			if (container == null)
			{
				throw new ArgumentNullException("container");
			}
			return this.StoreNotification(container, this.GetActionIdFromActionType(container.ActionType));
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x0002AED4 File Offset: 0x000290D4
		private AuditingDAL.NetObjectInfo GetNetObjectInfo(IDictionary<string, string> arguments)
		{
			int? networkNodeID = null;
			int? num = null;
			string text = null;
			if (arguments.ContainsKey(KnownKeys.NetObject) && arguments[KnownKeys.NetObject] != null)
			{
				string[] array = NetObjectHelper.ParseNetObject(arguments[KnownKeys.NetObject]);
				text = array[0];
				num = new int?(int.Parse(array[1]));
			}
			if (arguments.ContainsKey(KnownKeys.NodeID))
			{
				networkNodeID = new int?(int.Parse(arguments[KnownKeys.NodeID]));
			}
			else if (text != null && text.Equals("N", StringComparison.OrdinalIgnoreCase))
			{
				networkNodeID = num;
			}
			return new AuditingDAL.NetObjectInfo
			{
				NetObjectID = num,
				NetObjectType = text,
				NetworkNodeID = networkNodeID
			};
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x0002AF84 File Offset: 0x00029184
		protected int StoreNotification(AuditDatabaseDecoratedContainer decoratedDecoratedContainer, int actionTypeId)
		{
			if (AuditingDAL.log.IsTraceEnabled)
			{
				AuditingDAL.log.Trace("StoreNotification actionTypeId: " + actionTypeId);
			}
			int count = decoratedDecoratedContainer.Args.Count;
			if (AuditingDAL.log.IsDebugEnabled)
			{
				AuditingDAL.log.Debug("args.Count: " + count);
			}
			AuditingDAL.NetObjectInfo netObjectInfo = this.GetNetObjectInfo(decoratedDecoratedContainer.Args);
			StringBuilder stringBuilder = new StringBuilder("\r\nDECLARE @msg VARCHAR(max), @sev INT, @st INT;\r\n\r\n    INSERT INTO [dbo].[AuditingEvents] \r\n    (\r\n        [TimeLoggedUtc], \r\n        [AccountID], \r\n        [ActionTypeID], \r\n        [AuditEventMessage],\r\n        [NetworkNode],\r\n        [NetObjectID],\r\n        [NetObjectType]\r\n    )\r\n    VALUES\r\n    (\r\n        @TimeLoggedUtc, \r\n        @AccountID, \r\n        @ActionTypeID, \r\n        @AuditEventMessage,\r\n        @NetworkNode,\r\n        @NetObjectID,\r\n        @NetObjectType\r\n    );\r\n");
			if (count > 0)
			{
				stringBuilder.Append("  SELECT @lastID = @@IDENTITY;\r\n\r\n    INSERT INTO [dbo].[AuditingArguments] \r\n    ([AuditEventID], [ArgsKey], [ArgsValue])\r\n     ");
				stringBuilder.Append(string.Join(" UNION ALL ", from i in Enumerable.Range(0, count)
				select string.Format(" SELECT @lastID, @ArgsKey{0}, @ArgsValue{0} ", i)));
			}
			int result;
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction())
				{
					using (SqlCommand textCommand = SqlHelper.GetTextCommand(stringBuilder.ToString()))
					{
						try
						{
							textCommand.Parameters.AddWithValue("@TimeLoggedUtc", decoratedDecoratedContainer.IndicationTime.ToUniversalTime());
							textCommand.Parameters.AddWithValue("@AccountID", decoratedDecoratedContainer.AccountId.ToLower());
							textCommand.Parameters.AddWithValue("@ActionTypeID", actionTypeId);
							textCommand.Parameters.AddWithValue("@AuditEventMessage", decoratedDecoratedContainer.Message);
							textCommand.Parameters.AddWithValue("@NetworkNode", (netObjectInfo.NetworkNodeID != null) ? netObjectInfo.NetworkNodeID.Value : DBNull.Value);
							textCommand.Parameters.AddWithValue("@NetObjectID", (netObjectInfo.NetObjectID != null) ? netObjectInfo.NetObjectID.Value : DBNull.Value);
							textCommand.Parameters.AddWithValue("@NetObjectType", (netObjectInfo.NetObjectType != null) ? netObjectInfo.NetObjectType : DBNull.Value);
							textCommand.Parameters.Add(new SqlParameter("@lastID", SqlDbType.Int)
							{
								Direction = ParameterDirection.InputOutput,
								Value = 0
							});
							for (int j = 0; j < count; j++)
							{
								string key = decoratedDecoratedContainer.Args.ElementAt(j).Key;
								string value = decoratedDecoratedContainer.Args.ElementAt(j).Value;
								if (AuditingDAL.log.IsDebugEnabled)
								{
									AuditingDAL.log.DebugFormat("Adding argument: '{0}':'{1}'", key, value);
								}
								textCommand.Parameters.AddWithValue(string.Format("@ArgsKey{0}", j), key);
								textCommand.Parameters.AddWithValue(string.Format("@ArgsValue{0}", j), value ?? string.Empty);
							}
							AuditingDAL.log.Trace("Executing query.");
							SqlHelper.ExecuteScalar(textCommand, sqlConnection, sqlTransaction);
							sqlTransaction.Commit();
							int num = 0;
							int.TryParse(textCommand.Parameters["@lastID"].Value.ToString(), out num);
							result = num;
						}
						catch (Exception ex)
						{
							sqlTransaction.Rollback();
							AuditingDAL.log.Error("Error while storing notification.", ex);
							throw;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x0002B348 File Offset: 0x00029548
		internal static DataTable GetAuditingTable(int maxRecords, int netObjectId, string netObjectType, int nodeId, string actionTypeIds, DateTime startTime, DateTime endTime)
		{
			string format = "\r\n;WITH TOPNAUDITS\r\nAS\r\n(\r\n\tSELECT TOP (@parTopLimit)\r\n\t\tAE.TimeLoggedUtc AS DateTime,\r\n\t\tAE.AccountID,\r\n\t\tAE.AuditEventMessage AS Message,\r\n\t\tAE.AuditEventID,\r\n\t\tAE.ActionTypeID    \r\n\tFROM AuditingEvents AS AE WITH(NOLOCK)\r\n\tWHERE\r\n\t{0}        \r\n\tORDER BY\r\n\t\tAE.TimeLoggedUtc DESC\r\n)\r\nSELECT \r\n    TNA.DateTime,\r\n    TNA.AccountID,\r\n    TNA.Message,\r\n    TNA.AuditEventID,\r\n    TNA.ActionTypeID,\r\n    AAT.ActionType,\r\n    ARGS.ArgsKey,\r\n    ARGS.ArgsValue\r\nFROM TOPNAUDITS AS TNA\r\nLEFT JOIN AuditingActionTypes AS AAT WITH(NOLOCK)\r\nON\r\n    TNA.ActionTypeID = AAT.ActionTypeID\r\nLEFT JOIN AuditingArguments AS ARGS WITH(NOLOCK)\r\n\tON TNA.AuditEventID = ARGS.AuditEventID\r\nORDER BY TNA.[DateTime] DESC\r\n";
			DataTable result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand(string.Empty))
			{
				List<string> list = new List<string>();
				list.Add("1 = 1");
				textCommand.Parameters.AddWithValue("@parTopLimit", maxRecords);
				list.Add("AE.TimeLoggedUtc >= @parStartTime");
				textCommand.Parameters.AddWithValue("@parStartTime", startTime);
				list.Add("AE.TimeLoggedUtc <= @parEndTime");
				textCommand.Parameters.AddWithValue("@parEndTime", endTime);
				if (nodeId >= 0 && netObjectId < 0)
				{
					list.Add("AE.NetworkNode = @parNodeID");
					textCommand.Parameters.Add(new SqlParameter("@parNodeID", nodeId));
				}
				if (netObjectId >= 0)
				{
					list.Add("AE.NetObjectID = @parNetObjectID");
					textCommand.Parameters.Add(new SqlParameter("@parNetObjectID", netObjectId));
				}
				if (!string.IsNullOrEmpty(netObjectType))
				{
					list.Add("AE.NetObjectType LIKE @parNetObjectType");
					textCommand.Parameters.Add(new SqlParameter("@parNetObjectType", SqlDbType.Char, 10)
					{
						Value = netObjectType
					});
				}
				if (!string.IsNullOrEmpty(actionTypeIds))
				{
					list.Add(" AE.ActionTypeID IN (" + actionTypeIds + ")");
				}
				string arg = string.Join(" AND " + Environment.NewLine, list);
				string commandText = string.Format(format, arg);
				textCommand.CommandText = commandText;
				DataTable dataTable = SqlHelper.ExecuteDataTable(textCommand);
				dataTable.TableName = "AuditingTable";
				result = dataTable;
			}
			return result;
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x0002B4E8 File Offset: 0x000296E8
		public static DataTable GetAuditingTypesTable()
		{
			DataTable result;
			using (IInformationServiceProxy2 informationServiceProxy = AuditingDAL.creator.Create())
			{
				DataTable dataTable = InformationServiceProxyExtensions.QueryWithAppendedErrors(informationServiceProxy, "SELECT DISTINCT ActionTypeID, ActionType, ActionTypeDisplayName FROM [Orion].[AuditingActionTypes] (nolock=true)", SwisFederationInfo.IsFederationEnabled);
				dataTable.TableName = "AuditingTypesTable";
				result = dataTable;
			}
			return result;
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x0002B53C File Offset: 0x0002973C
		public AuditDataContainer GetAuditDataContainer(int auditEventId)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT [ArgsKey], [ArgsValue] FROM [dbo].[AuditingArguments] WITH(NOLOCK) WHERE [AuditEventID] = @AuditEventID;"))
			{
				textCommand.Parameters.AddWithValue("@AuditEventID", auditEventId);
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
				{
					while (dataReader.Read())
					{
						dictionary.Add(dataReader["ArgsKey"].ToString(), dataReader["ArgsValue"].ToString());
					}
				}
			}
			AuditDataContainer result;
			using (SqlCommand textCommand2 = SqlHelper.GetTextCommand("SELECT TOP 1 [AccountID], [ActionTypeID] FROM [dbo].[AuditingEvents] WITH(NOLOCK) WHERE [AuditEventID] = @AuditEventID;"))
			{
				textCommand2.Parameters.AddWithValue("@AuditEventID", auditEventId);
				using (IDataReader dataReader2 = SqlHelper.ExecuteReader(textCommand2))
				{
					dataReader2.Read();
					result = new AuditDataContainer(this.GetActionTypeFromActionId((int)dataReader2["ActionTypeID"]), dictionary, dataReader2["AccountID"].ToString());
				}
			}
			return result;
		}

		// Token: 0x0400021C RID: 540
		protected static readonly Log log = new Log();

		// Token: 0x0400021D RID: 541
		protected readonly object locker = new object();

		// Token: 0x0400021E RID: 542
		protected readonly Dictionary<AuditActionType, int> actionTypes = new Dictionary<AuditActionType, int>();

		// Token: 0x0400021F RID: 543
		private static readonly IInformationServiceProxyCreator creator = SwisConnectionProxyPool.GetCreator();

		// Token: 0x02000180 RID: 384
		private class NetObjectInfo
		{
			// Token: 0x1700015C RID: 348
			// (get) Token: 0x06000C29 RID: 3113 RVA: 0x0004B053 File Offset: 0x00049253
			// (set) Token: 0x06000C2A RID: 3114 RVA: 0x0004B05B File Offset: 0x0004925B
			public int? NetworkNodeID { get; set; }

			// Token: 0x1700015D RID: 349
			// (get) Token: 0x06000C2B RID: 3115 RVA: 0x0004B064 File Offset: 0x00049264
			// (set) Token: 0x06000C2C RID: 3116 RVA: 0x0004B06C File Offset: 0x0004926C
			public int? NetObjectID { get; set; }

			// Token: 0x1700015E RID: 350
			// (get) Token: 0x06000C2D RID: 3117 RVA: 0x0004B075 File Offset: 0x00049275
			// (set) Token: 0x06000C2E RID: 3118 RVA: 0x0004B07D File Offset: 0x0004927D
			public string NetObjectType { get; set; }
		}
	}
}
