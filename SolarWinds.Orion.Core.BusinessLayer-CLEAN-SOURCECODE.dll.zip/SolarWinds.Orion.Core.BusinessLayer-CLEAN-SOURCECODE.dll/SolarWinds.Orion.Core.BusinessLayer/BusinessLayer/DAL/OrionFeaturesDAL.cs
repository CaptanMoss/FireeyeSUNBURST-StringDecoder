﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Data;
using SolarWinds.Orion.Core.Models.OrionFeature;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x0200008A RID: 138
	internal class OrionFeaturesDAL : IOrionFeaturesDAL
	{
		// Token: 0x06000694 RID: 1684 RVA: 0x00027678 File Offset: 0x00025878
		public IEnumerable<OrionFeature> GetItems()
		{
			return EntityHydrator.PopulateCollectionFromSql<OrionFeature>("SELECT Name, Enabled FROM OrionFeatures");
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x00027684 File Offset: 0x00025884
		public void Update(IEnumerable<OrionFeature> features)
		{
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction())
				{
					SqlHelper.ExecuteNonQuery(SqlHelper.GetTextCommand("TRUNCATE TABLE OrionFeatures"), sqlConnection, sqlTransaction);
					using (EnumerableDataReader<OrionFeature> enumerableDataReader = new EnumerableDataReader<OrionFeature>(new SinglePropertyAccessor<OrionFeature>().AddColumn("Name", (OrionFeature n) => n.Name).AddColumn("Enabled", (OrionFeature n) => n.Enabled), features))
					{
						SqlHelper.ExecuteBulkCopy("OrionFeatures", enumerableDataReader, sqlConnection, sqlTransaction, SqlBulkCopyOptions.Default);
					}
					sqlTransaction.Commit();
				}
			}
		}
	}
}
