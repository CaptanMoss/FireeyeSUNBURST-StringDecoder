﻿using System;
using SolarWinds.Orion.Core.Models.MaintenanceMode;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000086 RID: 134
	public interface IMaintenanceModePlanDAL
	{
		// Token: 0x0600067C RID: 1660
		string Create(MaintenancePlan plan);

		// Token: 0x0600067D RID: 1661
		MaintenancePlan Get(int planID);

		// Token: 0x0600067E RID: 1662
		MaintenancePlan Get(string entityUri);

		// Token: 0x0600067F RID: 1663
		void Update(string entityUri, MaintenancePlan plan);
	}
}
