﻿using System;
using System.Collections.Generic;
using SolarWinds.Orion.Core.Models.OrionFeature;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000089 RID: 137
	internal interface IOrionFeaturesDAL
	{
		// Token: 0x06000692 RID: 1682
		void Update(IEnumerable<OrionFeature> features);

		// Token: 0x06000693 RID: 1683
		IEnumerable<OrionFeature> GetItems();
	}
}
