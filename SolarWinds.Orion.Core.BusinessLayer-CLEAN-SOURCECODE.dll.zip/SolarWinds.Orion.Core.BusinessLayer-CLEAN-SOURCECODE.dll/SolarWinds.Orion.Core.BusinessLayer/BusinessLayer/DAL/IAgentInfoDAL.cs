﻿using System;
using System.Collections.Generic;
using SolarWinds.Orion.Core.Common.Agent;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000092 RID: 146
	public interface IAgentInfoDAL
	{
		// Token: 0x060006E5 RID: 1765
		IEnumerable<AgentInfo> GetAgentsInfo();

		// Token: 0x060006E6 RID: 1766
		IEnumerable<AgentInfo> GetAgentsByNodesFilter(int engineId, string nodesFilter);

		// Token: 0x060006E7 RID: 1767
		AgentInfo GetAgentInfoByNode(int nodeId);

		// Token: 0x060006E8 RID: 1768
		AgentInfo GetAgentInfo(int agentId);

		// Token: 0x060006E9 RID: 1769
		AgentInfo GetAgentInfoByIpOrHostname(string ipAddress, string hostname);

		// Token: 0x060006EA RID: 1770
		AgentInfo GetAgentInfoByAgentAddress(string address);

		// Token: 0x060006EB RID: 1771
		bool IsUniqueAgentName(string agentName);
	}
}
