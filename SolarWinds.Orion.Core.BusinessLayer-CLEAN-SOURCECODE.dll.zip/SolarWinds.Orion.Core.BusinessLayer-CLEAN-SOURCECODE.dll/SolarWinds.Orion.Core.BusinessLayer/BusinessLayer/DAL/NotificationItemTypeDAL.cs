﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Enums;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Discovery.DataAccess;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000B4 RID: 180
	public sealed class NotificationItemTypeDAL
	{
		// Token: 0x17000110 RID: 272
		// (get) Token: 0x060008A6 RID: 2214 RVA: 0x0003FA97 File Offset: 0x0003DC97
		// (set) Token: 0x060008A7 RID: 2215 RVA: 0x0003FA9F File Offset: 0x0003DC9F
		public Guid Id { get; set; }

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x060008A8 RID: 2216 RVA: 0x0003FAA8 File Offset: 0x0003DCA8
		// (set) Token: 0x060008A9 RID: 2217 RVA: 0x0003FAB0 File Offset: 0x0003DCB0
		public string TypeName { get; set; }

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x060008AA RID: 2218 RVA: 0x0003FAB9 File Offset: 0x0003DCB9
		// (set) Token: 0x060008AB RID: 2219 RVA: 0x0003FAC1 File Offset: 0x0003DCC1
		public string Module { get; set; }

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x060008AC RID: 2220 RVA: 0x0003FACA File Offset: 0x0003DCCA
		// (set) Token: 0x060008AD RID: 2221 RVA: 0x0003FAD2 File Offset: 0x0003DCD2
		public string Caption { get; set; }

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x060008AE RID: 2222 RVA: 0x0003FADB File Offset: 0x0003DCDB
		// (set) Token: 0x060008AF RID: 2223 RVA: 0x0003FAE3 File Offset: 0x0003DCE3
		public string DetailsUrl { get; set; }

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x060008B0 RID: 2224 RVA: 0x0003FAEC File Offset: 0x0003DCEC
		// (set) Token: 0x060008B1 RID: 2225 RVA: 0x0003FAF4 File Offset: 0x0003DCF4
		public string DetailsCaption { get; set; }

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x060008B2 RID: 2226 RVA: 0x0003FAFD File Offset: 0x0003DCFD
		// (set) Token: 0x060008B3 RID: 2227 RVA: 0x0003FB05 File Offset: 0x0003DD05
		public string Icon { get; set; }

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x060008B4 RID: 2228 RVA: 0x0003FB0E File Offset: 0x0003DD0E
		// (set) Token: 0x060008B5 RID: 2229 RVA: 0x0003FB16 File Offset: 0x0003DD16
		public string Description { get; set; }

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x060008B6 RID: 2230 RVA: 0x0003FB1F File Offset: 0x0003DD1F
		// (set) Token: 0x060008B7 RID: 2231 RVA: 0x0003FB27 File Offset: 0x0003DD27
		public List<NotificationItemType.Roles> RequiredRoles { get; private set; }

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x060008B8 RID: 2232 RVA: 0x0003FB30 File Offset: 0x0003DD30
		// (set) Token: 0x060008B9 RID: 2233 RVA: 0x0003FB38 File Offset: 0x0003DD38
		public NotificationTypeDisplayAs DisplayAs { get; set; }

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x060008BA RID: 2234 RVA: 0x0003FB41 File Offset: 0x0003DD41
		// (set) Token: 0x060008BB RID: 2235 RVA: 0x0003FB49 File Offset: 0x0003DD49
		public string CustomDismissButtonText { get; set; }

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x060008BC RID: 2236 RVA: 0x0003FB52 File Offset: 0x0003DD52
		// (set) Token: 0x060008BD RID: 2237 RVA: 0x0003FB5A File Offset: 0x0003DD5A
		public bool HideDismissButton { get; set; }

		// Token: 0x060008BE RID: 2238 RVA: 0x0003FB64 File Offset: 0x0003DD64
		private NotificationItemTypeDAL()
		{
			this.Id = Guid.Empty;
			this.TypeName = string.Empty;
			this.Module = string.Empty;
			this.Caption = string.Empty;
			this.DetailsUrl = string.Empty;
			this.DetailsCaption = string.Empty;
			this.Icon = string.Empty;
			this.Description = string.Empty;
			this.DisplayAs = 0;
			this.RequiredRoles = new List<NotificationItemType.Roles>();
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x0003FBE4 File Offset: 0x0003DDE4
		public static NotificationItemTypeDAL GetTypeById(Guid typeId)
		{
			NotificationItemTypeDAL result;
			try
			{
				result = NotificationItemTypeDAL.GetTypes().FirstOrDefault((NotificationItemTypeDAL x) => x.Id == typeId);
			}
			catch (ResultCountException)
			{
				NotificationItemTypeDAL.log.DebugFormat("Can't find notification item type in database: ID={0}", typeId);
				result = null;
			}
			return result;
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x0003FC48 File Offset: 0x0003DE48
		public static ICollection<NotificationItemTypeDAL> GetTypes()
		{
			List<NotificationItemTypeDAL> cachedTypes = NotificationItemTypeDAL._cachedTypes;
			if (cachedTypes != null)
			{
				return cachedTypes;
			}
			NotificationItemTypeDAL._cachedTypes = NotificationItemTypeDAL.LoadAllTypes();
			return NotificationItemTypeDAL._cachedTypes;
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x0003FC70 File Offset: 0x0003DE70
		private static List<NotificationItemTypeDAL> LoadAllTypes()
		{
			List<NotificationItemTypeDAL> list = NotificationItemTypeDAL.LoadCollectionFromDB();
			Dictionary<Guid, List<NotificationItemType.Roles>> dictionary = NotificationItemTypeDAL.LoadRolesFromDB();
			foreach (NotificationItemTypeDAL notificationItemTypeDAL in list)
			{
				if (dictionary.ContainsKey(notificationItemTypeDAL.Id))
				{
					notificationItemTypeDAL.RequiredRoles = dictionary[notificationItemTypeDAL.Id];
				}
			}
			return list;
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x0003FCE4 File Offset: 0x0003DEE4
		private static List<NotificationItemTypeDAL> LoadCollectionFromDB()
		{
			List<NotificationItemTypeDAL> result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT * FROM NotificationItemTypes"))
			{
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
				{
					List<NotificationItemTypeDAL> list = new List<NotificationItemTypeDAL>();
					while (dataReader.Read())
					{
						NotificationItemTypeDAL notificationItemTypeDAL = new NotificationItemTypeDAL();
						notificationItemTypeDAL.LoadFromReader(dataReader);
						list.Add(notificationItemTypeDAL);
					}
					result = list;
				}
			}
			return result;
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x0003FD60 File Offset: 0x0003DF60
		private void LoadFromReader(IDataReader reader)
		{
			this.Id = reader.GetGuid(reader.GetOrdinal("TypeID"));
			this.TypeName = reader.GetString(reader.GetOrdinal("TypeName"));
			this.Module = reader.GetString(reader.GetOrdinal("Module"));
			this.Caption = DatabaseFunctions.GetString(reader, "Caption");
			this.DetailsUrl = DatabaseFunctions.GetString(reader, "DetailsUrl");
			this.DetailsCaption = DatabaseFunctions.GetString(reader, "DetailsCaption");
			this.Icon = DatabaseFunctions.GetString(reader, "Icon");
			this.Description = DatabaseFunctions.GetString(reader, "Description");
			this.CustomDismissButtonText = DatabaseFunctions.GetString(reader, "CustomDismissButtonText");
			this.HideDismissButton = DatabaseFunctions.GetBoolean(reader, "HideDismissButton");
			this.DisplayAs = SqlHelper.ParseEnum<NotificationTypeDisplayAs>(reader.GetString(reader.GetOrdinal("DisplayAs")));
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x0003FE48 File Offset: 0x0003E048
		private static Dictionary<Guid, List<NotificationItemType.Roles>> LoadRolesFromDB()
		{
			Dictionary<Guid, List<NotificationItemType.Roles>> dictionary = new Dictionary<Guid, List<NotificationItemType.Roles>>();
			Dictionary<Guid, List<NotificationItemType.Roles>> result;
			using (SqlCommand sqlCommand = new SqlCommand("SELECT NotificationTypeID, RequiredRoleID FROM NotificationTypePermissions"))
			{
				using (IDataReader dataReader = SqlHelper.ExecuteReader(sqlCommand))
				{
					while (dataReader.Read())
					{
						Guid guid = DatabaseFunctions.GetGuid(dataReader, 0);
						int @int = DatabaseFunctions.GetInt32(dataReader, 1);
						if (!dictionary.ContainsKey(guid))
						{
							dictionary[guid] = new List<NotificationItemType.Roles>();
						}
						dictionary[guid].Add(@int);
					}
					result = dictionary;
				}
			}
			return result;
		}

		// Token: 0x04000272 RID: 626
		private static readonly Log log = new Log();

		// Token: 0x04000273 RID: 627
		private static List<NotificationItemTypeDAL> _cachedTypes;
	}
}
