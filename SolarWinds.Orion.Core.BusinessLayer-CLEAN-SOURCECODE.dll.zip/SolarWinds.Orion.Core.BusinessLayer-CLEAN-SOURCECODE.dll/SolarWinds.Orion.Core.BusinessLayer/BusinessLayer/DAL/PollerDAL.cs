﻿using System;
using System.Data;
using System.Data.SqlClient;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000AC RID: 172
	[Obsolete("Please start using SolarWinds.Orion.Core.Common.DALs.PollersDAL instead")]
	public class PollerDAL
	{
		// Token: 0x0600086A RID: 2154 RVA: 0x0003CCA0 File Offset: 0x0003AEA0
		public static PollerAssignment GetPoller(int pollerID)
		{
			PollerAssignment result;
			try
			{
				PollerAssignment assignment = PollerDAL.pollersDAL.GetAssignment(pollerID);
				if (assignment == null)
				{
					throw new NullReferenceException();
				}
				result = assignment;
			}
			catch (Exception)
			{
				throw new ArgumentOutOfRangeException("PollerID", string.Format("Poller with Id {0} does not exist", pollerID));
			}
			return result;
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x0003CCF4 File Offset: 0x0003AEF4
		public static int InsertPoller(PollerAssignment poller)
		{
			int result;
			PollerDAL.pollersDAL.Insert(poller, ref result);
			return result;
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x0003CD0F File Offset: 0x0003AF0F
		public static void DeletePoller(int pollerID)
		{
			PollerDAL.pollersDAL.DeletePollerByID(pollerID);
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x0003CD1C File Offset: 0x0003AF1C
		public static PollerAssignments GetPollersForNode(int nodeId)
		{
			PollerAssignments pollerAssignments = new PollerAssignments();
			pollerAssignments.Add(PollerDAL.pollersDAL.GetNetObjectPollers("N", nodeId, Array.Empty<string>()));
			return pollerAssignments;
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x0003CD40 File Offset: 0x0003AF40
		public static PollerAssignments GetAllPollersForNode(int nodeId, bool includeInterfacePollers)
		{
			PollerAssignments pollerAssignments = new PollerAssignments();
			string text = "SELECT PollerID, PollerType, NetObjectType, NetObjectID, Enabled FROM Pollers WHERE NetObject = @NetObject ";
			if (includeInterfacePollers)
			{
				text += "OR NetObject IN\r\n                        (\r\n                            SELECT 'I:' + RTRIM(LTRIM(STR(InterfaceID))) FROM Interfaces WHERE NodeID=@NodeID\r\n                        )";
			}
			using (SqlCommand textCommand = SqlHelper.GetTextCommand(text))
			{
				if (includeInterfacePollers)
				{
					textCommand.Parameters.AddWithValue("@NodeID", nodeId);
				}
				textCommand.Parameters.Add("@NetObject", SqlDbType.VarChar, 50).Value = string.Format("N:{0}", nodeId);
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
				{
					while (dataReader.Read())
					{
						PollerAssignment pollerAssignment = PollerDAL.CreatePoller(dataReader);
						pollerAssignments.Add(pollerAssignment.PollerID, pollerAssignment);
					}
				}
			}
			return pollerAssignments;
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x0003CE10 File Offset: 0x0003B010
		public static PollerAssignments GetPollersForVolume(int volumeId)
		{
			PollerAssignments pollerAssignments = new PollerAssignments();
			pollerAssignments.Add(PollerDAL.pollersDAL.GetNetObjectPollers("V", volumeId, Array.Empty<string>()));
			return pollerAssignments;
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x0003CE34 File Offset: 0x0003B034
		private static PollerAssignment CreatePoller(IDataReader reader)
		{
			PollerAssignment pollerAssignment = new PollerAssignment();
			for (int i = 0; i < reader.FieldCount; i++)
			{
				string name = reader.GetName(i);
				if (!(name == "PollerType"))
				{
					if (!(name == "NetObjectType"))
					{
						if (!(name == "NetObjectID"))
						{
							if (!(name == "PollerID"))
							{
								if (!(name == "Enabled"))
								{
									throw new ApplicationException("Couldn't create poller - unknown field.");
								}
								pollerAssignment.Enabled = DatabaseFunctions.GetBoolean(reader, i);
							}
							else
							{
								pollerAssignment.PollerID = DatabaseFunctions.GetInt32(reader, i);
							}
						}
						else
						{
							pollerAssignment.NetObjectID = DatabaseFunctions.GetInt32(reader, name);
						}
					}
					else
					{
						pollerAssignment.NetObjectType = DatabaseFunctions.GetString(reader, i);
					}
				}
				else
				{
					pollerAssignment.PollerType = DatabaseFunctions.GetString(reader, i);
				}
			}
			return pollerAssignment;
		}

		// Token: 0x0400026C RID: 620
		private static PollersDAL pollersDAL = new PollersDAL();
	}
}
