﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Extensions;
using SolarWinds.Orion.Core.Common.InformationService;
using SolarWinds.Orion.Core.Models.MaintenanceMode;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000088 RID: 136
	public class MaintenanceModePlanDAL : IMaintenanceModePlanDAL
	{
		// Token: 0x06000687 RID: 1671 RVA: 0x0002727C File Offset: 0x0002547C
		internal static Dictionary<string, object> RemoveKeysFromDictionary(Dictionary<string, object> source, params string[] keysToRemove)
		{
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			if (keysToRemove == null)
			{
				throw new ArgumentNullException("keysToRemove");
			}
			return (from kvp in source
			where !keysToRemove.Contains(kvp.Key)
			select kvp).ToDictionary((KeyValuePair<string, object> kvp) => kvp.Key, (KeyValuePair<string, object> kvp) => kvp.Value);
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x0002730C File Offset: 0x0002550C
		internal static T GetValue<T>(DataRow dataRow, string columnName, Func<object, T> convertFunction, T defaultValue)
		{
			if (!dataRow.Table.Columns.Contains(columnName) || dataRow[columnName] == DBNull.Value)
			{
				return defaultValue;
			}
			return convertFunction(dataRow[columnName]);
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x00027340 File Offset: 0x00025540
		internal static MaintenancePlan DataRowToPlan(DataRow dataRow)
		{
			if (dataRow == null)
			{
				throw new ArgumentNullException("dataRow");
			}
			int id = Convert.ToInt32(dataRow["ID"]);
			string value = MaintenanceModePlanDAL.GetValue<string>(dataRow, "AccountID", new Func<object, string>(Convert.ToString), null);
			string value2 = MaintenanceModePlanDAL.GetValue<string>(dataRow, "Name", new Func<object, string>(Convert.ToString), null);
			string value3 = MaintenanceModePlanDAL.GetValue<string>(dataRow, "Reason", new Func<object, string>(Convert.ToString), null);
			bool value4 = MaintenanceModePlanDAL.GetValue<bool>(dataRow, "KeepPolling", new Func<object, bool>(Convert.ToBoolean), false);
			bool value5 = MaintenanceModePlanDAL.GetValue<bool>(dataRow, "Favorite", new Func<object, bool>(Convert.ToBoolean), false);
			bool value6 = MaintenanceModePlanDAL.GetValue<bool>(dataRow, "Enabled", new Func<object, bool>(Convert.ToBoolean), false);
			DateTime value7 = MaintenanceModePlanDAL.GetValue<DateTime>(dataRow, "UnmanageDate", new Func<object, DateTime>(Convert.ToDateTime), DateTime.MinValue);
			DateTime value8 = MaintenanceModePlanDAL.GetValue<DateTime>(dataRow, "RemanageDate", new Func<object, DateTime>(Convert.ToDateTime), DateTime.MinValue);
			return new MaintenancePlan
			{
				AccountID = value,
				Enabled = value6,
				Favorite = value5,
				ID = id,
				KeepPolling = value4,
				Name = value2,
				Reason = value3,
				RemanageDate = value8,
				UnmanageDate = value7
			};
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x0600068A RID: 1674 RVA: 0x0002748A File Offset: 0x0002568A
		// (set) Token: 0x0600068B RID: 1675 RVA: 0x000274A5 File Offset: 0x000256A5
		public IInformationServiceProxyCreator SwisFactory
		{
			get
			{
				if (this._SwisFactory == null)
				{
					this._SwisFactory = new InformationServiceProxyFactory();
				}
				return this._SwisFactory;
			}
			set
			{
				this._SwisFactory = value;
			}
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x000274B0 File Offset: 0x000256B0
		public string Create(MaintenancePlan plan)
		{
			string result;
			using (IInformationServiceProxy2 informationServiceProxy = this.SwisFactory.Create())
			{
				Dictionary<string, object> dictionary = MaintenanceModePlanDAL.RemoveKeysFromDictionary(ObjectExtensions.ToDictionary<MaintenancePlan>(plan), new string[]
				{
					"ID"
				});
				result = informationServiceProxy.Create("Orion.MaintenancePlan", dictionary);
			}
			return result;
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x00027510 File Offset: 0x00025710
		public void Update(string entityUri, MaintenancePlan plan)
		{
			using (IInformationServiceProxy2 informationServiceProxy = this.SwisFactory.Create())
			{
				Dictionary<string, object> dictionary = MaintenanceModePlanDAL.RemoveKeysFromDictionary(ObjectExtensions.ToDictionary<MaintenancePlan>(plan), new string[]
				{
					"ID"
				});
				informationServiceProxy.Update(entityUri, dictionary);
			}
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x00027568 File Offset: 0x00025768
		public MaintenancePlan Get(string entityUri)
		{
			using (IInformationServiceProxy2 informationServiceProxy = this.SwisFactory.Create())
			{
				DataTable dataTable = informationServiceProxy.Query("\r\n                SELECT TOP 1 ID, AccountID, Name, Reason, KeepPolling, Favorite, Enabled, UnmanageDate, RemanageDate\r\n                FROM Orion.MaintenancePlan\r\n                WHERE Uri = @EntityUri", new Dictionary<string, object>
				{
					{
						"EntityUri",
						entityUri
					}
				});
				if (dataTable != null && dataTable.Rows.Count == 1)
				{
					return MaintenanceModePlanDAL.DataRowToPlan(dataTable.Rows.Cast<DataRow>().FirstOrDefault<DataRow>());
				}
			}
			return null;
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x000275E8 File Offset: 0x000257E8
		public MaintenancePlan Get(int planID)
		{
			using (IInformationServiceProxy2 informationServiceProxy = this.SwisFactory.Create())
			{
				DataTable dataTable = informationServiceProxy.Query("\r\n                SELECT TOP 1 ID, AccountID, Name, Reason, KeepPolling, Favorite, Enabled, UnmanageDate, RemanageDate\r\n                FROM Orion.MaintenancePlan\r\n                WHERE ID = @PlanID", new Dictionary<string, object>
				{
					{
						"PlanID",
						planID
					}
				});
				if (dataTable != null && dataTable.Rows.Count == 1)
				{
					return MaintenanceModePlanDAL.DataRowToPlan(dataTable.Rows.Cast<DataRow>().FirstOrDefault<DataRow>());
				}
			}
			return null;
		}

		// Token: 0x04000215 RID: 533
		private const string entityName = "Orion.MaintenancePlan";

		// Token: 0x04000216 RID: 534
		private static readonly Log log = new Log();

		// Token: 0x04000217 RID: 535
		private IInformationServiceProxyCreator _SwisFactory;
	}
}
