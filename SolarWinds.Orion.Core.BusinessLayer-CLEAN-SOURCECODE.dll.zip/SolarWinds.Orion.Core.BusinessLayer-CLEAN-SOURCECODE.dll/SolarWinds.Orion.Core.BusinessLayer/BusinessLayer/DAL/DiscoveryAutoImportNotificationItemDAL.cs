﻿using System;
using System.Globalization;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Models.Discovery;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000085 RID: 133
	public sealed class DiscoveryAutoImportNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x06000677 RID: 1655 RVA: 0x00027104 File Offset: 0x00025304
		public static DiscoveryAutoImportNotificationItemDAL GetItem()
		{
			return NotificationItemDAL.GetItemById<DiscoveryAutoImportNotificationItemDAL>(DiscoveryAutoImportNotificationItemDAL.DiscoveryAutoImportNotificationItemId);
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x00027110 File Offset: 0x00025310
		public static void Show(DiscoveryResultBase result, StartImportStatus status)
		{
			DiscoveryAutoImportNotificationItemDAL item = DiscoveryAutoImportNotificationItemDAL.GetItem();
			string description = string.Format(CultureInfo.InvariantCulture, "DiscoveryImportStatus:{0}", status);
			string title = string.Empty;
			switch (status)
			{
			case 4:
				title = Resources2.Notification_DiscoveryAutoImport_Failed;
				break;
			case 5:
				title = Resources2.Notification_DiscoveryAutoImport_LicenseExceeded;
				break;
			case 6:
				title = Resources2.Notification_DiscoveryAutoImport_Succeeded;
				break;
			default:
				return;
			}
			if (item == null)
			{
				NotificationItemDAL.Insert(DiscoveryAutoImportNotificationItemDAL.DiscoveryAutoImportNotificationItemId, DiscoveryAutoImportNotificationItemDAL.DiscoveryAutoImportNotificationTypeGuid, title, description, false, DiscoveryAutoImportNotificationItemDAL.NetworkSonarDiscoveryURL, null, null);
				return;
			}
			item.SetNotAcknowledged();
			item.Title = title;
			item.Description = description;
			item.Update();
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x000271AB File Offset: 0x000253AB
		public static void Hide()
		{
			NotificationItemDAL.Delete(DiscoveryAutoImportNotificationItemDAL.DiscoveryAutoImportNotificationItemId);
		}

		// Token: 0x04000210 RID: 528
		public static readonly Guid DiscoveryAutoImportNotificationItemId = new Guid("{D52F46CF-99CA-4E93-9EA4-1FB9D8F27E46}");

		// Token: 0x04000211 RID: 529
		public static readonly Guid DiscoveryAutoImportNotificationTypeGuid = new Guid("{DD441A02-4789-4716-9A48-F0F7E3FC3EB4}");

		// Token: 0x04000212 RID: 530
		public static readonly string NetworkSonarDiscoveryURL = "/Orion/Discovery/Default.aspx";
	}
}
