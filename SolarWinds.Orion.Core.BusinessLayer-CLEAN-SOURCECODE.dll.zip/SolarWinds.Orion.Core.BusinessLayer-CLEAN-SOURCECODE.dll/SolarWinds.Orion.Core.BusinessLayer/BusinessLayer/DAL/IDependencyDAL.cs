﻿using System;
using System.Collections.Generic;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000A1 RID: 161
	public interface IDependencyDAL
	{
		// Token: 0x060007AF RID: 1967
		IList<Dependency> GetAllDependencies();

		// Token: 0x060007B0 RID: 1968
		Dependency GetDependency(int id);

		// Token: 0x060007B1 RID: 1969
		void SaveDependency(Dependency depenedency);

		// Token: 0x060007B2 RID: 1970
		void DeleteDependency(Dependency dependency);
	}
}
