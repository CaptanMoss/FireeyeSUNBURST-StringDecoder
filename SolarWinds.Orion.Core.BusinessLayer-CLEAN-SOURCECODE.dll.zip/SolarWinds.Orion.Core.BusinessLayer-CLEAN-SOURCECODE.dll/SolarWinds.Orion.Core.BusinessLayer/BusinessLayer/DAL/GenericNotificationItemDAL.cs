﻿using System;
using System.Collections.Generic;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000A4 RID: 164
	public class GenericNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x060007CA RID: 1994 RVA: 0x00038398 File Offset: 0x00036598
		protected override Guid GetNotificationItemTypeId()
		{
			return GenericNotificationItem.GenericNotificationTypeGuid;
		}

		// Token: 0x060007CB RID: 1995 RVA: 0x0003839F File Offset: 0x0003659F
		public static GenericNotificationItemDAL GetItemById(Guid itemId)
		{
			return NotificationItemDAL.GetItemById<GenericNotificationItemDAL>(itemId);
		}

		// Token: 0x060007CC RID: 1996 RVA: 0x000383A7 File Offset: 0x000365A7
		public static GenericNotificationItemDAL GetLatestItem()
		{
			return NotificationItemDAL.GetLatestItem<GenericNotificationItemDAL>(new NotificationItemFilter(false, false));
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x000383B5 File Offset: 0x000365B5
		public static ICollection<GenericNotificationItemDAL> GetItems(NotificationItemFilter filter)
		{
			return NotificationItemDAL.GetItems<GenericNotificationItemDAL>(filter);
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x000383BD File Offset: 0x000365BD
		public static int GetNotificationItemsCount()
		{
			return NotificationItemDAL.GetNotificationsCount<GenericNotificationItemDAL>(new NotificationItemFilter(false, false));
		}

		// Token: 0x060007CF RID: 1999 RVA: 0x000383CB File Offset: 0x000365CB
		public static GenericNotificationItemDAL Insert(Guid notificationId, string title, string description, bool ignored, string url, DateTime? acknowledgedAt, string acknowledgedBy)
		{
			return NotificationItemDAL.Insert<GenericNotificationItemDAL>(notificationId, title, description, ignored, url, acknowledgedAt, acknowledgedBy);
		}
	}
}
