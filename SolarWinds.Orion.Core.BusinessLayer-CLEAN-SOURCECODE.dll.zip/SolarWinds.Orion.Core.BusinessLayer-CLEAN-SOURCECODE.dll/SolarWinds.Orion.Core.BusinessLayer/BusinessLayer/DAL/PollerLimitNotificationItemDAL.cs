﻿using System;
using System.Collections.Generic;
using System.Linq;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000095 RID: 149
	public sealed class PollerLimitNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x06000704 RID: 1796 RVA: 0x0002CD54 File Offset: 0x0002AF54
		public static PollerLimitNotificationItemDAL GetItem()
		{
			return NotificationItemDAL.GetItemById<PollerLimitNotificationItemDAL>(PollerLimitNotificationItemDAL.PollerStatusNotificationItemId);
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x0002CD60 File Offset: 0x0002AF60
		public static void Show(Dictionary<string, int> warningEngines, Dictionary<string, int> reachedEngines)
		{
			if (warningEngines == null)
			{
				throw new ArgumentNullException("warningEngines");
			}
			if (reachedEngines == null)
			{
				throw new ArgumentNullException("reachedEngines");
			}
			bool isWarning = reachedEngines.Count == 0;
			Guid typeId = (reachedEngines.Count > 0) ? PollerLimitNotificationItemDAL.PollerLimitReachedNotificationTypeGuid : PollerLimitNotificationItemDAL.PollerLimitWarningNotificationTypeGuid;
			PollerLimitNotificationItemDAL.EnginesStatus enginesStatus = new PollerLimitNotificationItemDAL.EnginesStatus(warningEngines, reachedEngines);
			string description = enginesStatus.Serialize();
			PollerLimitNotificationItemDAL item = PollerLimitNotificationItemDAL.GetItem();
			string url = "javascript:SW.Core.SalesTrigger.ShowPollerLimitPopupAsync();";
			if (item == null)
			{
				NotificationItemDAL.Insert(PollerLimitNotificationItemDAL.PollerStatusNotificationItemId, typeId, PollerLimitNotificationItemDAL.GetNotificationMessage(isWarning), description, false, url, null, null);
				return;
			}
			PollerLimitNotificationItemDAL.EnginesStatus value = new PollerLimitNotificationItemDAL.EnginesStatus(item.Description);
			if (enginesStatus.Extends(value))
			{
				item.SetNotAcknowledged();
			}
			item.TypeId = typeId;
			item.Description = description;
			item.Url = url;
			item.Title = PollerLimitNotificationItemDAL.GetNotificationMessage(isWarning);
			item.Update();
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x0002CE39 File Offset: 0x0002B039
		public static void Hide()
		{
			NotificationItemDAL.Delete(PollerLimitNotificationItemDAL.PollerStatusNotificationItemId);
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x0002CE46 File Offset: 0x0002B046
		private static string GetNotificationMessage(bool isWarning)
		{
			if (!isWarning)
			{
				return PollerLimitNotificationItemDAL.LimitReachedTitle;
			}
			return PollerLimitNotificationItemDAL.WarningTitle;
		}

		// Token: 0x04000231 RID: 561
		public static readonly Guid PollerStatusNotificationItemId = new Guid("{C7070869-B2B8-42ED-8472-7F24056435D9}");

		// Token: 0x04000232 RID: 562
		public static readonly Guid PollerLimitWarningNotificationTypeGuid = new Guid("{68DF81BD-4025-4D7B-9296-C62C397AAC88}");

		// Token: 0x04000233 RID: 563
		public static readonly Guid PollerLimitReachedNotificationTypeGuid = new Guid("{25130585-7C09-4052-AF01-C706CC032940}");

		// Token: 0x04000234 RID: 564
		public static readonly string WarningTitle = Resources.COREBUSINESSLAYERDAL_CODE_YK0_1;

		// Token: 0x04000235 RID: 565
		public static readonly string LimitReachedTitle = Resources.COREBUSINESSLAYERDAL_CODE_YK0_2;

		// Token: 0x0200018B RID: 395
		private sealed class EnginesStatus
		{
			// Token: 0x17000162 RID: 354
			// (get) Token: 0x06000C4D RID: 3149 RVA: 0x0004B379 File Offset: 0x00049579
			private Dictionary<string, int> WarningEngines
			{
				get
				{
					return this.warningEngines;
				}
			}

			// Token: 0x17000163 RID: 355
			// (get) Token: 0x06000C4E RID: 3150 RVA: 0x0004B381 File Offset: 0x00049581
			private Dictionary<string, int> LimitReachedEngines
			{
				get
				{
					return this.limitReachedEngines;
				}
			}

			// Token: 0x06000C4F RID: 3151 RVA: 0x0004B389 File Offset: 0x00049589
			public EnginesStatus(Dictionary<string, int> warn, Dictionary<string, int> reached)
			{
				this.warningEngines = warn;
				this.limitReachedEngines = reached;
			}

			// Token: 0x06000C50 RID: 3152 RVA: 0x0004B3A0 File Offset: 0x000495A0
			public EnginesStatus(string enginesStatusString)
			{
				new Dictionary<string, Dictionary<string, int>>();
				if (!string.IsNullOrEmpty(enginesStatusString))
				{
					List<string> list = enginesStatusString.Split(new string[]
					{
						"||"
					}, StringSplitOptions.None).ToList<string>();
					if (list.Count < 2)
					{
						throw new ArgumentException("enginesStatusString");
					}
					this.warningEngines = new Dictionary<string, int>();
					list[0].Split(new char[]
					{
						'|'
					}, StringSplitOptions.RemoveEmptyEntries).ToList<string>().ForEach(delegate(string g)
					{
						string[] array = g.Split(new char[]
						{
							';'
						});
						this.warningEngines[array[0]] = Convert.ToInt32(array[1]);
					});
					this.limitReachedEngines = new Dictionary<string, int>();
					list[1].Split(new char[]
					{
						'|'
					}, StringSplitOptions.RemoveEmptyEntries).ToList<string>().ForEach(delegate(string g)
					{
						string[] array = g.Split(new char[]
						{
							';'
						});
						this.limitReachedEngines[array[0]] = Convert.ToInt32(array[1]);
					});
				}
			}

			// Token: 0x06000C51 RID: 3153 RVA: 0x0004B468 File Offset: 0x00049668
			public string Serialize()
			{
				string text = string.Join("|", (from e in this.warningEngines
				select e.Key + ";" + e.Value).ToArray<string>());
				string separator = "||";
				string[] array = new string[2];
				array[0] = text;
				array[1] = string.Join("|", (from e in this.limitReachedEngines
				select e.Key + ";" + e.Value).ToArray<string>());
				return string.Join(separator, array);
			}

			// Token: 0x06000C52 RID: 3154 RVA: 0x0004B504 File Offset: 0x00049704
			public bool Extends(PollerLimitNotificationItemDAL.EnginesStatus value)
			{
				return value == null || this.WarningEngines.Any((KeyValuePair<string, int> engine) => !value.WarningEngines.ContainsKey(engine.Key)) || this.LimitReachedEngines.Any((KeyValuePair<string, int> engine) => !value.LimitReachedEngines.ContainsKey(engine.Key));
			}

			// Token: 0x040004F3 RID: 1267
			private Dictionary<string, int> warningEngines;

			// Token: 0x040004F4 RID: 1268
			private Dictionary<string, int> limitReachedEngines;
		}
	}
}
