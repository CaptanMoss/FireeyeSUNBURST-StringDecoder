﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x0200009D RID: 157
	public class DependencyDAL
	{
		// Token: 0x06000796 RID: 1942 RVA: 0x00034B54 File Offset: 0x00032D54
		public static IList<Dependency> GetAllDependencies()
		{
			IList<Dependency> list = new List<Dependency>();
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT * FROM [dbo].[Dependencies]"))
			{
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
				{
					while (dataReader.Read())
					{
						list.Add(DependencyDAL.CreateDependency(dataReader));
					}
				}
			}
			return list;
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x00034BC4 File Offset: 0x00032DC4
		public static Dependency GetDependency(int id)
		{
			Dependency result = null;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT * FROM [dbo].[Dependencies] WHERE DependencyId = @id"))
			{
				textCommand.Parameters.AddWithValue("@id", id);
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
				{
					if (dataReader.Read())
					{
						result = DependencyDAL.CreateDependency(dataReader);
					}
				}
			}
			return result;
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x00034C40 File Offset: 0x00032E40
		public static void SaveDependency(Dependency dependency)
		{
			if (dependency != null)
			{
				SqlParameter[] array = new SqlParameter[]
				{
					new SqlParameter("@DependencyId", dependency.Id),
					new SqlParameter("@Name", dependency.Name),
					new SqlParameter("@ParentUri", dependency.ParentUri),
					new SqlParameter("@ChildUri", dependency.ChildUri),
					new SqlParameter("@AutoManaged", dependency.AutoManaged),
					new SqlParameter("@EngineID", dependency.EngineID),
					new SqlParameter("@Category", dependency.Category)
				};
				using (IDataReader dataReader = SqlHelper.ExecuteStoredProcReader("swsp_DependencyUpsert", array))
				{
					if (dataReader != null && !dataReader.IsClosed && dataReader.Read())
					{
						dependency.Id = dataReader.GetInt32(0);
						dependency.LastUpdateUTC = dataReader.GetDateTime(1);
					}
				}
			}
		}

		// Token: 0x06000799 RID: 1945 RVA: 0x00034D48 File Offset: 0x00032F48
		public static void DeleteDependency(Dependency dependency)
		{
			if (dependency != null)
			{
				using (SqlCommand textCommand = SqlHelper.GetTextCommand("\r\nSET NOCOUNT OFF;\r\nDelete FROM [dbo].[Dependencies]\r\n WHERE DependencyId = @id"))
				{
					textCommand.Parameters.AddWithValue("@id", dependency.Id);
					SqlHelper.ExecuteNonQuery(textCommand);
				}
			}
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x00034DA4 File Offset: 0x00032FA4
		public static int DeleteDependencies(List<int> listIds)
		{
			if (listIds.Count == 0)
			{
				return 0;
			}
			string arg = string.Empty;
			string arg2 = string.Empty;
			foreach (int num in listIds)
			{
				arg = string.Format("{0}{1}'{2}'", arg, arg2, num);
				arg2 = ", ";
			}
			int result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand(string.Format("\r\nSET NOCOUNT OFF;\r\nDelete FROM [dbo].[Dependencies]\r\n WHERE DependencyId in ({0})", arg)))
			{
				result = SqlHelper.ExecuteNonQuery(textCommand);
			}
			return result;
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x00034E54 File Offset: 0x00033054
		private static Dependency CreateDependency(IDataReader reader)
		{
			Dependency result = null;
			if (reader != null)
			{
				result = new Dependency
				{
					Id = reader.GetInt32(reader.GetOrdinal("DependencyId")),
					Name = reader.GetString(reader.GetOrdinal("Name")),
					ParentUri = reader.GetString(reader.GetOrdinal("ParentUri")),
					ChildUri = reader.GetString(reader.GetOrdinal("ChildUri")),
					LastUpdateUTC = reader.GetDateTime(reader.GetOrdinal("LastUpdateUTC")),
					AutoManaged = reader.GetBoolean(reader.GetOrdinal("AutoManaged")),
					EngineID = reader.GetInt32(reader.GetOrdinal("EngineID")),
					Category = reader.GetInt32(reader.GetOrdinal("Category"))
				};
			}
			return result;
		}
	}
}
