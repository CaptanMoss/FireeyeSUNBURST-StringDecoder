﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000B6 RID: 182
	public sealed class MaintenanceRenewalItemDAL : NotificationItemDAL
	{
		// Token: 0x1700011D RID: 285
		// (get) Token: 0x060008CA RID: 2250 RVA: 0x0003FF1D File Offset: 0x0003E11D
		// (set) Token: 0x060008CB RID: 2251 RVA: 0x0003FF25 File Offset: 0x0003E125
		public string ProductTag { get; set; }

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x060008CC RID: 2252 RVA: 0x0003FF2E File Offset: 0x0003E12E
		// (set) Token: 0x060008CD RID: 2253 RVA: 0x0003FF36 File Offset: 0x0003E136
		public DateTime DateReleased { get; set; }

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x060008CE RID: 2254 RVA: 0x0003FF3F File Offset: 0x0003E13F
		// (set) Token: 0x060008CF RID: 2255 RVA: 0x0003FF47 File Offset: 0x0003E147
		public string NewVersion { get; set; }

		// Token: 0x060008D0 RID: 2256 RVA: 0x0003FF50 File Offset: 0x0003E150
		public MaintenanceRenewalItemDAL()
		{
			this.ProductTag = string.Empty;
			this.DateReleased = DateTime.MinValue;
			this.NewVersion = string.Empty;
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x0003FF79 File Offset: 0x0003E179
		protected override Guid GetNotificationItemTypeId()
		{
			return MaintenanceRenewalItem.MaintenanceRenewalsTypeGuid;
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x0003FF80 File Offset: 0x0003E180
		protected override SqlCommand ComposeSelectCollectionCommand(NotificationItemFilter filter)
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT * FROM NotificationMaintenanceRenewals LEFT JOIN NotificationItems ON \r\n                                         NotificationMaintenanceRenewals.RenewalID = NotificationItems.NotificationID");
			SqlCommand result;
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				if (!filter.IncludeAcknowledged)
				{
					SqlHelper.AddCondition(stringBuilder, "AcknowledgedAt IS NULL", "AND");
				}
				if (!filter.IncludeIgnored)
				{
					SqlHelper.AddCondition(stringBuilder, "Ignored=0", "AND");
				}
				MaintenanceRenewalFilter maintenanceRenewalFilter = filter as MaintenanceRenewalFilter;
				if (maintenanceRenewalFilter != null && !string.IsNullOrEmpty(maintenanceRenewalFilter.ProductTag))
				{
					SqlHelper.AddCondition(stringBuilder, "ProductTag=@ProductTag", "AND");
					sqlCommand.Parameters.AddWithValue("@ProductTag", maintenanceRenewalFilter.ProductTag);
				}
				SqlCommand sqlCommand2 = sqlCommand;
				sqlCommand2.CommandText += stringBuilder.ToString();
				SqlCommand sqlCommand3 = sqlCommand;
				sqlCommand3.CommandText += " ORDER BY DateReleased DESC";
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				NotificationItemDAL.log.Error(string.Format("Error while composing SELECT SQL command for {0} collection: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x00040084 File Offset: 0x0003E284
		protected override SqlCommand ComposeSelectItemCommand()
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT * FROM NotificationMaintenanceRenewals LEFT JOIN NotificationItems ON \r\n                                         NotificationMaintenanceRenewals.RenewalID = NotificationItems.NotificationID \r\n                                       WHERE RenewalID=@RenewalID");
			SqlCommand result;
			try
			{
				sqlCommand.Parameters.AddWithValue("@RenewalID", base.Id);
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				NotificationItemDAL.log.Error(string.Format("Error while composing SELECT SQL command for {0}: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00040100 File Offset: 0x0003E300
		protected override SqlCommand ComposeSelectLatestItemCommand(NotificationItemFilter filter)
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT TOP 1 * FROM NotificationMaintenanceRenewals LEFT JOIN NotificationItems ON \r\n                                         NotificationMaintenanceRenewals.RenewalID = NotificationItems.NotificationID");
			SqlCommand result;
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				if (!filter.IncludeAcknowledged)
				{
					SqlHelper.AddCondition(stringBuilder, "AcknowledgedAt IS NULL", "AND");
				}
				if (!filter.IncludeIgnored)
				{
					SqlHelper.AddCondition(stringBuilder, "Ignored=0", "AND");
				}
				MaintenanceRenewalFilter maintenanceRenewalFilter = filter as MaintenanceRenewalFilter;
				if (maintenanceRenewalFilter != null && !string.IsNullOrEmpty(maintenanceRenewalFilter.ProductTag))
				{
					SqlHelper.AddCondition(stringBuilder, "ProductTag=@ProductTag", "AND");
					sqlCommand.Parameters.AddWithValue("@ProductTag", maintenanceRenewalFilter.ProductTag);
				}
				SqlCommand sqlCommand2 = sqlCommand;
				sqlCommand2.CommandText += stringBuilder.ToString();
				SqlCommand sqlCommand3 = sqlCommand;
				sqlCommand3.CommandText += " ORDER BY DateReleased DESC";
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				NotificationItemDAL.log.Error(string.Format("Error while composing SELECT SQL command for latest {0}: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x00040204 File Offset: 0x0003E404
		protected override SqlCommand ComposeSelectCountCommand(NotificationItemFilter filter)
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT COUNT(RenewalID) FROM NotificationMaintenanceRenewals LEFT JOIN NotificationItems ON \r\n                                         NotificationMaintenanceRenewals.RenewalID = NotificationItems.NotificationID");
			SqlCommand result;
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				if (!filter.IncludeAcknowledged)
				{
					SqlHelper.AddCondition(stringBuilder, "AcknowledgedAt IS NULL", "AND");
				}
				if (!filter.IncludeIgnored)
				{
					SqlHelper.AddCondition(stringBuilder, "Ignored=0", "AND");
				}
				MaintenanceRenewalFilter maintenanceRenewalFilter = filter as MaintenanceRenewalFilter;
				if (maintenanceRenewalFilter != null && !string.IsNullOrEmpty(maintenanceRenewalFilter.ProductTag))
				{
					SqlHelper.AddCondition(stringBuilder, "ProductTag=@ProductTag", "AND");
					sqlCommand.Parameters.AddWithValue("@ProductTag", maintenanceRenewalFilter.ProductTag);
				}
				SqlCommand sqlCommand2 = sqlCommand;
				sqlCommand2.CommandText += stringBuilder.ToString();
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				NotificationItemDAL.log.Error(string.Format("Error while composing SELECT COUNT SQL command for {0}: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x000402F4 File Offset: 0x0003E4F4
		public static MaintenanceRenewalItemDAL GetItemById(Guid itemId)
		{
			return NotificationItemDAL.GetItemById<MaintenanceRenewalItemDAL>(itemId);
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x000402FC File Offset: 0x0003E4FC
		public static MaintenanceRenewalItemDAL GetLatestItem(NotificationItemFilter filter)
		{
			return NotificationItemDAL.GetLatestItem<MaintenanceRenewalItemDAL>(filter);
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x00040304 File Offset: 0x0003E504
		public static ICollection<MaintenanceRenewalItemDAL> GetItems(MaintenanceRenewalFilter filter)
		{
			return NotificationItemDAL.GetItems<MaintenanceRenewalItemDAL>(filter);
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x0004030C File Offset: 0x0003E50C
		public static int GetNotificationsCount()
		{
			return NotificationItemDAL.GetNotificationsCount<MaintenanceRenewalItemDAL>(new NotificationItemFilter());
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x00040318 File Offset: 0x0003E518
		public static MaintenanceRenewalItemDAL GetItemForProduct(string productTag)
		{
			if (string.IsNullOrEmpty(productTag))
			{
				throw new ArgumentNullException("productTag");
			}
			MaintenanceRenewalItemDAL result;
			using (SqlCommand sqlCommand = new SqlCommand("SELECT * FROM NotificationMaintenanceRenewals LEFT JOIN NotificationItems ON \r\n                                                NotificationMaintenanceRenewals.RenewalID = NotificationItems.NotificationID\r\n                                              WHERE ProductTag=@ProductTag"))
			{
				sqlCommand.Parameters.AddWithValue("@ProductTag", productTag);
				using (IDataReader dataReader = SqlHelper.ExecuteReader(sqlCommand))
				{
					if (dataReader.Read())
					{
						MaintenanceRenewalItemDAL maintenanceRenewalItemDAL = new MaintenanceRenewalItemDAL();
						maintenanceRenewalItemDAL.LoadFromReader(dataReader);
						result = maintenanceRenewalItemDAL;
					}
					else
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x000403A8 File Offset: 0x0003E5A8
		private static MaintenanceRenewalItemDAL Insert(SqlConnection con, SqlTransaction tr, Guid renewalId, string title, string description, bool ignored, string url, DateTime? acknowledgedAt, string acknowledgedBy, string productTag, DateTime dateReleased, string newVersion)
		{
			if (tr == null)
			{
				throw new ArgumentNullException("tr");
			}
			if (string.IsNullOrEmpty(productTag))
			{
				throw new ArgumentNullException("productTag");
			}
			if (dateReleased == DateTime.MinValue)
			{
				throw new ArgumentNullException("dateReleased");
			}
			if (string.IsNullOrEmpty(newVersion))
			{
				throw new ArgumentNullException("newVersion");
			}
			MaintenanceRenewalItemDAL maintenanceRenewalItemDAL = NotificationItemDAL.Insert<MaintenanceRenewalItemDAL>(con, tr, renewalId, title, description, ignored, url, acknowledgedAt, acknowledgedBy);
			if (maintenanceRenewalItemDAL == null)
			{
				return null;
			}
			using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO NotificationMaintenanceRenewals (RenewalID, ProductTag, DateReleased, Version) VALUES (@RenewalID, @ProductTag, @DateReleased, @NewVersion)"))
			{
				sqlCommand.Parameters.AddWithValue("@RenewalID", renewalId);
				sqlCommand.Parameters.AddWithValue("@ProductTag", productTag);
				sqlCommand.Parameters.AddWithValue("@DateReleased", dateReleased);
				sqlCommand.Parameters.AddWithValue("@NewVersion", newVersion);
				if (SqlHelper.ExecuteNonQuery(sqlCommand, con, tr) == 0)
				{
					maintenanceRenewalItemDAL = null;
				}
				else
				{
					maintenanceRenewalItemDAL.ProductTag = productTag;
					maintenanceRenewalItemDAL.DateReleased = dateReleased;
					maintenanceRenewalItemDAL.NewVersion = newVersion;
				}
			}
			return maintenanceRenewalItemDAL;
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x000404C0 File Offset: 0x0003E6C0
		public static MaintenanceRenewalItemDAL Insert(Guid renewalId, string title, string description, bool ignored, string url, DateTime? acknowledgedAt, string acknowledgedBy, string productTag, DateTime dateReleased, string newVersion)
		{
			MaintenanceRenewalItemDAL result;
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction())
				{
					try
					{
						MaintenanceRenewalItemDAL maintenanceRenewalItemDAL = MaintenanceRenewalItemDAL.Insert(sqlConnection, sqlTransaction, renewalId, title, description, ignored, url, acknowledgedAt, acknowledgedBy, productTag, dateReleased, newVersion);
						sqlTransaction.Commit();
						result = maintenanceRenewalItemDAL;
					}
					catch (Exception ex)
					{
						sqlTransaction.Rollback();
						NotificationItemDAL.log.Error(string.Format("Can't INSERT maintenance renewal item: ", Array.Empty<object>()) + ex.ToString());
						throw;
					}
				}
			}
			return result;
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x00040564 File Offset: 0x0003E764
		protected override bool Update(SqlConnection con, SqlTransaction tr)
		{
			if (!base.Update(con, tr))
			{
				return false;
			}
			bool result;
			using (SqlCommand sqlCommand = new SqlCommand("UPDATE NotificationMaintenanceRenewals SET ProductTag=@ProductTag, DateReleased=@DateReleased, Version=@NewVersion WHERE RenewalID=@RenewalID"))
			{
				sqlCommand.Parameters.AddWithValue("@RenewalID", base.Id);
				sqlCommand.Parameters.AddWithValue("@ProductTag", this.ProductTag);
				sqlCommand.Parameters.AddWithValue("@DateReleased", this.DateReleased);
				sqlCommand.Parameters.AddWithValue("@NewVersion", this.NewVersion);
				result = (SqlHelper.ExecuteNonQuery(sqlCommand, con, tr) > 0);
			}
			return result;
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x00040618 File Offset: 0x0003E818
		protected override bool Delete(SqlConnection con, SqlTransaction tr)
		{
			if (!base.Delete(con, tr))
			{
				return false;
			}
			bool result;
			using (SqlCommand sqlCommand = new SqlCommand("DELETE FROM NotificationMaintenanceRenewals WHERE RenewalID=@RenewalID"))
			{
				sqlCommand.Parameters.AddWithValue("@RenewalID", base.Id);
				result = (SqlHelper.ExecuteNonQuery(sqlCommand, con, tr) > 0);
			}
			return result;
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x00040684 File Offset: 0x0003E884
		protected override void LoadFromReader(IDataReader rd)
		{
			base.LoadFromReader(rd);
			this.ProductTag = DatabaseFunctions.GetString(rd, "ProductTag");
			this.DateReleased = DatabaseFunctions.GetDateTime(rd, "DateReleased");
			this.NewVersion = DatabaseFunctions.GetString(rd, "Version");
		}
	}
}
