﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000B5 RID: 181
	public class MaintenanceRenewalFilter : NotificationItemFilter
	{
		// Token: 0x1700011C RID: 284
		// (get) Token: 0x060008C6 RID: 2246 RVA: 0x0003FEF0 File Offset: 0x0003E0F0
		// (set) Token: 0x060008C7 RID: 2247 RVA: 0x0003FEF8 File Offset: 0x0003E0F8
		public string ProductTag { get; set; }

		// Token: 0x060008C8 RID: 2248 RVA: 0x0003FF01 File Offset: 0x0003E101
		public MaintenanceRenewalFilter(bool includeAcknowledged, bool includeIgnored, string productTag) : base(includeAcknowledged, includeIgnored)
		{
			this.ProductTag = productTag;
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x0003FF12 File Offset: 0x0003E112
		public MaintenanceRenewalFilter() : this(false, false, null)
		{
		}
	}
}
