﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x020000A0 RID: 160
	public class GenericPopupNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x060007AC RID: 1964 RVA: 0x000271B8 File Offset: 0x000253B8
		protected GenericPopupNotificationItemDAL()
		{
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x0003575B File Offset: 0x0003395B
		protected virtual Guid GetPopupNotificationItemId()
		{
			return Guid.Empty;
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x00035764 File Offset: 0x00033964
		protected static TNotificationItem Create<TNotificationItem>(string title, string url) where TNotificationItem : GenericPopupNotificationItemDAL, new()
		{
			Guid popupNotificationItemId = Activator.CreateInstance<TNotificationItem>().GetPopupNotificationItemId();
			if (popupNotificationItemId == Guid.Empty)
			{
				throw new ArgumentException("Can't obtain Popup Notification Item GUID", "TNotificationItem");
			}
			TNotificationItem itemById = NotificationItemDAL.GetItemById<TNotificationItem>(popupNotificationItemId);
			if (itemById == null)
			{
				return NotificationItemDAL.Insert<TNotificationItem>(popupNotificationItemId, title, null, false, url, null, null);
			}
			itemById.Title = title;
			itemById.Description = null;
			itemById.Url = url;
			itemById.CreatedAt = DateTime.UtcNow;
			itemById.SetNotAcknowledged();
			itemById.Ignored = false;
			if (!itemById.Update())
			{
				return default(TNotificationItem);
			}
			return itemById;
		}
	}
}
