﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Models;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x0200009C RID: 156
	public sealed class BlogItemDAL : NotificationItemDAL
	{
		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x06000777 RID: 1911 RVA: 0x00033F0D File Offset: 0x0003210D
		// (set) Token: 0x06000778 RID: 1912 RVA: 0x00033F15 File Offset: 0x00032115
		public Guid PostGuid { get; set; }

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000779 RID: 1913 RVA: 0x00033F1E File Offset: 0x0003211E
		// (set) Token: 0x0600077A RID: 1914 RVA: 0x00033F26 File Offset: 0x00032126
		public long PostId { get; set; }

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x0600077B RID: 1915 RVA: 0x00033F2F File Offset: 0x0003212F
		// (set) Token: 0x0600077C RID: 1916 RVA: 0x00033F37 File Offset: 0x00032137
		public string Owner { get; set; }

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x0600077D RID: 1917 RVA: 0x00033F40 File Offset: 0x00032140
		// (set) Token: 0x0600077E RID: 1918 RVA: 0x00033F48 File Offset: 0x00032148
		public DateTime PublicationDate { get; set; }

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x0600077F RID: 1919 RVA: 0x00033F51 File Offset: 0x00032151
		// (set) Token: 0x06000780 RID: 1920 RVA: 0x00033F59 File Offset: 0x00032159
		public string CommentsUrl { get; set; }

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06000781 RID: 1921 RVA: 0x00033F62 File Offset: 0x00032162
		// (set) Token: 0x06000782 RID: 1922 RVA: 0x00033F6A File Offset: 0x0003216A
		public int CommentsCount { get; set; }

		// Token: 0x06000783 RID: 1923 RVA: 0x00033F74 File Offset: 0x00032174
		public BlogItemDAL()
		{
			this.PostGuid = Guid.Empty;
			this.PostId = 0L;
			this.Owner = string.Empty;
			this.PublicationDate = DateTime.MinValue;
			this.CommentsUrl = string.Empty;
			this.CommentsCount = 0;
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x00033FC2 File Offset: 0x000321C2
		protected override Guid GetNotificationItemTypeId()
		{
			return BlogItem.BlogTypeGuid;
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x00033FCC File Offset: 0x000321CC
		protected override SqlCommand ComposeSelectCollectionCommand(NotificationItemFilter filter)
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT{0} * FROM NotificationBlogs LEFT JOIN NotificationItems ON \r\n                                         NotificationBlogs.BlogID = NotificationItems.NotificationID");
			SqlCommand result;
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				if (!filter.IncludeAcknowledged)
				{
					SqlHelper.AddCondition(stringBuilder, "AcknowledgedAt IS NULL", "AND");
				}
				if (!filter.IncludeIgnored)
				{
					SqlHelper.AddCondition(stringBuilder, "Ignored=0", "AND");
				}
				BlogFilter blogFilter = filter as BlogFilter;
				if (blogFilter != null && blogFilter.MaxResults > 0)
				{
					sqlCommand.CommandText = string.Format(sqlCommand.CommandText, " TOP " + blogFilter.MaxResults);
				}
				else
				{
					sqlCommand.CommandText = string.Format(sqlCommand.CommandText, string.Empty);
				}
				SqlCommand sqlCommand2 = sqlCommand;
				sqlCommand2.CommandText += stringBuilder.ToString();
				SqlCommand sqlCommand3 = sqlCommand;
				sqlCommand3.CommandText += " ORDER BY PublicationDate DESC";
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				BlogItemDAL.log.Error(string.Format("Error while composing SELECT SQL command for {0} collection: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x000340E4 File Offset: 0x000322E4
		protected override SqlCommand ComposeSelectItemCommand()
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT * FROM NotificationBlogs LEFT JOIN NotificationItems ON \r\n                                         NotificationBlogs.BlogID = NotificationItems.NotificationID \r\n                                       WHERE BlogID=@BlogID");
			SqlCommand result;
			try
			{
				sqlCommand.Parameters.AddWithValue("@BlogID", base.Id);
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				BlogItemDAL.log.Error(string.Format("Error while composing SELECT SQL command for {0}: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x00034160 File Offset: 0x00032360
		protected override SqlCommand ComposeSelectLatestItemCommand(NotificationItemFilter filter)
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT TOP 1 * FROM NotificationBlogs LEFT JOIN NotificationItems ON \r\n                                         NotificationBlogs.BlogID = NotificationItems.NotificationID");
			SqlCommand result;
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				if (!filter.IncludeAcknowledged)
				{
					SqlHelper.AddCondition(stringBuilder, "AcknowledgedAt IS NULL", "AND");
				}
				if (!filter.IncludeIgnored)
				{
					SqlHelper.AddCondition(stringBuilder, "Ignored=0", "AND");
				}
				SqlCommand sqlCommand2 = sqlCommand;
				sqlCommand2.CommandText += stringBuilder.ToString();
				SqlCommand sqlCommand3 = sqlCommand;
				sqlCommand3.CommandText += " ORDER BY PublicationDate DESC";
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				BlogItemDAL.log.Error(string.Format("Error while composing SELECT SQL command for latest {0}: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00034224 File Offset: 0x00032424
		protected override SqlCommand ComposeSelectCountCommand(NotificationItemFilter filter)
		{
			SqlCommand sqlCommand = new SqlCommand("SELECT COUNT(BlogID) FROM NotificationBlogs LEFT JOIN NotificationItems ON \r\n                                         NotificationBlogs.BlogID = NotificationItems.NotificationID");
			SqlCommand result;
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				if (!filter.IncludeAcknowledged)
				{
					SqlHelper.AddCondition(stringBuilder, "AcknowledgedAt IS NULL", "AND");
				}
				if (!filter.IncludeIgnored)
				{
					SqlHelper.AddCondition(stringBuilder, "Ignored=0", "AND");
				}
				SqlCommand sqlCommand2 = sqlCommand;
				sqlCommand2.CommandText += stringBuilder.ToString();
				result = sqlCommand;
			}
			catch (Exception ex)
			{
				sqlCommand.Dispose();
				BlogItemDAL.log.Error(string.Format("Error while composing SELECT COUNT SQL command for {0}: ", base.GetType().Name) + ex.ToString());
				throw;
			}
			return result;
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x000342D4 File Offset: 0x000324D4
		public static BlogItemDAL GetItemById(Guid itemId)
		{
			return NotificationItemDAL.GetItemById<BlogItemDAL>(itemId);
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x000342DC File Offset: 0x000324DC
		public static BlogItemDAL GetLatestItem()
		{
			return NotificationItemDAL.GetLatestItem<BlogItemDAL>(new NotificationItemFilter(false, false));
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x000342EA File Offset: 0x000324EA
		public static ICollection<BlogItemDAL> GetItems(BlogFilter filter)
		{
			return NotificationItemDAL.GetItems<BlogItemDAL>(filter);
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x000342F2 File Offset: 0x000324F2
		public static int GetNotificationsCount()
		{
			return NotificationItemDAL.GetNotificationsCount<BlogItemDAL>(new NotificationItemFilter());
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x000342FE File Offset: 0x000324FE
		public static BlogItemDAL GetBlogItemForPost(Guid postGuid, long postId)
		{
			return BlogItemDAL.GetBlogItemForPost(postGuid, postId, null);
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x00034308 File Offset: 0x00032508
		private static BlogItemDAL GetBlogItemForPost(Guid postGuid, long postId, SqlConnection connection)
		{
			BlogItemDAL result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("SELECT * FROM NotificationBlogs LEFT JOIN NotificationItems ON NotificationBlogs.BlogID=NotificationItems.NotificationID \r\n                                 WHERE PostGUID=@PostGUID AND PostID=@PostID"))
			{
				textCommand.Parameters.AddWithValue("@PostGUID", postGuid);
				textCommand.Parameters.AddWithValue("@PostID", postId);
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand, connection))
				{
					if (dataReader.Read())
					{
						BlogItemDAL blogItemDAL = new BlogItemDAL();
						blogItemDAL.LoadFromReader(dataReader);
						result = blogItemDAL;
					}
					else
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x000343A4 File Offset: 0x000325A4
		public static void StoreBlogItems(List<BlogItemDAL> blogItems, int targetBlogsCount)
		{
			if (targetBlogsCount < 0)
			{
				throw new ArgumentOutOfRangeException("targetBlogsCount", targetBlogsCount, "Should be >= 0");
			}
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				List<BlogItemDAL> list = new List<BlogItemDAL>();
				List<BlogItemDAL> list2 = new List<BlogItemDAL>();
				foreach (BlogItemDAL blogItemDAL in blogItems)
				{
					BlogItemDAL blogItemForPost = BlogItemDAL.GetBlogItemForPost(blogItemDAL.PostGuid, blogItemDAL.PostId, sqlConnection);
					if (blogItemForPost != null)
					{
						blogItemForPost.Title = blogItemDAL.Title;
						blogItemForPost.Description = blogItemDAL.Description;
						blogItemForPost.Url = blogItemDAL.Url;
						blogItemForPost.Owner = blogItemDAL.Owner;
						blogItemForPost.PublicationDate = blogItemDAL.PublicationDate;
						blogItemForPost.CommentsUrl = blogItemDAL.CommentsUrl;
						blogItemForPost.CommentsCount = blogItemDAL.CommentsCount;
						list.Add(blogItemForPost);
					}
					else
					{
						list2.Add(blogItemDAL);
					}
				}
				using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction(IsolationLevel.Serializable))
				{
					try
					{
						foreach (BlogItemDAL blogItemDAL2 in list)
						{
							blogItemDAL2.Update(sqlConnection, sqlTransaction);
						}
						foreach (BlogItemDAL blogItemDAL3 in list2)
						{
							BlogItemDAL.Insert(sqlConnection, sqlTransaction, Guid.NewGuid(), blogItemDAL3.Title, blogItemDAL3.Description, false, blogItemDAL3.Url, null, null, blogItemDAL3.PostGuid, blogItemDAL3.PostId, blogItemDAL3.Owner, blogItemDAL3.PublicationDate, blogItemDAL3.CommentsUrl, blogItemDAL3.CommentsCount);
						}
						using (SqlCommand sqlCommand = new SqlCommand(string.Format("DELETE FROM NotificationBlogs WHERE BlogID NOT IN (SELECT TOP {0} BlogID FROM NotificationBlogs ORDER BY PublicationDate DESC)", targetBlogsCount)))
						{
							SqlHelper.ExecuteNonQuery(sqlCommand, sqlConnection, sqlTransaction);
						}
						using (SqlCommand sqlCommand2 = new SqlCommand("DELETE FROM NotificationItems WHERE NotificationTypeID=@TypeID AND NotificationID NOT IN (SELECT BlogID FROM NotificationBlogs)"))
						{
							sqlCommand2.Parameters.AddWithValue("@TypeID", BlogItem.BlogTypeGuid);
							SqlHelper.ExecuteNonQuery(sqlCommand2, sqlConnection, sqlTransaction);
						}
						sqlTransaction.Commit();
					}
					catch
					{
						sqlTransaction.Rollback();
						throw;
					}
				}
			}
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x000346C0 File Offset: 0x000328C0
		private static BlogItemDAL Insert(SqlConnection con, SqlTransaction tr, Guid blogId, string title, string description, bool ignored, string url, DateTime? acknowledgedAt, string acknowledgedBy, Guid postGuid, long postId, string owner, DateTime publicationDate, string commentsUrl, int commentsCount)
		{
			if (tr == null)
			{
				throw new ArgumentNullException("tr");
			}
			if (postGuid == Guid.Empty)
			{
				throw new ArgumentException("postGuid GUID can't be Guid.Empty", "postGuid");
			}
			if (publicationDate == DateTime.MinValue)
			{
				throw new ArgumentNullException("publicationDate");
			}
			BlogItemDAL blogItemDAL = NotificationItemDAL.Insert<BlogItemDAL>(con, tr, blogId, title, description, ignored, url, acknowledgedAt, acknowledgedBy);
			if (blogItemDAL == null)
			{
				return null;
			}
			BlogItemDAL result;
			using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO NotificationBlogs (BlogID, PostGUID, PostID, Owner, PublicationDate, CommentsUrl, CommentsCount)\r\n                                              VALUES (@BlogID, @PostGUID, @PostID, @Owner, @PublicationDate, @CommentsUrl, @CommentsCount)"))
			{
				sqlCommand.Parameters.AddWithValue("@BlogID", blogId);
				sqlCommand.Parameters.AddWithValue("@PostGUID", postGuid);
				sqlCommand.Parameters.AddWithValue("@PostID", postId);
				sqlCommand.Parameters.AddWithValue("@Owner", string.IsNullOrEmpty(owner) ? DBNull.Value : owner);
				sqlCommand.Parameters.AddWithValue("@PublicationDate", publicationDate);
				sqlCommand.Parameters.AddWithValue("@CommentsUrl", string.IsNullOrEmpty(commentsUrl) ? DBNull.Value : commentsUrl);
				sqlCommand.Parameters.AddWithValue("@CommentsCount", (commentsCount < 0) ? DBNull.Value : commentsCount);
				if (SqlHelper.ExecuteNonQuery(sqlCommand, con, tr) == 0)
				{
					result = null;
				}
				else
				{
					blogItemDAL.PostGuid = postGuid;
					blogItemDAL.PostId = postId;
					blogItemDAL.Owner = owner;
					blogItemDAL.PublicationDate = publicationDate;
					blogItemDAL.CommentsUrl = commentsUrl;
					blogItemDAL.CommentsCount = commentsCount;
					result = blogItemDAL;
				}
			}
			return result;
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x00034868 File Offset: 0x00032A68
		public static BlogItemDAL Insert(Guid blogId, string title, string description, bool ignored, string url, DateTime? acknowledgedAt, string acknowledgedBy, Guid postGuid, long postId, string owner, DateTime publicationDate, string commentsUrl, int commentsCount)
		{
			BlogItemDAL result;
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlTransaction sqlTransaction = sqlConnection.BeginTransaction())
				{
					try
					{
						BlogItemDAL blogItemDAL = BlogItemDAL.Insert(sqlConnection, sqlTransaction, blogId, title, description, ignored, url, acknowledgedAt, acknowledgedBy, postGuid, postId, owner, publicationDate, commentsUrl, commentsCount);
						sqlTransaction.Commit();
						result = blogItemDAL;
					}
					catch (Exception ex)
					{
						sqlTransaction.Rollback();
						BlogItemDAL.log.Error(string.Format("Can't INSERT blog item: ", Array.Empty<object>()) + ex.ToString());
						throw;
					}
				}
			}
			return result;
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x00034914 File Offset: 0x00032B14
		protected override bool Update(SqlConnection con, SqlTransaction tr)
		{
			if (!base.Update(con, tr))
			{
				return false;
			}
			bool result;
			using (SqlCommand sqlCommand = new SqlCommand("UPDATE NotificationBlogs SET PostGUID=@PostGUID, PostID=@PostID, Owner=@Owner, PublicationDate=@PublicationDate, \r\n                                              CommentsUrl=@CommentsUrl, CommentsCount=@CommentsCount WHERE BlogID=@BlogID"))
			{
				sqlCommand.Parameters.AddWithValue("@BlogID", base.Id);
				sqlCommand.Parameters.AddWithValue("@PostGUID", this.PostGuid);
				sqlCommand.Parameters.AddWithValue("@PostID", this.PostId);
				sqlCommand.Parameters.AddWithValue("@Owner", string.IsNullOrEmpty(this.Owner) ? DBNull.Value : this.Owner);
				sqlCommand.Parameters.AddWithValue("@PublicationDate", this.PublicationDate);
				sqlCommand.Parameters.AddWithValue("@CommentsUrl", string.IsNullOrEmpty(this.CommentsUrl) ? DBNull.Value : this.CommentsUrl);
				sqlCommand.Parameters.AddWithValue("@CommentsCount", (this.CommentsCount < 0) ? DBNull.Value : this.CommentsCount);
				result = (SqlHelper.ExecuteNonQuery(sqlCommand, con, tr) > 0);
			}
			return result;
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x00034A60 File Offset: 0x00032C60
		protected override bool Delete(SqlConnection con, SqlTransaction tr)
		{
			if (!base.Delete(con, tr))
			{
				return false;
			}
			bool result;
			using (SqlCommand sqlCommand = new SqlCommand("DELETE FROM NotificationBlogs WHERE BlogID=@BlogID"))
			{
				sqlCommand.Parameters.AddWithValue("@BlogID", base.Id);
				result = (SqlHelper.ExecuteNonQuery(sqlCommand, con, tr) > 0);
			}
			return result;
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x00034ACC File Offset: 0x00032CCC
		protected override void LoadFromReader(IDataReader rd)
		{
			base.LoadFromReader(rd);
			this.PostGuid = DatabaseFunctions.GetGuid(rd, "PostGUID");
			this.PostId = DatabaseFunctions.GetLong(rd, "PostID");
			this.Owner = DatabaseFunctions.GetString(rd, "Owner");
			this.PublicationDate = DatabaseFunctions.GetDateTime(rd, "PublicationDate");
			this.CommentsUrl = DatabaseFunctions.GetString(rd, "CommentsUrl");
			this.CommentsCount = DatabaseFunctions.GetInt32(rd, "CommentsCount");
		}

		// Token: 0x04000247 RID: 583
		private new static readonly Log log = new Log();
	}
}
