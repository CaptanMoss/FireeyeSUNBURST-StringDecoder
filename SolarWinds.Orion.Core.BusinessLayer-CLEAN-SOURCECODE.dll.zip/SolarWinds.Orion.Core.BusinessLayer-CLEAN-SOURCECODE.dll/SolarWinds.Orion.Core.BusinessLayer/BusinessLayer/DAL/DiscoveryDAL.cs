﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Discovery.DataAccess;
using SolarWinds.Orion.Core.Models.OldDiscoveryModels;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000096 RID: 150
	public static class DiscoveryDAL
	{
		// Token: 0x0600070A RID: 1802 RVA: 0x0002CEA6 File Offset: 0x0002B0A6
		[Obsolete("This method belongs to old discovery process.", true)]
		public static StartImportStatus ImportDiscoveryResults(Guid importID, List<DiscoveryResult> discoveryResults)
		{
			return 2;
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x0000AAB8 File Offset: 0x00008CB8
		[Obsolete("This method belongs to old discovery process.", true)]
		public static bool IsImportInProgress(int discoveryProfileID)
		{
			return false;
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x0002CEA9 File Offset: 0x0002B0A9
		[Obsolete("This method belongs to old discovery process.", true)]
		public static string GetCPUPollerTypeByOID(string oid)
		{
			return string.Empty;
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x0002CEB0 File Offset: 0x0002B0B0
		[Obsolete("This method belongs to old discovery process.", true)]
		public static Intervals GetEnginesPollingIntervals(int engineID)
		{
			return new Intervals();
		}

		// Token: 0x0600070E RID: 1806 RVA: 0x0002CEB8 File Offset: 0x0002B0B8
		public static Intervals GetSettingsPollingIntervals()
		{
			return new Intervals
			{
				RediscoveryInterval = int.Parse(SettingsDAL.Get("SWNetPerfMon-Settings-Default Rediscovery Interval")),
				NodePollInterval = int.Parse(SettingsDAL.Get("SWNetPerfMon-Settings-Default Node Poll Interval")),
				VolumePollInterval = int.Parse(SettingsDAL.Get("SWNetPerfMon-Settings-Default Volume Poll Interval")),
				NodeStatPollInterval = int.Parse(SettingsDAL.Get("SWNetPerfMon-Settings-Default Node Stat Poll Interval")),
				VolumeStatPollInterval = int.Parse(SettingsDAL.Get("SWNetPerfMon-Settings-Default Volume Stat Poll Interval"))
			};
		}

		// Token: 0x0600070F RID: 1807 RVA: 0x0002CF34 File Offset: 0x0002B134
		public static List<SnmpEntry> GetAllCredentials()
		{
			SqlCommand textCommand = SqlHelper.GetTextCommand("\r\n    Select Distinct 1 As SnmpVersion, CommunityString, Null as SNMPUser, Null as Context, Null as AuthPassword, Null as EncryptPassword, \r\n0 as AuthLevel, Null as AuthMethod, 0 as EncryptMethod From dbo.DiscoverySNMPCredentials\r\nUnion\r\n(\r\n\tSELECT 3 As SnmpVersion, Null as CommunityString, SNMPUser, Context, AuthPassword, EncryptPassword, AuthLevel, AuthMethod, EncryptMethod \r\n\tFROM DiscoverySNMPCredentialsV3\r\n)");
			List<SnmpEntry> list = new List<SnmpEntry>
			{
				new SnmpEntry
				{
					Name = "public",
					Version = 1,
					Selected = true
				},
				new SnmpEntry
				{
					Name = "private",
					Version = 1,
					Selected = true
				}
			};
			using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
			{
				while (dataReader.Read())
				{
					string @string = DatabaseFunctions.GetString(dataReader, "CommunityString");
					int @int = DatabaseFunctions.GetInt32(dataReader, "SnmpVersion");
					if (!@string.Equals("public", StringComparison.OrdinalIgnoreCase) && !@string.Equals("private", StringComparison.OrdinalIgnoreCase))
					{
						if (@int == 3)
						{
							DiscoverySNMPCredentialsV3Entry.AuthenticationMethods int2 = DatabaseFunctions.GetInt32(dataReader, "AuthMethod");
							DiscoverySNMPCredentialsV3Entry.EncryptionMethods int3 = DatabaseFunctions.GetInt32(dataReader, "EncryptMethod");
							SnmpEntry snmpEntry = new SnmpEntry
							{
								UserName = DatabaseFunctions.GetString(dataReader, "SNMPUser"),
								Context = DatabaseFunctions.GetString(dataReader, "Context"),
								AuthPassword = DatabaseFunctions.GetString(dataReader, "AuthPassword"),
								PrivPassword = DatabaseFunctions.GetString(dataReader, "EncryptPassword"),
								AuthLevel = DatabaseFunctions.GetInt32(dataReader, "AuthLevel"),
								AuthMethod = ((int2 == 2) ? 1 : 0),
								Version = 3,
								Selected = true
							};
							switch (int3)
							{
							case 2:
								snmpEntry.PrivMethod = 1;
								break;
							case 3:
								snmpEntry.PrivMethod = 2;
								break;
							case 4:
								snmpEntry.PrivMethod = 3;
								break;
							default:
								snmpEntry.PrivMethod = 0;
								break;
							}
							list.Add(snmpEntry);
						}
						else
						{
							list.Add(new SnmpEntry
							{
								Name = @string,
								Version = 1,
								Selected = true
							});
						}
					}
				}
			}
			return list;
		}

		// Token: 0x04000236 RID: 566
		public const string subTypeICMP = "ICMP";

		// Token: 0x04000237 RID: 567
		public const string subTypeSNMP = "SNMP";

		// Token: 0x04000238 RID: 568
		public const int UNDEFINED_VALUE = -2;
	}
}
