﻿using System;
using System.Collections.Generic;
using System.Linq;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000099 RID: 153
	public sealed class LicenseSaturationNotificationItemDAL : NotificationItemDAL
	{
		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x0600071D RID: 1821 RVA: 0x0002D870 File Offset: 0x0002BA70
		private static string NotificationMessge
		{
			get
			{
				return string.Format(Resources.LIBCODE_PCC_24, Array.Empty<object>()) + " " + string.Format(Resources.LIBCODE_PCC_25, Array.Empty<object>());
			}
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x0002D89A File Offset: 0x0002BA9A
		protected override Guid GetNotificationItemTypeId()
		{
			return GenericNotificationItem.LicenseSaturationNotificationTypeGuid;
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0002D8A1 File Offset: 0x0002BAA1
		public static LicenseSaturationNotificationItemDAL GetItem()
		{
			return NotificationItemDAL.GetItemById<LicenseSaturationNotificationItemDAL>(LicenseSaturationNotificationItemDAL.LicenseSaturationNotificationItemId);
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x0002D8B0 File Offset: 0x0002BAB0
		public static void Show(IEnumerable<string> elementsOverLimit)
		{
			string text = string.Join(";", elementsOverLimit.ToArray<string>());
			LicenseSaturationNotificationItemDAL item = LicenseSaturationNotificationItemDAL.GetItem();
			if (item == null)
			{
				NotificationItemDAL.Insert<LicenseSaturationNotificationItemDAL>(LicenseSaturationNotificationItemDAL.LicenseSaturationNotificationItemId, LicenseSaturationNotificationItemDAL.NotificationMessge, text, false, LicenseSaturationNotificationItemDAL.popupCallFunction, null, null);
				return;
			}
			if (text == item.Description)
			{
				return;
			}
			if (string.IsNullOrEmpty(item.Description) || elementsOverLimit.Except(item.Description.Split(new char[]
			{
				';'
			})).Count<string>() > 0)
			{
				item.SetNotAcknowledged();
			}
			item.Description = text;
			item.Update();
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x0002D952 File Offset: 0x0002BB52
		public static void Hide()
		{
			NotificationItemDAL.Delete(LicenseSaturationNotificationItemDAL.LicenseSaturationNotificationItemId);
		}

		// Token: 0x0400023C RID: 572
		public static readonly Guid LicenseSaturationNotificationItemId = new Guid("{B138550D-824C-482d-9CBB-D82A6C95EC3B}");

		// Token: 0x0400023D RID: 573
		private static readonly string popupCallFunction = "javascript:SW.Core.SalesTrigger.ShowLicensePopupAsync();";
	}
}
