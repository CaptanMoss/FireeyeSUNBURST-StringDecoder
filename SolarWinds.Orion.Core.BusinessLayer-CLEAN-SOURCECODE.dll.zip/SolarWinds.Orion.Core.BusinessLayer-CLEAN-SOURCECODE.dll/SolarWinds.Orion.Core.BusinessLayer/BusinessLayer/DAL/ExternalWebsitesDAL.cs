﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Common.Swis;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x0200009F RID: 159
	internal static class ExternalWebsitesDAL
	{
		// Token: 0x060007A3 RID: 1955 RVA: 0x000354A8 File Offset: 0x000336A8
		public static ExternalWebsite Get(int id)
		{
			return Collection<int, ExternalWebsite>.GetCollectionItem<ExternalWebsites>(new Collection<int, ExternalWebsite>.CreateElement(ExternalWebsitesDAL.Create), "SELECT * FROM ExternalWebsites WHERE ExternalWebsiteID=@site", new SqlParameter[]
			{
				new SqlParameter("@site", id)
			});
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x000354D9 File Offset: 0x000336D9
		public static ExternalWebsites GetAll()
		{
			return Collection<int, ExternalWebsite>.FillCollection<ExternalWebsites>(new Collection<int, ExternalWebsite>.CreateElement(ExternalWebsitesDAL.Create), "SELECT * FROM ExternalWebsites", Array.Empty<SqlParameter>());
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x000354F8 File Offset: 0x000336F8
		public static void Delete(int id)
		{
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("DELETE FROM ExternalWebsites WHERE ExternalWebsiteID=@site"))
			{
				textCommand.Parameters.AddWithValue("site", id);
				SqlHelper.ExecuteNonQuery(textCommand);
			}
			ExternalWebsitesDAL.ClearMenuCache();
		}

		// Token: 0x060007A6 RID: 1958 RVA: 0x00035550 File Offset: 0x00033750
		public static int Insert(ExternalWebsite site)
		{
			int result;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("INSERT ExternalWebsites (ShortTitle, FullTitle, URL) VALUES (@short, @full, @url)\nSELECT scope_identity()"))
			{
				ExternalWebsitesDAL.AddParams(textCommand, site);
				result = Convert.ToInt32(SqlHelper.ExecuteScalar(textCommand));
			}
			ExternalWebsitesDAL.ClearMenuCache();
			return result;
		}

		// Token: 0x060007A7 RID: 1959 RVA: 0x000355A0 File Offset: 0x000337A0
		public static void Update(ExternalWebsite site)
		{
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("UPDATE ExternalWebsites SET ShortTitle=@short, FullTitle=@full, URL=@url WHERE ExternalWebsiteID=@site"))
			{
				ExternalWebsitesDAL.AddParams(textCommand, site);
				SqlHelper.ExecuteNonQuery(textCommand);
			}
			ExternalWebsitesDAL.ClearMenuCache();
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x000355E8 File Offset: 0x000337E8
		private static void AddParams(SqlCommand command, ExternalWebsite site)
		{
			command.Parameters.AddWithValue("site", site.ID);
			command.Parameters.AddWithValue("short", site.ShortTitle);
			command.Parameters.AddWithValue("full", site.FullTitle);
			command.Parameters.AddWithValue("url", site.URL);
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x00035658 File Offset: 0x00033858
		private static ExternalWebsite Create(IDataReader reader)
		{
			return new ExternalWebsite
			{
				ID = (int)reader["ExternalWebsiteID"],
				ShortTitle = (string)reader["ShortTitle"],
				FullTitle = (string)reader["FullTitle"],
				URL = (string)reader["URL"]
			};
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x000356C4 File Offset: 0x000338C4
		private static void ClearMenuCache()
		{
			try
			{
				using (SwisConnectionProxy swisConnectionProxy = ExternalWebsitesDAL._swisConnectionProxyFactory.Value.CreateConnection())
				{
					swisConnectionProxy.Invoke<object>("Orion.Web.Menu", "ClearCache", Array.Empty<object>());
				}
			}
			catch (Exception ex)
			{
				ExternalWebsitesDAL._log.Warn("Could not clear Orion.Web.Menu cache in $ExternalWebsitesDAL.", ex);
			}
		}

		// Token: 0x0400024E RID: 590
		private static readonly Log _log = new Log();

		// Token: 0x0400024F RID: 591
		private static readonly Lazy<ISwisConnectionProxyFactory> _swisConnectionProxyFactory = new Lazy<ISwisConnectionProxyFactory>(() => new SwisConnectionProxyFactory(), LazyThreadSafetyMode.PublicationOnly);

		// Token: 0x020001A1 RID: 417
		private static class Fields
		{
			// Token: 0x0400051D RID: 1309
			public const string ID = "ExternalWebsiteID";

			// Token: 0x0400051E RID: 1310
			public const string ShortTitle = "ShortTitle";

			// Token: 0x0400051F RID: 1311
			public const string FullTitle = "FullTitle";

			// Token: 0x04000520 RID: 1312
			public const string URL = "URL";
		}
	}
}
