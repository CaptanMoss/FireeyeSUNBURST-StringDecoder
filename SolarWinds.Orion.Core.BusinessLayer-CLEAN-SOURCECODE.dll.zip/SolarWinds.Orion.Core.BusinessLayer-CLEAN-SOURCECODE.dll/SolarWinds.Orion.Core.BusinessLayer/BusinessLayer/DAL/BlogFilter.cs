﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x0200009B RID: 155
	public class BlogFilter : NotificationItemFilter
	{
		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x06000773 RID: 1907 RVA: 0x00033EE0 File Offset: 0x000320E0
		// (set) Token: 0x06000774 RID: 1908 RVA: 0x00033EE8 File Offset: 0x000320E8
		public int MaxResults { get; set; }

		// Token: 0x06000775 RID: 1909 RVA: 0x00033EF1 File Offset: 0x000320F1
		public BlogFilter(bool includeAcknowledged, bool includeIgnored, int maxResults) : base(includeAcknowledged, includeIgnored)
		{
			this.MaxResults = maxResults;
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x00033F02 File Offset: 0x00032102
		public BlogFilter() : this(false, false, -1)
		{
		}
	}
}
