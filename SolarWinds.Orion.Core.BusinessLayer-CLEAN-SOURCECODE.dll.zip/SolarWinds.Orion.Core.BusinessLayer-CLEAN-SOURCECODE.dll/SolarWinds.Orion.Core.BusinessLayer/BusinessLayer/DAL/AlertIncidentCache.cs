﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Models.Alerts;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000084 RID: 132
	internal class AlertIncidentCache
	{
		// Token: 0x06000672 RID: 1650 RVA: 0x00026D54 File Offset: 0x00024F54
		private AlertIncidentCache()
		{
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x00026D68 File Offset: 0x00024F68
		public static AlertIncidentCache Build(IInformationServiceProxy2 swisProxy, int? alertObjectId = null, bool detectIntegration = false)
		{
			if (swisProxy == null)
			{
				throw new ArgumentNullException("swisProxy");
			}
			AlertIncidentCache alertIncidentCache = new AlertIncidentCache();
			try
			{
				if (AlertIncidentCache.isIncidentIntegrationAvailable == null || detectIntegration)
				{
					DataTable dataTable = swisProxy.Query("\r\nSELECT COUNT(EntityName) AS Cnt\r\nFROM Metadata.EntityMetadata\r\nWHERE EntityName = 'Orion.ESI.AlertIncident'");
					if (dataTable == null || dataTable.Rows.Count == 0 || Convert.ToUInt32(dataTable.Rows[0][0]) == 0U)
					{
						AlertIncidentCache.log.Debug("Incident integration not found");
						AlertIncidentCache.isIncidentIntegrationAvailable = new bool?(false);
					}
					else
					{
						AlertIncidentCache.log.Debug("Incident integration found");
						AlertIncidentCache.isIncidentIntegrationAvailable = new bool?(true);
					}
				}
				if (!AlertIncidentCache.isIncidentIntegrationAvailable.Value)
				{
					return alertIncidentCache;
				}
				DataTable dataTable2;
				if (alertObjectId != null)
				{
					string text = string.Format("\r\nSELECT AlertObjectID, IncidentNumber, IncidentUrl, AssignedTo\r\nFROM Orion.ESI.AlertIncident\r\nWHERE AlertTriggerState > 0 {0}", "AND AlertObjectID = @aoId");
					dataTable2 = swisProxy.Query(text, new Dictionary<string, object>
					{
						{
							"aoId",
							alertObjectId.Value
						}
					});
				}
				else
				{
					string text2 = string.Format("\r\nSELECT AlertObjectID, IncidentNumber, IncidentUrl, AssignedTo\r\nFROM Orion.ESI.AlertIncident\r\nWHERE AlertTriggerState > 0 {0}", string.Empty);
					dataTable2 = swisProxy.Query(text2);
				}
				foreach (object obj in dataTable2.Rows)
				{
					DataRow dataRow = (DataRow)obj;
					int key = (int)dataRow[0];
					AlertIncidentCache.IncidentInfo item = new AlertIncidentCache.IncidentInfo
					{
						Number = (AlertIncidentCache.Get<string>(dataRow, 1) ?? string.Empty),
						Url = (AlertIncidentCache.Get<string>(dataRow, 2) ?? string.Empty),
						AssignedTo = (AlertIncidentCache.Get<string>(dataRow, 3) ?? string.Empty)
					};
					List<AlertIncidentCache.IncidentInfo> list;
					if (!alertIncidentCache.incidentInfoByAlertObjectId.TryGetValue(key, out list))
					{
						list = (alertIncidentCache.incidentInfoByAlertObjectId[key] = new List<AlertIncidentCache.IncidentInfo>());
					}
					list.Add(item);
				}
			}
			catch (Exception ex)
			{
				AlertIncidentCache.log.Error(ex);
			}
			return alertIncidentCache;
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x00026F8C File Offset: 0x0002518C
		public void FillIncidentInfo(ActiveAlert activeAlert)
		{
			if (activeAlert == null)
			{
				throw new ArgumentNullException("activeAlert");
			}
			List<AlertIncidentCache.IncidentInfo> list;
			if (!this.incidentInfoByAlertObjectId.TryGetValue(activeAlert.Id, out list) || list.Count == 0)
			{
				return;
			}
			if (list.Count == 1)
			{
				activeAlert.IncidentNumber = list[0].Number;
				activeAlert.IncidentUrl = list[0].Url;
				activeAlert.AssignedTo = list[0].AssignedTo;
				return;
			}
			activeAlert.IncidentNumber = string.Format(CultureInfo.InvariantCulture, Resources2.ActiveAlertsGrid_IncidentsClomun_ValueFormat, list.Count);
			activeAlert.IncidentUrl = string.Format(CultureInfo.InvariantCulture, "/Orion/View.aspx?NetObject=AAT:{0}", activeAlert.Id);
			List<string> list2 = (from i in list
			select i.AssignedTo into u
			where !string.IsNullOrEmpty(u)
			select u).Distinct<string>().ToList<string>();
			if (list2.Count == 1)
			{
				activeAlert.AssignedTo = list2.First<string>();
				return;
			}
			activeAlert.AssignedTo = Resources2.ActiveAlertsGrid_IncidentAssignee_MultiUser;
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x000270BC File Offset: 0x000252BC
		private static T Get<T>(DataRow row, int colIndex)
		{
			if (row[colIndex] != DBNull.Value)
			{
				return (T)((object)row[colIndex]);
			}
			return default(T);
		}

		// Token: 0x0400020C RID: 524
		private static readonly Log log = new Log();

		// Token: 0x0400020D RID: 525
		private static bool? isIncidentIntegrationAvailable = null;

		// Token: 0x0400020E RID: 526
		internal const string AlertUrlFormat = "/Orion/View.aspx?NetObject=AAT:{0}";

		// Token: 0x0400020F RID: 527
		internal Dictionary<int, List<AlertIncidentCache.IncidentInfo>> incidentInfoByAlertObjectId = new Dictionary<int, List<AlertIncidentCache.IncidentInfo>>();

		// Token: 0x02000175 RID: 373
		internal class IncidentInfo
		{
			// Token: 0x17000159 RID: 345
			// (get) Token: 0x06000C00 RID: 3072 RVA: 0x0004ACCD File Offset: 0x00048ECD
			// (set) Token: 0x06000C01 RID: 3073 RVA: 0x0004ACD5 File Offset: 0x00048ED5
			public string Number { get; set; }

			// Token: 0x1700015A RID: 346
			// (get) Token: 0x06000C02 RID: 3074 RVA: 0x0004ACDE File Offset: 0x00048EDE
			// (set) Token: 0x06000C03 RID: 3075 RVA: 0x0004ACE6 File Offset: 0x00048EE6
			public string Url { get; set; }

			// Token: 0x1700015B RID: 347
			// (get) Token: 0x06000C04 RID: 3076 RVA: 0x0004ACEF File Offset: 0x00048EEF
			// (set) Token: 0x06000C05 RID: 3077 RVA: 0x0004ACF7 File Offset: 0x00048EF7
			public string AssignedTo { get; set; }
		}
	}
}
