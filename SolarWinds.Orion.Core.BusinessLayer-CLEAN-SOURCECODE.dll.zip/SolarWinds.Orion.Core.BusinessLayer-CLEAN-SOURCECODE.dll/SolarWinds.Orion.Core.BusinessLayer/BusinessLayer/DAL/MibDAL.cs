﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Models.Mib;

namespace SolarWinds.Orion.Core.BusinessLayer.DAL
{
	// Token: 0x02000093 RID: 147
	internal class MibDAL
	{
		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x060006EC RID: 1772 RVA: 0x0002C14C File Offset: 0x0002A34C
		// (set) Token: 0x060006ED RID: 1773 RVA: 0x0002C18C File Offset: 0x0002A38C
		private static CancellationTokenSource CancellationTokenSource
		{
			get
			{
				object tokenLock = MibDAL._tokenLock;
				CancellationTokenSource cancellationTokenSource;
				lock (tokenLock)
				{
					cancellationTokenSource = MibDAL._cancellationTokenSource;
				}
				return cancellationTokenSource;
			}
			set
			{
				object tokenLock = MibDAL._tokenLock;
				lock (tokenLock)
				{
					MibDAL._cancellationTokenSource = value;
				}
			}
		}

		// Token: 0x060006EE RID: 1774 RVA: 0x0002C1CC File Offset: 0x0002A3CC
		public Oid GetOid(string oid)
		{
			Oid oid2 = this.GetOid(oid, true);
			if (oid2 == null)
			{
				oid2 = this.GetOid(oid, false);
			}
			return oid2;
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x0002C1F4 File Offset: 0x0002A3F4
		private Oid GetOid(string oid, bool clean)
		{
			Oid oid2;
			using (OleDbConnection dbconnection = MibHelper.GetDBConnection())
			{
				dbconnection.Open();
				oid2 = this.GetOid(oid, dbconnection, clean);
			}
			return oid2;
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x0002C234 File Offset: 0x0002A434
		private Oid GetOid(string oid, OleDbConnection connection, bool clean)
		{
			Oid result = null;
			using (OleDbCommand oleDbCommand = new OleDbCommand())
			{
				string commandText = string.Empty;
				if (clean)
				{
					commandText = string.Format("Select TOP 1 {0} from Tree WHERE Primary = -1 AND OID=@Oid AND Description <> 'unknown';", "Index, MIB, Name, Primary, OID, Description, Access, Status, Units, Enum, TypeS");
				}
				else
				{
					commandText = string.Format("Select TOP 1 {0} from Tree WHERE Primary = -1 AND OID=@Oid;", "Index, MIB, Name, Primary, OID, Description, Access, Status, Units, Enum, TypeS");
				}
				oleDbCommand.CommandText = commandText;
				oleDbCommand.Parameters.AddWithValue("Oid", oid);
				using (IDataReader dataReader = OleDbHelper.ExecuteReader(oleDbCommand, connection))
				{
					if (dataReader.Read())
					{
						result = this.CreateOid(dataReader, connection);
					}
				}
			}
			return result;
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x0000B161 File Offset: 0x00009361
		public MemoryStream GetIcon(string oid)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x0002C2DC File Offset: 0x0002A4DC
		public Dictionary<string, MemoryStream> GetIcons()
		{
			byte[] buffer = new byte[0];
			Dictionary<string, MemoryStream> dictionary = new Dictionary<string, MemoryStream>();
			using (OleDbConnection dbconnection = MibHelper.GetDBConnection())
			{
				using (OleDbCommand oleDbCommand = new OleDbCommand())
				{
					dbconnection.Open();
					oleDbCommand.CommandText = "Select OID, [Small Icon] From Icons";
					using (IDataReader dataReader = OleDbHelper.ExecuteReader(oleDbCommand, dbconnection))
					{
						while (dataReader.Read())
						{
							if (!(dataReader["Small Icon"] is DBNull))
							{
								buffer = (byte[])dataReader["Small Icon"];
								dictionary.Add(dataReader["OID"].ToString(), new MemoryStream(buffer, true));
							}
						}
					}
				}
			}
			return dictionary;
		}

		// Token: 0x060006F3 RID: 1779 RVA: 0x0002C3B8 File Offset: 0x0002A5B8
		public Oids GetChildOids(string parentOid)
		{
			List<string> uniqueChildOids = this.GetUniqueChildOids(parentOid);
			Oids oids = new Oids();
			using (OleDbConnection dbconnection = MibHelper.GetDBConnection())
			{
				dbconnection.Open();
				foreach (string oid in uniqueChildOids)
				{
					Oid oid2 = this.GetOid(oid, dbconnection, true);
					if (oid2 == null)
					{
						oid2 = this.GetOid(oid, dbconnection, false);
					}
					oids.Add(oid2);
				}
			}
			return oids;
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x0002C458 File Offset: 0x0002A658
		public List<string> GetUniqueChildOids(string parentOid)
		{
			List<string> list = new List<string>();
			using (OleDbConnection dbconnection = MibHelper.GetDBConnection())
			{
				dbconnection.Open();
				using (OleDbCommand oleDbCommand = new OleDbCommand())
				{
					oleDbCommand.CommandText = string.Format("Select DISTINCT Name, OID, Index from Tree WHERE Primary = -1 AND ParentOID=@parentOid order by index;", "Index, MIB, Name, Primary, OID, Description, Access, Status, Units, Enum, TypeS");
					oleDbCommand.Parameters.AddWithValue("parentOid", parentOid);
					using (IDataReader dataReader = OleDbHelper.ExecuteReader(oleDbCommand, dbconnection))
					{
						while (dataReader.Read())
						{
							list.Add(DatabaseFunctions.GetString(dataReader, "OID"));
						}
					}
				}
			}
			return list;
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x0002C510 File Offset: 0x0002A710
		public OidEnums GetEnums(string enumName)
		{
			OidEnums oidEnums = new OidEnums();
			if (string.IsNullOrEmpty(enumName))
			{
				return oidEnums;
			}
			using (OleDbConnection dbconnection = MibHelper.GetDBConnection())
			{
				dbconnection.Open();
				using (OleDbCommand oleDbCommand = new OleDbCommand())
				{
					oleDbCommand.CommandText = string.Format("Select {0} from Enums WHERE Name=@name order by Value;", "Name, Value, Enum");
					oleDbCommand.Parameters.AddWithValue("name", enumName);
					using (IDataReader dataReader = OleDbHelper.ExecuteReader(oleDbCommand, dbconnection))
					{
						while (dataReader.Read())
						{
							oidEnums.Add(new OidEnum
							{
								Id = DatabaseFunctions.GetDouble(dataReader, 1).ToString(),
								Name = DatabaseFunctions.GetString(dataReader, 2)
							});
						}
					}
				}
			}
			return oidEnums;
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x0000B161 File Offset: 0x00009361
		public Oids GetSearchingOidsByDescription(string searchCriteria, string searchMIBsCriteria)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x0002C5F8 File Offset: 0x0002A7F8
		public void CancelRunningCommand()
		{
			if (MibDAL.CancellationTokenSource != null)
			{
				try
				{
					MibDAL.CancellationTokenSource.Cancel();
				}
				catch (AggregateException)
				{
				}
			}
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x0002C62C File Offset: 0x0002A82C
		public Oids GetSearchingOidsByName(string searchCriteria)
		{
			new List<string>();
			Oids oids = new Oids();
			using (OleDbConnection connection = MibHelper.GetDBConnection())
			{
				connection.Open();
				MibDAL.CancellationTokenSource = new CancellationTokenSource();
				using (OleDbCommand oleDbCommand = new OleDbCommand())
				{
					oleDbCommand.CommandText = string.Format("SELECT TOP 250 {0} FROM Tree WHERE (Primary = -1) AND ( Name LIKE @SearchValue OR Description LIKE '%' + @SearchValue + '%' OR Mib LIKE @SearchValue)", "Index, MIB, Name, Primary, OID, Description, Access, Status, Units, Enum, TypeS");
					oleDbCommand.Parameters.AddWithValue("@SearchValue", searchCriteria);
					using (IDataReader reader = OleDbHelper.ExecuteReader(oleDbCommand, connection))
					{
						foreach (Oid oid in Task.Factory.StartNew<Oids>(() => this.getOidsFromReader(reader, connection), MibDAL.CancellationTokenSource.Token).Result)
						{
							oids.Add(oid);
						}
					}
				}
			}
			return oids;
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x0002C780 File Offset: 0x0002A980
		private Oids getOidsFromReader(IDataReader reader, OleDbConnection connection)
		{
			Oids oids = new Oids();
			while (reader.Read())
			{
				MibDAL.CancellationTokenSource.Token.ThrowIfCancellationRequested();
				Oid oid = this.CreateOid(reader, connection);
				oids.Add(oid);
			}
			return oids;
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x0002C7C0 File Offset: 0x0002A9C0
		public bool IsMibDatabaseAvailable()
		{
			return MibHelper.IsMIBDatabaseAvailable();
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x0002C7C8 File Offset: 0x0002A9C8
		private Oid CreateOid(IDataReader reader, OleDbConnection connection)
		{
			Oid oid = new Oid();
			oid.ID = DatabaseFunctions.GetString(reader, 4);
			oid.Name = DatabaseFunctions.GetString(reader, 2);
			oid.Description = DatabaseFunctions.GetString(reader, 5);
			oid.MIB = DatabaseFunctions.GetString(reader, 1);
			oid.Access = DatabaseFunctions.GetByte(reader, 6);
			oid.Status = DatabaseFunctions.GetByte(reader, 7);
			oid.Units = DatabaseFunctions.GetString(reader, 8);
			oid.StringType = DatabaseFunctions.GetString(reader, 10);
			oid.HasChildren = this.HasChildren(oid.ID, connection);
			oid.Enums = this.GetEnums(DatabaseFunctions.GetString(reader, 9));
			oid.TreeIndex = DatabaseFunctions.GetInt32(reader, 0).ToString();
			MibHelper.CleanupDescription(oid);
			MibHelper.SetTypeInfo(oid);
			return oid;
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x0002C890 File Offset: 0x0002AA90
		private bool HasChildren(string oid, OleDbConnection connection)
		{
			using (OleDbCommand oleDbCommand = new OleDbCommand())
			{
				oleDbCommand.CommandText = "Select COUNT(*) from Tree WHERE Primary = -1 AND ParentOID=@oid;";
				oleDbCommand.Parameters.AddWithValue("parentOid", oid);
				if ((int)OleDbHelper.ExecuteScalar(oleDbCommand, connection) > 0)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0400022C RID: 556
		private const string TreeColumns = "Index, MIB, Name, Primary, OID, Description, Access, Status, Units, Enum, TypeS";

		// Token: 0x0400022D RID: 557
		private const string EnumColumns = "Name, Value, Enum";

		// Token: 0x0400022E RID: 558
		private static readonly Log _myLog = new Log();

		// Token: 0x0400022F RID: 559
		private static CancellationTokenSource _cancellationTokenSource;

		// Token: 0x04000230 RID: 560
		private static object _tokenLock = new object();

		// Token: 0x02000188 RID: 392
		private enum EnumColumnOrder
		{
			// Token: 0x040004EC RID: 1260
			EnumName,
			// Token: 0x040004ED RID: 1261
			EnumValue,
			// Token: 0x040004EE RID: 1262
			EnumEnum
		}
	}
}
