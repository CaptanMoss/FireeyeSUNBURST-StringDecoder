﻿using System;
using SolarWinds.Logging;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000037 RID: 55
	internal class ScheduledJobWatcher
	{
		// Token: 0x060003E8 RID: 1000 RVA: 0x00008409 File Offset: 0x00006609
		public void Start()
		{
		}

		// Token: 0x040000E4 RID: 228
		private static readonly Log log = new Log();
	}
}
