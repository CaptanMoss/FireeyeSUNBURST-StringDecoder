﻿using System;
using SolarWinds.Orion.Core.Discovery;

namespace SolarWinds.Orion.Core.BusinessLayer.Discovery.DiscoveryCache
{
	// Token: 0x02000082 RID: 130
	public interface IPersistentDiscoveryCache
	{
		// Token: 0x0600066B RID: 1643
		DiscoveryResultItem GetResultForNode(int nodeId);

		// Token: 0x0600066C RID: 1644
		void StoreResultForNode(int nodeId, DiscoveryResultItem result);
	}
}
