﻿using System;
using System.Threading;
using System.Threading.Tasks;
using SolarWinds.Logging;

namespace SolarWinds.Orion.Core.BusinessLayer.Discovery
{
	// Token: 0x0200007C RID: 124
	internal class RescheduleDiscoveryJobsTask : IDisposable
	{
		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000621 RID: 1569 RVA: 0x0002501C File Offset: 0x0002321C
		public bool IsPeriodicRescheduleTaskRunning
		{
			get
			{
				object reschedulingStartStopControlLock = this._reschedulingStartStopControlLock;
				bool result;
				lock (reschedulingStartStopControlLock)
				{
					result = (this._isPeriodicReschedulingEnabled != null && !this._isPeriodicReschedulingEnabled.IsCancellationRequested);
				}
				return result;
			}
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x00025074 File Offset: 0x00023274
		public RescheduleDiscoveryJobsTask(Func<int, bool> updateDiscoveryJobsDelegate, int engineId, bool keepRunning, TimeSpan periodicRetryInterval)
		{
			if (periodicRetryInterval <= TimeSpan.Zero)
			{
				throw new ArgumentOutOfRangeException("periodicRetryInterval", periodicRetryInterval, "Periodic retry interval has to be greater than zero");
			}
			if (updateDiscoveryJobsDelegate == null)
			{
				throw new ArgumentNullException("updateDiscoveryJobsDelegate");
			}
			this._updateDiscoveryJobsDelegate = updateDiscoveryJobsDelegate;
			this._engineId = engineId;
			this._keepRunning = keepRunning;
			this._periodicRetryInterval = periodicRetryInterval;
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x000250FC File Offset: 0x000232FC
		public void StartPeriodicRescheduleTask()
		{
			object reschedulingStartStopControlLock = this._reschedulingStartStopControlLock;
			lock (reschedulingStartStopControlLock)
			{
				if (!this._isDisposed)
				{
					if (!this.IsPeriodicRescheduleTaskRunning)
					{
						this._isPeriodicReschedulingEnabled = new CancellationTokenSource();
						RescheduleDiscoveryJobsTask.Log.InfoFormat("Starting periodic discovery jobs rescheduling for engine {0}", this._engineId);
						Task.Run(delegate()
						{
							this.PeriodicReschedule(this._isPeriodicReschedulingEnabled);
						}).ContinueWith(new Action<Task>(this.LogTaskUnhandledException));
					}
					else
					{
						RescheduleDiscoveryJobsTask.Log.WarnFormat("Periodic discovery jobs rescheduling is already running for engine {0}", this._engineId);
					}
				}
			}
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x000251B0 File Offset: 0x000233B0
		public void StopPeriodicRescheduleTask()
		{
			object reschedulingStartStopControlLock = this._reschedulingStartStopControlLock;
			lock (reschedulingStartStopControlLock)
			{
				CancellationTokenSource isPeriodicReschedulingEnabled = this._isPeriodicReschedulingEnabled;
				if (isPeriodicReschedulingEnabled != null)
				{
					isPeriodicReschedulingEnabled.Cancel();
				}
				this._isPeriodicReschedulingEnabled = null;
			}
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x00025204 File Offset: 0x00023404
		private void PeriodicReschedule(CancellationTokenSource isPeriodicReschedulingEnabled)
		{
			while (!isPeriodicReschedulingEnabled.IsCancellationRequested)
			{
				object reschedulingAttemptLock = this._reschedulingAttemptLock;
				lock (reschedulingAttemptLock)
				{
					if (this.TryRescheduleDiscoveryJobsTask())
					{
						bool keepRunning = this._keepRunning;
						RescheduleDiscoveryJobsTask.Log.DebugFormat("Periodic discovery jobs rescheduling  for engine {0} successful. Keep running: {1}", this._engineId, keepRunning);
						if (!keepRunning)
						{
							isPeriodicReschedulingEnabled.Cancel();
							break;
						}
					}
					else
					{
						RescheduleDiscoveryJobsTask.Log.DebugFormat("Periodic discovery jobs rescheduling for engine {0} failed - next attempt in {1}.", this._engineId, this._periodicRetryInterval);
					}
				}
				Task.Delay(this._periodicRetryInterval, isPeriodicReschedulingEnabled.Token).ContinueWith(new Action<Task>(this.LogTaskUnhandledException)).Wait();
			}
			RescheduleDiscoveryJobsTask.Log.DebugFormat("Periodic discovery jobs rescheduling stopped for engine {0}", this._engineId);
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x000252F0 File Offset: 0x000234F0
		public void QueueRescheduleAttempt()
		{
			object reschedulingStartStopControlLock = this._reschedulingStartStopControlLock;
			bool flag = false;
			try
			{
				Monitor.Enter(reschedulingStartStopControlLock, ref flag);
				if (!this._isDisposed)
				{
					DateTime invocationTime = DateTime.UtcNow;
					RescheduleDiscoveryJobsTask.Log.DebugFormat("Invoking manual discovery jobs rescheduling for engine {0}", this._engineId);
					Task.Run(delegate()
					{
						this.ManualRescheduleAttempt(invocationTime);
					}).ContinueWith(new Action<Task>(this.LogTaskUnhandledException));
				}
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(reschedulingStartStopControlLock);
				}
			}
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0002538C File Offset: 0x0002358C
		private void ManualRescheduleAttempt(DateTime invocationTime)
		{
			object reschedulingAttemptLock = this._reschedulingAttemptLock;
			lock (reschedulingAttemptLock)
			{
				if (invocationTime > this._lastSuccess)
				{
					if (!this.TryRescheduleDiscoveryJobsTask() && !this.IsPeriodicRescheduleTaskRunning)
					{
						this.StartPeriodicRescheduleTask();
					}
				}
				else
				{
					RescheduleDiscoveryJobsTask.Log.DebugFormat("Manual discovery jobs rescheduling skipped. Last success is newer than invocation time", Array.Empty<object>());
				}
			}
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x00025400 File Offset: 0x00023600
		private bool TryRescheduleDiscoveryJobsTask()
		{
			if (this._isDisposed)
			{
				return false;
			}
			try
			{
				if (this._updateDiscoveryJobsDelegate(this._engineId))
				{
					this._lastSuccess = DateTime.UtcNow;
					RescheduleDiscoveryJobsTask.Log.DebugFormat("Discovery jobs rescheduling finished for engine {0}", this._engineId);
					return true;
				}
				RescheduleDiscoveryJobsTask.Log.DebugFormat("Discovery jobs rescheduling failed for engine {0}", this._engineId);
			}
			catch (Exception ex)
			{
				RescheduleDiscoveryJobsTask.Log.Error(string.Format("RescheduleDiscoveryJobsTask.TryRescheduleDiscoveryJobsTask failed for engine {0}", this._engineId), ex);
			}
			return false;
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x000254A8 File Offset: 0x000236A8
		private void LogTaskUnhandledException(Task task)
		{
			if (task.IsFaulted)
			{
				RescheduleDiscoveryJobsTask.Log.Error("Task faulted with unhandled exception", task.Exception);
			}
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x000254C7 File Offset: 0x000236C7
		public void Dispose()
		{
			this._isDisposed = true;
			this.StopPeriodicRescheduleTask();
		}

		// Token: 0x040001EE RID: 494
		private static readonly Log Log = new Log();

		// Token: 0x040001EF RID: 495
		private readonly Func<int, bool> _updateDiscoveryJobsDelegate;

		// Token: 0x040001F0 RID: 496
		private readonly int _engineId;

		// Token: 0x040001F1 RID: 497
		private readonly bool _keepRunning;

		// Token: 0x040001F2 RID: 498
		private readonly TimeSpan _periodicRetryInterval;

		// Token: 0x040001F3 RID: 499
		private CancellationTokenSource _isPeriodicReschedulingEnabled;

		// Token: 0x040001F4 RID: 500
		private readonly object _reschedulingAttemptLock = new object();

		// Token: 0x040001F5 RID: 501
		private readonly object _reschedulingStartStopControlLock = new object();

		// Token: 0x040001F6 RID: 502
		private DateTime _lastSuccess = DateTime.MinValue;

		// Token: 0x040001F7 RID: 503
		private volatile bool _isDisposed;
	}
}
