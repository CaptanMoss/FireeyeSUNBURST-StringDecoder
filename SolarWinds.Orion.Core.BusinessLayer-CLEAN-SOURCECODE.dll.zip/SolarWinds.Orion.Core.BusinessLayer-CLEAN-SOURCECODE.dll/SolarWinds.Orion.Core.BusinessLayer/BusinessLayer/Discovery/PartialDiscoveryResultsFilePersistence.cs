﻿using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;
using SolarWinds.Logging;
using SolarWinds.Orion.Discovery.Job;

namespace SolarWinds.Orion.Core.BusinessLayer.Discovery
{
	// Token: 0x02000081 RID: 129
	public class PartialDiscoveryResultsFilePersistence : IPartialDiscoveryResultsPersistence
	{
		// Token: 0x06000661 RID: 1633 RVA: 0x0002666C File Offset: 0x0002486C
		public PartialDiscoveryResultsFilePersistence()
		{
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x0002668B File Offset: 0x0002488B
		internal PartialDiscoveryResultsFilePersistence(string customPersistencePath)
		{
			this._persistenceFolderPath = customPersistencePath;
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x000266B4 File Offset: 0x000248B4
		public bool SaveResult(Guid jobId, OrionDiscoveryJobResult result)
		{
			if (result == null)
			{
				throw new ArgumentNullException("result");
			}
			string text = null;
			try
			{
				text = this.GetResultsTempFileName(jobId);
				DataContractSerializer dataContractSerializer = new DataContractSerializer(typeof(OrionDiscoveryJobResult));
				using (AesCryptoServiceProvider aesCryptoServiceProvider = new AesCryptoServiceProvider())
				{
					aesCryptoServiceProvider.Key = this.GetEncryptionKey(jobId);
					aesCryptoServiceProvider.IV = this.GetEncryptionIV(aesCryptoServiceProvider, jobId);
					aesCryptoServiceProvider.Mode = CipherMode.CBC;
					aesCryptoServiceProvider.Padding = PaddingMode.PKCS7;
					using (ICryptoTransform cryptoTransform = aesCryptoServiceProvider.CreateEncryptor(aesCryptoServiceProvider.Key, aesCryptoServiceProvider.IV))
					{
						using (FileStream fileStream = new FileStream(text, FileMode.Create, FileAccess.Write))
						{
							using (CryptoStream cryptoStream = new CryptoStream(fileStream, cryptoTransform, CryptoStreamMode.Write))
							{
								using (GZipStream gzipStream = new GZipStream(cryptoStream, CompressionMode.Compress))
								{
									dataContractSerializer.WriteObject(gzipStream, result);
								}
							}
						}
					}
				}
				return true;
			}
			catch (Exception ex)
			{
				PartialDiscoveryResultsFilePersistence._log.ErrorFormat("Error saving partial discovery result for job {0} to temporary file {1}. {2}", jobId, text ?? "<unable to get filename>", ex);
			}
			return false;
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x00026810 File Offset: 0x00024A10
		public OrionDiscoveryJobResult LoadResult(Guid jobId)
		{
			string text = null;
			try
			{
				text = this.GetResultsTempFileName(jobId);
				DataContractSerializer dataContractSerializer = new DataContractSerializer(typeof(OrionDiscoveryJobResult));
				using (AesCryptoServiceProvider aesCryptoServiceProvider = new AesCryptoServiceProvider())
				{
					aesCryptoServiceProvider.Key = this.GetEncryptionKey(jobId);
					aesCryptoServiceProvider.IV = this.GetEncryptionIV(aesCryptoServiceProvider, jobId);
					aesCryptoServiceProvider.Mode = CipherMode.CBC;
					aesCryptoServiceProvider.Padding = PaddingMode.PKCS7;
					using (ICryptoTransform cryptoTransform = aesCryptoServiceProvider.CreateDecryptor(aesCryptoServiceProvider.Key, aesCryptoServiceProvider.IV))
					{
						using (FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read))
						{
							using (CryptoStream cryptoStream = new CryptoStream(fileStream, cryptoTransform, CryptoStreamMode.Read))
							{
								using (GZipStream gzipStream = new GZipStream(cryptoStream, CompressionMode.Decompress))
								{
									return (OrionDiscoveryJobResult)dataContractSerializer.ReadObject(gzipStream);
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				PartialDiscoveryResultsFilePersistence._log.ErrorFormat("Error loading partial discovery result for job {0} from temporary file {1}. {2}", jobId, text ?? "<unable to get filename>", ex);
			}
			return null;
		}

		// Token: 0x06000665 RID: 1637 RVA: 0x00026958 File Offset: 0x00024B58
		public void DeleteResult(Guid jobId)
		{
			string text = null;
			try
			{
				text = this.GetResultsTempFileName(jobId);
				File.Delete(text);
			}
			catch (Exception ex)
			{
				PartialDiscoveryResultsFilePersistence._log.ErrorFormat("Error deleting partial discovery result for job {0} temporary file {1}. {2}", jobId, text ?? "<unable to get filename>", ex);
			}
		}

		// Token: 0x06000666 RID: 1638 RVA: 0x000269AC File Offset: 0x00024BAC
		public void ClearStore()
		{
			try
			{
				if (Directory.Exists(this._persistenceFolderPath))
				{
					Directory.Delete(this._persistenceFolderPath, true);
				}
			}
			catch (Exception ex)
			{
				PartialDiscoveryResultsFilePersistence._log.ErrorFormat("Error clearing partial discovery results persistence store '{0}'. {1}", this._persistenceFolderPath, ex);
			}
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x00026A00 File Offset: 0x00024C00
		private byte[] GetEncryptionKey(Guid jobId)
		{
			return ProtectedData.Protect(Encoding.UTF8.GetBytes(jobId.ToString()), null, DataProtectionScope.LocalMachine).Take(32).ToArray<byte>();
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x00026A2C File Offset: 0x00024C2C
		private byte[] GetEncryptionIV(AesCryptoServiceProvider aesAlg, Guid jobId)
		{
			return Encoding.UTF8.GetBytes(jobId.ToString()).Take(aesAlg.BlockSize / 8).ToArray<byte>();
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x00026A57 File Offset: 0x00024C57
		private string GetResultsTempFileName(Guid jobId)
		{
			if (!Directory.Exists(this._persistenceFolderPath))
			{
				Directory.CreateDirectory(this._persistenceFolderPath);
			}
			return Path.Combine(this._persistenceFolderPath, jobId.ToString() + ".result");
		}

		// Token: 0x04000209 RID: 521
		private static readonly Log _log = new Log();

		// Token: 0x0400020A RID: 522
		private readonly string _persistenceFolderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SolarWinds/Discovery Engine/PartialResults");
	}
}
