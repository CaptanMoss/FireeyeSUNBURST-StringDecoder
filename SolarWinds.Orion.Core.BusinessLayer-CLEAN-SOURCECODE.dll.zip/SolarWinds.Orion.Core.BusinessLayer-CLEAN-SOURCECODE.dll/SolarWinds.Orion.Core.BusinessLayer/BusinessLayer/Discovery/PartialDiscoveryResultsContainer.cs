﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using SolarWinds.JobEngine;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Models.Discovery;
using SolarWinds.Orion.Core.Models.Interfaces;
using SolarWinds.Orion.Discovery.Contract.DiscoveryPlugin;
using SolarWinds.Orion.Discovery.Job;

namespace SolarWinds.Orion.Core.BusinessLayer.Discovery
{
	// Token: 0x02000080 RID: 128
	internal class PartialDiscoveryResultsContainer : IDisposable
	{
		// Token: 0x1400000B RID: 11
		// (add) Token: 0x0600064A RID: 1610 RVA: 0x00025CA8 File Offset: 0x00023EA8
		// (remove) Token: 0x0600064B RID: 1611 RVA: 0x00025CE0 File Offset: 0x00023EE0
		public event EventHandler<DiscoveryResultsCompletedEventArgs> DiscoveryResultsComplete = delegate(object <p0>, DiscoveryResultsCompletedEventArgs <p1>)
		{
		};

		// Token: 0x0600064C RID: 1612 RVA: 0x00025D15 File Offset: 0x00023F15
		public PartialDiscoveryResultsContainer() : this(new PartialDiscoveryResultsFilePersistence(), () => DateTime.UtcNow, TimeSpan.FromSeconds(10.0))
		{
		}

		// Token: 0x0600064D RID: 1613 RVA: 0x00025D50 File Offset: 0x00023F50
		internal PartialDiscoveryResultsContainer(IPartialDiscoveryResultsPersistence persistenceStore, Func<DateTime> dateTimeProvider, TimeSpan expirationCheckFrequency)
		{
			if (persistenceStore == null)
			{
				throw new ArgumentNullException("persistenceStore");
			}
			if (dateTimeProvider == null)
			{
				throw new ArgumentNullException("dateTimeProvider");
			}
			this._persistenceStore = persistenceStore;
			this._dateTimeProvider = dateTimeProvider;
			this._resultsByMainJobId = new Dictionary<Guid, List<PartialDiscoveryResultsContainer.PartialResult>>();
			this._resultsByOwnJobId = new Dictionary<Guid, PartialDiscoveryResultsContainer.PartialResult>();
			this._mainResultsReadyForComplete = new HashSet<Guid>();
			this._expirationCleanupTimer = new Timer(delegate(object x)
			{
				this.RunExpirationCheck();
			}, null, expirationCheckFrequency, expirationCheckFrequency);
		}

		// Token: 0x0600064E RID: 1614 RVA: 0x00025DF8 File Offset: 0x00023FF8
		public void CreatePartialResult(Guid scheduledJobId, OrionDiscoveryJobResult result, SortedDictionary<int, List<IDiscoveryPlugin>> orderedPlugins, JobState jobState)
		{
			if (result == null)
			{
				throw new ArgumentNullException("result");
			}
			PartialDiscoveryResultsContainer.PartialResult partialResult = new PartialDiscoveryResultsContainer.PartialResult(scheduledJobId, scheduledJobId, orderedPlugins, jobState, result.ProfileId, this._persistenceStore, DateTime.MaxValue)
			{
				Result = result
			};
			object syncRoot = this._syncRoot;
			lock (syncRoot)
			{
				this._resultsByMainJobId[partialResult.JobId] = new List<PartialDiscoveryResultsContainer.PartialResult>();
				this._resultsByMainJobId[partialResult.JobId].Add(partialResult);
				this._resultsByOwnJobId[partialResult.JobId] = partialResult;
			}
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x00025EA4 File Offset: 0x000240A4
		public void AddExpectedPartialResult(Guid scheduledJobId, OrionDiscoveryJobResult result)
		{
			if (result == null)
			{
				throw new ArgumentNullException("result");
			}
			object syncRoot = this._syncRoot;
			List<PartialDiscoveryResultsContainer.PartialResult> list;
			lock (syncRoot)
			{
				PartialDiscoveryResultsContainer.PartialResult partialResult;
				if (!this._resultsByOwnJobId.TryGetValue(scheduledJobId, out partialResult))
				{
					throw new ArgumentException("Results with given job ID are not expected.", "scheduledJobId");
				}
				partialResult.Result = result;
				list = this.TryGetCompleteResults(partialResult.MainJobId);
			}
			if (list != null)
			{
				this.OnDiscoveryResultsComplete(list);
			}
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x00025F2C File Offset: 0x0002412C
		public void ExpectPartialResult(Guid mainScheduledJobId, Guid scheduledJobId, TimeSpan timeout)
		{
			object syncRoot = this._syncRoot;
			lock (syncRoot)
			{
				List<PartialDiscoveryResultsContainer.PartialResult> list;
				if (!this._resultsByMainJobId.TryGetValue(mainScheduledJobId, out list))
				{
					throw new ArgumentException("Results with given main result ID are not in container.", "mainScheduledJobId");
				}
				PartialDiscoveryResultsContainer.PartialResult partialResult = new PartialDiscoveryResultsContainer.PartialResult(scheduledJobId, mainScheduledJobId, this._persistenceStore, this._dateTimeProvider().Add(timeout));
				list.Add(partialResult);
				this._resultsByOwnJobId[partialResult.JobId] = partialResult;
			}
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x00025FC4 File Offset: 0x000241C4
		public bool IsResultExpected(Guid scheduledJobId)
		{
			object syncRoot = this._syncRoot;
			bool result;
			lock (syncRoot)
			{
				result = (this._resultsByOwnJobId.ContainsKey(scheduledJobId) && !this._resultsByMainJobId.ContainsKey(scheduledJobId));
			}
			return result;
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00026020 File Offset: 0x00024220
		public void AllExpectedResultsRegistered(Guid mainScheduledJobId)
		{
			object syncRoot = this._syncRoot;
			List<PartialDiscoveryResultsContainer.PartialResult> list;
			lock (syncRoot)
			{
				this._mainResultsReadyForComplete.Add(mainScheduledJobId);
				list = this.TryGetCompleteResults(mainScheduledJobId);
			}
			if (list != null)
			{
				this.OnDiscoveryResultsComplete(list);
			}
		}

		// Token: 0x06000653 RID: 1619 RVA: 0x0002607C File Offset: 0x0002427C
		public void ClearStore()
		{
			this._persistenceStore.ClearStore();
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x0002608C File Offset: 0x0002428C
		public void RemoveExpectedPartialResult(Guid scheduledJobId)
		{
			object syncRoot = this._syncRoot;
			List<PartialDiscoveryResultsContainer.PartialResult> list;
			lock (syncRoot)
			{
				PartialDiscoveryResultsContainer.PartialResult partialResult;
				if (!this._resultsByOwnJobId.TryGetValue(scheduledJobId, out partialResult))
				{
					throw new ArgumentException("Results with given job ID are not expected.", "scheduledJobId");
				}
				this._resultsByOwnJobId.Remove(scheduledJobId);
				this._resultsByMainJobId[partialResult.MainJobId].Remove(partialResult);
				this._persistenceStore.DeleteResult(partialResult.JobId);
				list = this.TryGetCompleteResults(partialResult.MainJobId);
			}
			if (list != null)
			{
				this.OnDiscoveryResultsComplete(list);
			}
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x00026134 File Offset: 0x00024334
		private void RunExpirationCheck()
		{
			object syncRoot = this._syncRoot;
			lock (syncRoot)
			{
				foreach (PartialDiscoveryResultsContainer.PartialResult partialResult in this._resultsByOwnJobId.Values.ToList<PartialDiscoveryResultsContainer.PartialResult>())
				{
					if (!partialResult.HasResult && partialResult.Expiration < this._dateTimeProvider())
					{
						PartialDiscoveryResultsContainer._log.WarnFormat("Expected partial discovery results for job {0} were not received in defined time and are being discarded.", partialResult.JobId);
						this.RemoveExpectedPartialResult(partialResult.JobId);
					}
				}
			}
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x000261F8 File Offset: 0x000243F8
		private void OnDiscoveryResultsComplete(List<PartialDiscoveryResultsContainer.PartialResult> results)
		{
			if (results == null || results.Count == 0)
			{
				PartialDiscoveryResultsContainer._log.WarnFormat("Attempt to report partial discovery results completion with empty results.", Array.Empty<object>());
				return;
			}
			OrionDiscoveryJobResult completeResult = this.MergePartialResults(results);
			object syncRoot = this._syncRoot;
			lock (syncRoot)
			{
				this.RemovePartialResults(results[0].MainJobId, results);
			}
			this.DiscoveryResultsComplete(this, new DiscoveryResultsCompletedEventArgs(completeResult, results[0].OrderedPlugins, results[0].MainJobId, results[0].JobState, results[0].ProfileId));
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x000262B0 File Offset: 0x000244B0
		private List<PartialDiscoveryResultsContainer.PartialResult> TryGetCompleteResults(Guid mainResultId)
		{
			object syncRoot = this._syncRoot;
			lock (syncRoot)
			{
				List<PartialDiscoveryResultsContainer.PartialResult> list;
				if (!this._resultsByMainJobId.TryGetValue(mainResultId, out list))
				{
					throw new ArgumentException("Main results for results with given ID are not in container.");
				}
				if (this.AreAllResultsReady(list))
				{
					return list;
				}
			}
			return null;
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x00026318 File Offset: 0x00024518
		private bool AreAllResultsReady(List<PartialDiscoveryResultsContainer.PartialResult> results)
		{
			bool result = false;
			if (results.Count > 0)
			{
				if (results.All((PartialDiscoveryResultsContainer.PartialResult x) => x.HasResult))
				{
					result = this._mainResultsReadyForComplete.Contains(results[0].MainJobId);
				}
			}
			return result;
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x00026370 File Offset: 0x00024570
		private OrionDiscoveryJobResult MergePartialResults(List<PartialDiscoveryResultsContainer.PartialResult> results)
		{
			if (results.Count == 0)
			{
				throw new ArgumentException("Results for merge can't be empty.", "results");
			}
			OrionDiscoveryJobResult result = results[0].Result;
			if (result == null)
			{
				throw new ArgumentException("Main results for merge were not loaded.", "results");
			}
			OrionDiscoveryJobResult orionDiscoveryJobResult = (OrionDiscoveryJobResult)result.Copy();
			foreach (PartialDiscoveryResultsContainer.PartialResult partialResult in results.Skip(1))
			{
				this.MergePluginResults(orionDiscoveryJobResult.ProfileId, orionDiscoveryJobResult.PluginResults, partialResult.Result.PluginResults);
			}
			return orionDiscoveryJobResult;
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x00026418 File Offset: 0x00024618
		private void MergePluginResults(int? profileId, DiscoveryPluginItems<DiscoveryPluginResultBase> results, DiscoveryPluginItems<DiscoveryPluginResultBase> partialResultsToMerge)
		{
			DiscoveryPluginResultObjectMapping discoveryPluginResultObjectMapping = new DiscoveryPluginResultObjectMapping();
			List<DiscoveryPluginResultBase> list = new List<DiscoveryPluginResultBase>();
			using (IEnumerator<DiscoveryPluginResultBase> enumerator = results.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					DiscoveryPluginResultBase item = enumerator.Current;
					DiscoveryPluginResultBase discoveryPluginResultBase = partialResultsToMerge.Except(list).FirstOrDefault((DiscoveryPluginResultBase x) => x.GetType() == item.GetType());
					if (discoveryPluginResultBase != null)
					{
						IDiscoveryPluginResultMerge discoveryPluginResultMerge = item as IDiscoveryPluginResultMerge;
						if (discoveryPluginResultMerge == null)
						{
							PartialDiscoveryResultsContainer._log.WarnFormat("Plugin discovery results '{0}' do not implement IDiscoveryPluginResultMerge interface and will not be merged with other results instances.", item.GetType());
						}
						else
						{
							discoveryPluginResultMerge.MergeResults(discoveryPluginResultBase, discoveryPluginResultObjectMapping, profileId);
							list.Add(discoveryPluginResultBase);
						}
					}
				}
			}
			foreach (DiscoveryPluginResultBase discoveryPluginResultBase2 in partialResultsToMerge.Except(list))
			{
				results.Add(discoveryPluginResultBase2);
			}
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x00026510 File Offset: 0x00024710
		private void RemovePartialResults(Guid mainResultId, IEnumerable<PartialDiscoveryResultsContainer.PartialResult> results)
		{
			object syncRoot = this._syncRoot;
			lock (syncRoot)
			{
				this._mainResultsReadyForComplete.Remove(mainResultId);
				this._resultsByMainJobId.Remove(mainResultId);
				foreach (PartialDiscoveryResultsContainer.PartialResult partialResult in results)
				{
					this._resultsByOwnJobId.Remove(partialResult.JobId);
					this._persistenceStore.DeleteResult(partialResult.JobId);
				}
			}
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x000265B8 File Offset: 0x000247B8
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x000265C8 File Offset: 0x000247C8
		protected void Dispose(bool disposing)
		{
			if (this._disposed)
			{
				return;
			}
			if (disposing)
			{
				try
				{
					if (this._expirationCleanupTimer != null)
					{
						this._expirationCleanupTimer.Dispose();
						this._expirationCleanupTimer = null;
					}
				}
				catch (Exception ex)
				{
					PartialDiscoveryResultsContainer._log.Error("Error diposing PartialDiscoveryResultsContainer.", ex);
				}
				this._disposed = true;
			}
		}

		// Token: 0x0600065E RID: 1630 RVA: 0x00026628 File Offset: 0x00024828
		~PartialDiscoveryResultsContainer()
		{
			this.Dispose(false);
		}

		// Token: 0x040001FF RID: 511
		private static readonly Log _log = new Log();

		// Token: 0x04000200 RID: 512
		private readonly object _syncRoot = new object();

		// Token: 0x04000201 RID: 513
		private readonly Dictionary<Guid, List<PartialDiscoveryResultsContainer.PartialResult>> _resultsByMainJobId;

		// Token: 0x04000202 RID: 514
		private readonly Dictionary<Guid, PartialDiscoveryResultsContainer.PartialResult> _resultsByOwnJobId;

		// Token: 0x04000203 RID: 515
		private readonly HashSet<Guid> _mainResultsReadyForComplete;

		// Token: 0x04000204 RID: 516
		private readonly IPartialDiscoveryResultsPersistence _persistenceStore;

		// Token: 0x04000205 RID: 517
		private readonly Func<DateTime> _dateTimeProvider;

		// Token: 0x04000206 RID: 518
		private Timer _expirationCleanupTimer;

		// Token: 0x04000207 RID: 519
		private bool _disposed;

		// Token: 0x02000172 RID: 370
		private class PartialResult
		{
			// Token: 0x06000BE7 RID: 3047 RVA: 0x0004AB58 File Offset: 0x00048D58
			public PartialResult(Guid jobId, Guid mainJobId, IPartialDiscoveryResultsPersistence persistenceStore, DateTime expiration) : this(jobId, mainJobId, null, 7, null, persistenceStore, expiration)
			{
			}

			// Token: 0x06000BE8 RID: 3048 RVA: 0x0004AB7C File Offset: 0x00048D7C
			public PartialResult(Guid jobId, Guid mainJobId, SortedDictionary<int, List<IDiscoveryPlugin>> orderedPlugins, JobState jobState, int? profileId, IPartialDiscoveryResultsPersistence persistenceStore, DateTime expiration)
			{
				if (persistenceStore == null)
				{
					throw new ArgumentNullException("persistenceStore");
				}
				this._persistenceStore = persistenceStore;
				this.JobId = jobId;
				this.MainJobId = mainJobId;
				this.OrderedPlugins = orderedPlugins;
				this.JobState = jobState;
				this.ProfileId = profileId;
				this.Expiration = expiration;
			}

			// Token: 0x17000151 RID: 337
			// (get) Token: 0x06000BE9 RID: 3049 RVA: 0x0004ABD3 File Offset: 0x00048DD3
			// (set) Token: 0x06000BEA RID: 3050 RVA: 0x0004ABDB File Offset: 0x00048DDB
			public Guid MainJobId { get; private set; }

			// Token: 0x17000152 RID: 338
			// (get) Token: 0x06000BEB RID: 3051 RVA: 0x0004ABE4 File Offset: 0x00048DE4
			// (set) Token: 0x06000BEC RID: 3052 RVA: 0x0004ABEC File Offset: 0x00048DEC
			public Guid JobId { get; private set; }

			// Token: 0x17000153 RID: 339
			// (get) Token: 0x06000BED RID: 3053 RVA: 0x0004ABF5 File Offset: 0x00048DF5
			// (set) Token: 0x06000BEE RID: 3054 RVA: 0x0004ABFD File Offset: 0x00048DFD
			public SortedDictionary<int, List<IDiscoveryPlugin>> OrderedPlugins { get; private set; }

			// Token: 0x17000154 RID: 340
			// (get) Token: 0x06000BEF RID: 3055 RVA: 0x0004AC06 File Offset: 0x00048E06
			// (set) Token: 0x06000BF0 RID: 3056 RVA: 0x0004AC0E File Offset: 0x00048E0E
			public JobState JobState { get; private set; }

			// Token: 0x17000155 RID: 341
			// (get) Token: 0x06000BF1 RID: 3057 RVA: 0x0004AC17 File Offset: 0x00048E17
			// (set) Token: 0x06000BF2 RID: 3058 RVA: 0x0004AC1F File Offset: 0x00048E1F
			public int? ProfileId { get; private set; }

			// Token: 0x17000156 RID: 342
			// (get) Token: 0x06000BF3 RID: 3059 RVA: 0x0004AC28 File Offset: 0x00048E28
			// (set) Token: 0x06000BF4 RID: 3060 RVA: 0x0004AC30 File Offset: 0x00048E30
			public bool HasResult { get; private set; }

			// Token: 0x17000157 RID: 343
			// (get) Token: 0x06000BF5 RID: 3061 RVA: 0x0004AC39 File Offset: 0x00048E39
			// (set) Token: 0x06000BF6 RID: 3062 RVA: 0x0004AC41 File Offset: 0x00048E41
			public DateTime Expiration { get; private set; }

			// Token: 0x17000158 RID: 344
			// (get) Token: 0x06000BF7 RID: 3063 RVA: 0x0004AC4A File Offset: 0x00048E4A
			// (set) Token: 0x06000BF8 RID: 3064 RVA: 0x0004AC76 File Offset: 0x00048E76
			public OrionDiscoveryJobResult Result
			{
				get
				{
					if (!this.HasResult)
					{
						return null;
					}
					if (this._result != null)
					{
						return this._result;
					}
					return this._persistenceStore.LoadResult(this.JobId);
				}
				set
				{
					if (!this._persistenceStore.SaveResult(this.JobId, value))
					{
						this._result = value;
					}
					this.HasResult = true;
				}
			}

			// Token: 0x040004A4 RID: 1188
			private readonly IPartialDiscoveryResultsPersistence _persistenceStore;

			// Token: 0x040004A5 RID: 1189
			private OrionDiscoveryJobResult _result;
		}
	}
}
