﻿using System;
using System.Collections.Generic;
using SolarWinds.JobEngine;
using SolarWinds.Orion.Discovery.Contract.DiscoveryPlugin;
using SolarWinds.Orion.Discovery.Job;

namespace SolarWinds.Orion.Core.BusinessLayer.Discovery
{
	// Token: 0x0200007E RID: 126
	public class DiscoveryResultsCompletedEventArgs : EventArgs
	{
		// Token: 0x0600063B RID: 1595 RVA: 0x00025C23 File Offset: 0x00023E23
		public DiscoveryResultsCompletedEventArgs(OrionDiscoveryJobResult completeResult, SortedDictionary<int, List<IDiscoveryPlugin>> orderedPlugins, Guid scheduledJobId, JobState jobState, int? profileId)
		{
			this.CompleteResult = completeResult;
			this.OrderedPlugins = orderedPlugins;
			this.ScheduledJobId = scheduledJobId;
			this.JobState = jobState;
			this.ProfileId = profileId;
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600063C RID: 1596 RVA: 0x00025C50 File Offset: 0x00023E50
		// (set) Token: 0x0600063D RID: 1597 RVA: 0x00025C58 File Offset: 0x00023E58
		public OrionDiscoveryJobResult CompleteResult { get; private set; }

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600063E RID: 1598 RVA: 0x00025C61 File Offset: 0x00023E61
		// (set) Token: 0x0600063F RID: 1599 RVA: 0x00025C69 File Offset: 0x00023E69
		public SortedDictionary<int, List<IDiscoveryPlugin>> OrderedPlugins { get; private set; }

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000640 RID: 1600 RVA: 0x00025C72 File Offset: 0x00023E72
		// (set) Token: 0x06000641 RID: 1601 RVA: 0x00025C7A File Offset: 0x00023E7A
		public Guid ScheduledJobId { get; private set; }

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000642 RID: 1602 RVA: 0x00025C83 File Offset: 0x00023E83
		// (set) Token: 0x06000643 RID: 1603 RVA: 0x00025C8B File Offset: 0x00023E8B
		public JobState JobState { get; private set; }

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000644 RID: 1604 RVA: 0x00025C94 File Offset: 0x00023E94
		// (set) Token: 0x06000645 RID: 1605 RVA: 0x00025C9C File Offset: 0x00023E9C
		public int? ProfileId { get; private set; }
	}
}
