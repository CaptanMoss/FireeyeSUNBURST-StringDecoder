﻿using System;
using SolarWinds.Orion.Discovery.Job;

namespace SolarWinds.Orion.Core.BusinessLayer.Discovery
{
	// Token: 0x0200007F RID: 127
	public interface IPartialDiscoveryResultsPersistence
	{
		// Token: 0x06000646 RID: 1606
		bool SaveResult(Guid jobId, OrionDiscoveryJobResult result);

		// Token: 0x06000647 RID: 1607
		OrionDiscoveryJobResult LoadResult(Guid jobId);

		// Token: 0x06000648 RID: 1608
		void DeleteResult(Guid jobId);

		// Token: 0x06000649 RID: 1609
		void ClearStore();
	}
}
