﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000011 RID: 17
	public interface IServiceStateProvider
	{
		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000288 RID: 648
		bool IsServiceDown { get; }
	}
}
