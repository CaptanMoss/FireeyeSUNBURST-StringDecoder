﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.PubSub;

namespace SolarWinds.Orion.Core.BusinessLayer.NodeStatus
{
	// Token: 0x02000070 RID: 112
	public class EnhancedNodeStatusCalculationSubscriber : ISubscriber, IDisposable
	{
		// Token: 0x060005C8 RID: 1480 RVA: 0x00022E7D File Offset: 0x0002107D
		public EnhancedNodeStatusCalculationSubscriber(ISubscriptionManager subscriptionManager, ISqlHelper sqlHelper)
		{
			if (subscriptionManager == null)
			{
				throw new ArgumentNullException("subscriptionManager");
			}
			this.subscriptionManager = subscriptionManager;
			if (sqlHelper == null)
			{
				throw new ArgumentNullException("sqlHelper");
			}
			this.sqlHelper = sqlHelper;
		}

		// Token: 0x060005C9 RID: 1481 RVA: 0x00022EB4 File Offset: 0x000210B4
		public async Task OnNotificationAsync(Notification notification)
		{
			if (this.subscription != null && !(((notification != null) ? notification.SubscriptionId.UniqueName : null) != EnhancedNodeStatusCalculationSubscriber.SubscriptionUniqueName))
			{
				if (notification.SourceInstanceProperties == null)
				{
					EnhancedNodeStatusCalculationSubscriber.log.Error("Argument SourceInstanceProperties is null.");
				}
				else if (!notification.SourceInstanceProperties.ContainsKey("CurrentValue"))
				{
					EnhancedNodeStatusCalculationSubscriber.log.Error("CurrentValue not supplied in SourceInstanceProperties.");
				}
				else
				{
					try
					{
						bool flag = Convert.ToInt32(notification.SourceInstanceProperties["CurrentValue"]) == 1;
						EnhancedNodeStatusCalculationSubscriber.log.DebugFormat("Node status calculation changed to '{0} calculation', re-calculating node status ..", flag ? "Enhanced" : "Classic");
						await Task.Run(delegate()
						{
							this.RecalculateNodeStatus();
						});
					}
					catch (Exception ex)
					{
						EnhancedNodeStatusCalculationSubscriber.log.Error("Indication handling failed", ex);
					}
				}
			}
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x00022F04 File Offset: 0x00021104
		public EnhancedNodeStatusCalculationSubscriber Start()
		{
			EnhancedNodeStatusCalculationSubscriber.log.Debug("Subscribing EnhancedNodeStatusCalculation changed indications..");
			try
			{
				if (this.subscription != null)
				{
					EnhancedNodeStatusCalculationSubscriber.log.Debug("Already subscribed, unsubscribing first..");
					this.Unsubscribe(this.subscription.Id);
				}
				SubscriptionId subscriptionId;
				subscriptionId..ctor("Core", EnhancedNodeStatusCalculationSubscriber.SubscriptionUniqueName, 0);
				this.subscription = this.subscriptionManager.Subscribe(subscriptionId, this, new SubscriberConfiguration
				{
					SubscriptionQuery = EnhancedNodeStatusCalculationSubscriber.SubscriptionQuery,
					ReliableDelivery = true,
					AcknowledgeMode = 0,
					MessageTimeToLive = TimeSpan.Zero
				});
			}
			catch (Exception ex)
			{
				EnhancedNodeStatusCalculationSubscriber.log.Error("Failed to subscribe.", ex);
				throw;
			}
			return this;
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x00022FC0 File Offset: 0x000211C0
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x00022FD0 File Offset: 0x000211D0
		protected void Dispose(bool disposing)
		{
			if (this.subscription != null)
			{
				try
				{
					EnhancedNodeStatusCalculationSubscriber.log.Debug("Unsubscribing EnhancedNodeStatusCalculation changed indications..");
					this.Unsubscribe(this.subscription.Id);
					this.subscription = null;
				}
				catch (Exception ex)
				{
					EnhancedNodeStatusCalculationSubscriber.log.Error("Error unsubscribing subscription.", ex);
				}
			}
		}

		// Token: 0x060005CD RID: 1485 RVA: 0x00023034 File Offset: 0x00021234
		private void Unsubscribe(SubscriptionId subscriptionId)
		{
			this.subscriptionManager.Unsubscribe(subscriptionId);
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x00023044 File Offset: 0x00021244
		private void RecalculateNodeStatus()
		{
			string text = "EXEC dbo.[swsp_ReflowAllNodeChildStatus]";
			using (SqlCommand textCommand = this.sqlHelper.GetTextCommand(text))
			{
				this.sqlHelper.ExecuteNonQuery(textCommand);
			}
		}

		// Token: 0x040001B9 RID: 441
		public static string SubscriptionUniqueName = "EnhancedNodeStatusCalculation";

		// Token: 0x040001BA RID: 442
		private static string SubscriptionQuery = "SUBSCRIBE CHANGES TO Orion.Settings WHEN SettingsID = 'EnhancedNodeStatusCalculation'";

		// Token: 0x040001BB RID: 443
		private static readonly Log log = new Log();

		// Token: 0x040001BC RID: 444
		private readonly ISubscriptionManager subscriptionManager;

		// Token: 0x040001BD RID: 445
		private readonly ISqlHelper sqlHelper;

		// Token: 0x040001BE RID: 446
		private ISubscription subscription;
	}
}
