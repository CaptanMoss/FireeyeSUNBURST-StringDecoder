﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Serialization;
using SolarWinds.InformationService.Contract2;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Indications;

namespace SolarWinds.Orion.Core.BusinessLayer.NodeStatus
{
	// Token: 0x02000071 RID: 113
	public class EnhancedNodeStatusIndicator
	{
		// Token: 0x060005D1 RID: 1489 RVA: 0x000230B8 File Offset: 0x000212B8
		public EnhancedNodeStatusIndicator(ISqlHelper sqlHelper, IIndicationReporterPublisher ip)
		{
			this.sqlHelper = sqlHelper;
			this.ip = ip;
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x000230CE File Offset: 0x000212CE
		public void Execute()
		{
			this.ProcessIndications(this.ReadFromDB());
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x000230DC File Offset: 0x000212DC
		private List<EnhancedNodeStatusIndicator.IndicationInfo> ReadFromDB()
		{
			List<EnhancedNodeStatusIndicator.IndicationInfo> list = new List<EnhancedNodeStatusIndicator.IndicationInfo>();
			using (SqlCommand textCommand = this.sqlHelper.GetTextCommand(EnhancedNodeStatusIndicator.SelectNodeStatusQuery))
			{
				using (IDataReader dataReader = this.sqlHelper.ExecuteReader(textCommand))
				{
					try
					{
						while (dataReader.Read())
						{
							int @int = dataReader.GetInt32(0);
							string @string = dataReader.GetString(1);
							list.Add(new EnhancedNodeStatusIndicator.IndicationInfo
							{
								Id = @int,
								Data = @string
							});
							EnhancedNodeStatusIndicator.log.Debug(string.Format("Reading new indication info from DB ({0},{1})", @int, @string));
						}
					}
					catch (Exception ex)
					{
						EnhancedNodeStatusIndicator.log.Warn("Reading indication data failed", ex);
					}
				}
			}
			return list;
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x000231B4 File Offset: 0x000213B4
		private void DeleteIndicationFromDB(EnhancedNodeStatusIndicator.IndicationInfo record)
		{
			try
			{
				SqlCommand textCommand = this.sqlHelper.GetTextCommand(EnhancedNodeStatusIndicator.DeleteNodeStatusQuery);
				textCommand.Parameters.Add(new SqlParameter("id", record.Id));
				this.sqlHelper.ExecuteNonQuery(textCommand);
			}
			catch (Exception ex)
			{
				EnhancedNodeStatusIndicator.log.Error("Deleting from indication table failed", ex);
			}
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00023228 File Offset: 0x00021428
		internal void ProcessIndications(IEnumerable<EnhancedNodeStatusIndicator.IndicationInfo> indications)
		{
			foreach (EnhancedNodeStatusIndicator.IndicationInfo indicationInfo in indications)
			{
				try
				{
					EnhancedNodeStatusIndicator.NodeStatusIndication nodeStatusIndication = (EnhancedNodeStatusIndicator.NodeStatusIndication)OrionSerializationHelper.FromJSON(indicationInfo.Data, typeof(EnhancedNodeStatusIndicator.NodeStatusIndication));
					PropertyBag propertyBag = new PropertyBag();
					propertyBag["PreviousStatus"] = nodeStatusIndication.PreviousStatus;
					PropertyBag propertyBag2 = new PropertyBag();
					propertyBag2["NodeID"] = nodeStatusIndication.NodeID;
					propertyBag2["Status"] = nodeStatusIndication.Status;
					propertyBag2["InstanceType"] = "Orion.Nodes";
					propertyBag2["PreviousProperties"] = propertyBag;
					this.ip.ReportIndication(IndicationHelper.GetIndicationType(2), IndicationHelper.GetIndicationProperties(), propertyBag2);
					this.DeleteIndicationFromDB(indicationInfo);
					EnhancedNodeStatusIndicator.log.Debug("Enhanced node status indication processed " + string.Format("(N:{0} [{1}]->[{2}])", nodeStatusIndication.NodeID, nodeStatusIndication.PreviousStatus, nodeStatusIndication.Status));
				}
				catch (Exception ex)
				{
					EnhancedNodeStatusIndicator.log.Error("Indication processing failed", ex);
				}
			}
		}

		// Token: 0x040001BF RID: 447
		private static string SelectNodeStatusQuery = "SELECT TOP 1000 [ID], [Data]FROM [DatabaseIndicationQueue] WHERE [Owner] = 'Core.Status' ORDER BY ID";

		// Token: 0x040001C0 RID: 448
		private static string DeleteNodeStatusQuery = "DELETE FROM [DatabaseIndicationQueue] WHERE ID=@id";

		// Token: 0x040001C1 RID: 449
		private static readonly Log log = new Log();

		// Token: 0x040001C2 RID: 450
		private readonly ISqlHelper sqlHelper;

		// Token: 0x040001C3 RID: 451
		private readonly IIndicationReporterPublisher ip;

		// Token: 0x02000165 RID: 357
		internal class IndicationInfo
		{
			// Token: 0x1700014C RID: 332
			// (get) Token: 0x06000BB5 RID: 2997 RVA: 0x0004A6C2 File Offset: 0x000488C2
			// (set) Token: 0x06000BB6 RID: 2998 RVA: 0x0004A6CA File Offset: 0x000488CA
			public int Id { get; set; }

			// Token: 0x1700014D RID: 333
			// (get) Token: 0x06000BB7 RID: 2999 RVA: 0x0004A6D3 File Offset: 0x000488D3
			// (set) Token: 0x06000BB8 RID: 3000 RVA: 0x0004A6DB File Offset: 0x000488DB
			public string Data { get; set; }
		}

		// Token: 0x02000166 RID: 358
		[DataContract]
		internal class NodeStatusIndication
		{
			// Token: 0x1700014E RID: 334
			// (get) Token: 0x06000BBA RID: 3002 RVA: 0x0004A6E4 File Offset: 0x000488E4
			// (set) Token: 0x06000BBB RID: 3003 RVA: 0x0004A6EC File Offset: 0x000488EC
			[DataMember]
			public int NodeID { get; set; }

			// Token: 0x1700014F RID: 335
			// (get) Token: 0x06000BBC RID: 3004 RVA: 0x0004A6F5 File Offset: 0x000488F5
			// (set) Token: 0x06000BBD RID: 3005 RVA: 0x0004A6FD File Offset: 0x000488FD
			[DataMember]
			public int Status { get; set; }

			// Token: 0x17000150 RID: 336
			// (get) Token: 0x06000BBE RID: 3006 RVA: 0x0004A706 File Offset: 0x00048906
			// (set) Token: 0x06000BBF RID: 3007 RVA: 0x0004A70E File Offset: 0x0004890E
			[DataMember]
			public int PreviousStatus { get; set; }
		}
	}
}
