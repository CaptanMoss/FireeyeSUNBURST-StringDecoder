﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.BusinessLayer.DAL;
using SolarWinds.Orion.Core.Common.Indications;
using SolarWinds.Orion.Core.Common.InformationService;
using SolarWinds.Orion.Core.Models.MaintenanceMode;
using SolarWinds.Orion.PubSub;
using SolarWinds.Orion.Swis.PubSub.InformationService;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintenanceMode
{
	// Token: 0x02000069 RID: 105
	internal class MaintenanceIndicationSubscriber : ISubscriber, IDisposable
	{
		// Token: 0x06000590 RID: 1424 RVA: 0x00022110 File Offset: 0x00020310
		public MaintenanceIndicationSubscriber() : this(new MaintenanceManager(InformationServiceProxyPoolCreatorFactory.GetSystemCreator(), new MaintenanceModePlanDAL()), SubscriptionManager.Instance)
		{
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x0002212C File Offset: 0x0002032C
		public MaintenanceIndicationSubscriber(IMaintenanceManager manager, ISubscriptionManager subscriptionManager)
		{
			this.manager = manager;
			this._subscriptionManager = subscriptionManager;
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x00022144 File Offset: 0x00020344
		public void Start()
		{
			try
			{
				this._subscriptionId = this.Subscribe();
			}
			catch (Exception ex)
			{
				MaintenanceIndicationSubscriber.log.ErrorFormat("Unable to start maintenance mode service. Unmanage functionality may be affected. {0}", ex);
				throw;
			}
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x00022184 File Offset: 0x00020384
		internal MaintenancePlanAssignment CreateAssignment(IDictionary<string, object> sourceInstanceProperties)
		{
			if (sourceInstanceProperties == null)
			{
				throw new ArgumentNullException("sourceInstanceProperties");
			}
			if (!sourceInstanceProperties.Keys.Any<string>())
			{
				throw new ArgumentException("sourceInstanceProperties");
			}
			return new MaintenancePlanAssignment
			{
				ID = Convert.ToInt32(sourceInstanceProperties["ID"]),
				EntityType = Convert.ToString(sourceInstanceProperties["EntityType"]),
				EntityID = Convert.ToInt32(sourceInstanceProperties["EntityID"]),
				MaintenancePlanID = Convert.ToInt32(sourceInstanceProperties["MaintenancePlanID"])
			};
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x00022214 File Offset: 0x00020414
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x00022224 File Offset: 0x00020424
		protected void Dispose(bool disposing)
		{
			if (this._subscriptionId == null)
			{
				return;
			}
			try
			{
				this.Unsubscribe(this._subscriptionId);
				this._subscriptionId = null;
			}
			catch (Exception ex)
			{
				MaintenanceIndicationSubscriber.log.ErrorFormat("Error unsubscribing subscription '{0}'. {1}", this._subscriptionId, ex);
			}
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x0002227C File Offset: 0x0002047C
		private ISubscription Subscribe()
		{
			SubscriptionId subscriptionId;
			subscriptionId..ctor("Core", typeof(MaintenanceIndicationSubscriber).FullName, 0);
			SubscriberConfiguration subscriberConfiguration = new SubscriberConfiguration
			{
				SubscriptionQuery = "SUBSCRIBE CHANGES TO Orion.MaintenancePlanAssignment"
			};
			return this._subscriptionManager.Subscribe(subscriptionId, this, subscriberConfiguration);
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x000222C4 File Offset: 0x000204C4
		private void Unsubscribe(ISubscription subscriptionId)
		{
			this._subscriptionManager.Unsubscribe(subscriptionId.Id);
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x000222D8 File Offset: 0x000204D8
		~MaintenanceIndicationSubscriber()
		{
			this.Dispose(false);
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00022308 File Offset: 0x00020508
		public Task OnNotificationAsync(Notification notification)
		{
			if (!this._subscriptionId.Id.Equals(notification.SubscriptionId))
			{
				return Task.CompletedTask;
			}
			MaintenanceIndicationSubscriber.log.DebugFormat("Received maintenance mode indication '{0}'.", notification.IndicationType);
			MaintenanceIndicationSubscriber.log.DebugFormat("Indication Properties: {0}", notification.IndicationProperties);
			MaintenanceIndicationSubscriber.log.DebugFormat("Source Instance Properties: {0}", notification.SourceInstanceProperties);
			try
			{
				MaintenancePlanAssignment assignment = this.CreateAssignment(notification.SourceInstanceProperties);
				if (IndicationHelper.GetIndicationType(0).Equals(notification.IndicationType))
				{
					this.manager.Unmanage(assignment);
				}
				else if (IndicationHelper.GetIndicationType(1).Equals(notification.IndicationType))
				{
					this.manager.Remanage(assignment);
				}
				else
				{
					IndicationHelper.GetIndicationType(2).Equals(notification.IndicationType);
				}
			}
			catch (Exception ex)
			{
				MaintenanceIndicationSubscriber.log.ErrorFormat("Unable to process maintenance mode indication. {0}", ex);
				throw;
			}
			return Task.CompletedTask;
		}

		// Token: 0x040001A2 RID: 418
		private static readonly Log log = new Log();

		// Token: 0x040001A3 RID: 419
		private readonly IMaintenanceManager manager;

		// Token: 0x040001A4 RID: 420
		private readonly ISubscriptionManager _subscriptionManager;

		// Token: 0x040001A5 RID: 421
		private ISubscription _subscriptionId;

		// Token: 0x040001A6 RID: 422
		private const string SubscriptionQuery = "SUBSCRIBE CHANGES TO Orion.MaintenancePlanAssignment";
	}
}
