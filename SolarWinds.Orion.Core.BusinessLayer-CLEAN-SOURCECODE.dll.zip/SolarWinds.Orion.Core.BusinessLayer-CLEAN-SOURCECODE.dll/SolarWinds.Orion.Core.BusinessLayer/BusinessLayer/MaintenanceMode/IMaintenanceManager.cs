﻿using System;
using SolarWinds.Orion.Core.Models.MaintenanceMode;

namespace SolarWinds.Orion.Core.BusinessLayer.MaintenanceMode
{
	// Token: 0x02000067 RID: 103
	public interface IMaintenanceManager
	{
		// Token: 0x06000589 RID: 1417
		void Unmanage(MaintenancePlanAssignment assignment);

		// Token: 0x0600058A RID: 1418
		void Remanage(MaintenancePlanAssignment assignment);
	}
}
