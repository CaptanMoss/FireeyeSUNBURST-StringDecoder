﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using SolarWinds.Common.Utility;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Indications;
using SolarWinds.Orion.Core.Common.InformationService;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Common.Swis;
using SolarWinds.Orion.PubSub;
using SolarWinds.Orion.Swis.PubSub.InformationService;

namespace SolarWinds.Orion.Core.BusinessLayer.DowntimeMonitoring
{
	// Token: 0x0200007B RID: 123
	public class DowntimeMonitoringNotificationSubscriber : ISubscriber
	{
		// Token: 0x170000EB RID: 235
		// (set) Token: 0x0600060F RID: 1551 RVA: 0x000244F2 File Offset: 0x000226F2
		internal Lazy<ILookup<string, NetObjectTypeEx>> NetObjectTypes
		{
			set
			{
				this._netObjectTypes = value;
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000610 RID: 1552 RVA: 0x000244FB File Offset: 0x000226FB
		private static bool IsEnabled
		{
			get
			{
				return SettingsDAL.GetCurrent<bool>("SWNetPerfMon-Settings-EnableDowntimeMonitoring", true);
			}
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x00024508 File Offset: 0x00022708
		public DowntimeMonitoringNotificationSubscriber(INetObjectDowntimeDAL netObjectDowntimeDal) : this(netObjectDowntimeDal, SwisConnectionProxyPool.GetSystemCreator(), new SwisUriParser(), SubscriptionManager.Instance)
		{
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x00024520 File Offset: 0x00022720
		internal DowntimeMonitoringNotificationSubscriber(INetObjectDowntimeDAL netObjectDowntimeDal, IInformationServiceProxyCreator serviceProxyCreator, ISwisUriParser swisUriParser, ISubscriptionManager subscriptionManager)
		{
			if (netObjectDowntimeDal == null)
			{
				throw new ArgumentNullException("netObjectDowntimeDal");
			}
			this._netObjectDowntimeDal = netObjectDowntimeDal;
			if (serviceProxyCreator == null)
			{
				throw new ArgumentNullException("serviceProxyCreator");
			}
			this._swisServiceProxyCreator = serviceProxyCreator;
			if (swisUriParser == null)
			{
				throw new ArgumentNullException("swisUriParser");
			}
			this._swisUriParser = swisUriParser;
			this._nodeNetObjectIdColumn = null;
			this._netObjectTypes = new Lazy<ILookup<string, NetObjectTypeEx>>(new Func<ILookup<string, NetObjectTypeEx>>(this.LoadNetObjectTypesExtSwisInfo), LazyThreadSafetyMode.PublicationOnly);
			if (subscriptionManager == null)
			{
				throw new ArgumentNullException("subscriptionManager");
			}
			this._subscriptionManager = subscriptionManager;
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x000245B6 File Offset: 0x000227B6
		internal int ExtractStatusID(object statusObject)
		{
			return Convert.ToInt32(statusObject);
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x000245C0 File Offset: 0x000227C0
		public virtual void Start()
		{
			if (!DowntimeMonitoringNotificationSubscriber.IsEnabled)
			{
				DowntimeMonitoringNotificationSubscriber.log.Info("Subscription of Downtime Monitoring cancelled (disabled by Settings option)");
				this.Stop();
				return;
			}
			Scheduler.Instance.Add(new ScheduledTask("NetObjectDowntimeInitializator", new TimerCallback(this.Initialize), null, TimeSpan.FromSeconds(1.0), TimeSpan.FromMinutes(1.0)));
			Scheduler.Instance.Add(new ScheduledTask("NetObjectDowntimeIndication", new TimerCallback(this.Subscribe), null, TimeSpan.FromSeconds(1.0), TimeSpan.FromMinutes(1.0)));
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x00024664 File Offset: 0x00022864
		private void Initialize(object state)
		{
			List<NetObjectDowntime> list = new List<NetObjectDowntime>();
			try
			{
				using (IInformationServiceProxy2 informationServiceProxy = this._swisServiceProxyCreator.Create())
				{
					DateTime utcNow = DateTime.UtcNow;
					foreach (object obj in informationServiceProxy.Query("SELECT Uri, Status, InstanceType, AncestorDetailsUrls\n                                            FROM System.ManagedEntity\n                                            WHERE UnManaged = false").Rows)
					{
						DataRow dataRow = (DataRow)obj;
						try
						{
							if (this.IsValid(dataRow))
							{
								list.Add(new NetObjectDowntime
								{
									DateTimeFrom = utcNow,
									EntityID = this._swisUriParser.GetEntityId(dataRow["Uri"].ToString()),
									NodeID = this.ExtractStatusID(this.GetNodeIDFromUrl((string[])dataRow["AncestorDetailsUrls"])),
									EntityType = dataRow["InstanceType"].ToString(),
									StatusID = (int)dataRow["Status"]
								});
							}
						}
						catch (Exception arg)
						{
							DowntimeMonitoringNotificationSubscriber.log.Error(string.Format("Unable to create NetObjectDowntime instance from ManagedEntity with Uri '{0}', {1}", dataRow["Uri"], arg));
						}
					}
				}
			}
			catch (Exception ex)
			{
				DowntimeMonitoringNotificationSubscriber.log.ErrorFormat("Exception while initializing NetObjectDowntime table with ManagedEntities. {0}", ex);
			}
			this._netObjectDowntimeDal.Insert(list);
			Scheduler.Instance.Remove("NetObjectDowntimeInitializator");
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x00024830 File Offset: 0x00022A30
		private bool IsValid(DataRow row)
		{
			bool result;
			try
			{
				this.GetNodeIDFromUrl((string[])row["AncestorDetailsUrls"]);
				result = !row.IsNull("Uri");
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x0002487C File Offset: 0x00022A7C
		public virtual void Stop()
		{
			this.Unsubscribe();
			Scheduler.Instance.Remove("NetObjectDowntimeIndication");
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x00024894 File Offset: 0x00022A94
		private void Unsubscribe()
		{
			if (this.subscriptionIds.Count == 0)
			{
				return;
			}
			try
			{
				foreach (SubscriptionId subscriptionId in this.subscriptionIds)
				{
					this._subscriptionManager.Unsubscribe(subscriptionId);
				}
				this.subscriptionIds.Clear();
			}
			catch (Exception ex)
			{
				DowntimeMonitoringNotificationSubscriber.log.ErrorFormat("Unsubscribe failed: '{0}'", ex);
				throw;
			}
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x00024928 File Offset: 0x00022B28
		private void Subscribe(object state)
		{
			DowntimeMonitoringNotificationSubscriber.log.Debug("Subscribing Managed Entity changed indications..");
			try
			{
				try
				{
					this.DeleteOldSubscriptions();
				}
				catch (Exception ex)
				{
					DowntimeMonitoringNotificationSubscriber.log.Warn("Exception deleting old subscriptions:", ex);
				}
				if (this.subscriptionIds.Count > 0)
				{
					this.Unsubscribe();
				}
				foreach (Tuple<string, string> tuple in new Tuple<string, string>[]
				{
					new Tuple<string, string>("SUBSCRIBE System.InstanceDeleted WHEN InstanceType ISA 'System.ManagedEntity' OR SourceInstanceType ISA 'System.ManagedEntity'", "ManagedEntityDeleted"),
					new Tuple<string, string>("SUBSCRIBE System.InstanceCreated WHEN InstanceType ISA 'System.ManagedEntity' OR SourceInstanceType ISA 'System.ManagedEntity'", "ManagedEntityCreated"),
					new Tuple<string, string>("SUBSCRIBE CHANGES TO System.ManagedEntity WHEN Status CHANGES", "ManagedEntityStatusChanges")
				})
				{
					SubscriptionId subscriptionId;
					subscriptionId..ctor("Core", typeof(DowntimeMonitoringNotificationSubscriber).FullName + "." + tuple.Item2, 0);
					SubscriberConfiguration subscriberConfiguration = new SubscriberConfiguration
					{
						SubscriptionQuery = tuple.Item1
					};
					ISubscription subscription = this._subscriptionManager.Subscribe(subscriptionId, this, subscriberConfiguration);
					this.subscriptionIds.Add(subscription.Id);
					DowntimeMonitoringNotificationSubscriber.log.InfoFormat("Pub/sub subscription succeeded. uri:'{0}'", subscription.Id);
				}
				Scheduler.Instance.Remove("NetObjectDowntimeIndication");
			}
			catch (Exception ex2)
			{
				DowntimeMonitoringNotificationSubscriber.log.ErrorFormat("{0} in Subscribe: {1}\r\n{2}", ex2.GetType(), ex2.Message, ex2.StackTrace);
			}
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x00024AB4 File Offset: 0x00022CB4
		private string DetailInfo(SubscriptionId subscriptionId, string indicationType, IDictionary<string, object> indicationProperties, IDictionary<string, object> sourceInstanceProperties)
		{
			string format = "Pub/Sub Notification: ID: {0}, Type: {1}, IndicationProperties: {2}, InstanceProperties: {3}";
			object[] array = new object[4];
			array[0] = subscriptionId;
			array[1] = indicationType;
			array[2] = string.Join(", ", from kvp in indicationProperties
			select string.Format("{0} = {1}", kvp.Key, kvp.Value));
			int num = 3;
			object obj;
			if (sourceInstanceProperties.Count <= 0)
			{
				obj = string.Empty;
			}
			else
			{
				obj = string.Join(", ", from kvp in sourceInstanceProperties
				select string.Format("{0} = {1}", kvp.Key, kvp.Value));
			}
			array[num] = obj;
			return string.Format(format, array);
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x00024B54 File Offset: 0x00022D54
		internal string GetNodeIDFromUrl(string[] urls)
		{
			foreach (string input in urls)
			{
				Match match = DowntimeMonitoringNotificationSubscriber.NodeIdRegex.Match(input);
				if (match.Success)
				{
					return NetObjectHelper.GetObjectID(match.Value);
				}
			}
			throw new ArgumentException(string.Format("Cannot parse NodeId from AncestorUrl. Urls: {0}.", string.Join(",", urls)), "urls");
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x00024BB4 File Offset: 0x00022DB4
		internal string GetNetObjectIdColumnForSwisEntity(string instanceType)
		{
			string result = null;
			if (this._netObjectTypes == null || this._netObjectTypes.Value == null)
			{
				return null;
			}
			NetObjectTypeEx netObjectTypeEx = this._netObjectTypes.Value[instanceType].FirstOrDefault((NetObjectTypeEx n) => n.KeyPropertyIndex == 0);
			if (netObjectTypeEx != null)
			{
				result = netObjectTypeEx.KeyProperty;
			}
			return result;
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x00024C1C File Offset: 0x00022E1C
		private ILookup<string, NetObjectTypeEx> LoadNetObjectTypesExtSwisInfo()
		{
			ILookup<string, NetObjectTypeEx> result;
			using (IInformationServiceProxy2 informationServiceProxy = this._swisServiceProxyCreator.Create())
			{
				result = (from DataRow row in informationServiceProxy.Query("SELECT EntityType, Name, Prefix, KeyProperty, NameProperty, KeyPropertyIndex, CanConvert FROM Orion.NetObjectTypesExt").Rows
				select new NetObjectTypeEx(row.Field("EntityType"), row.Field("Name"), row.Field("Prefix"), row.Field("KeyProperty"), row.Field("NameProperty"), (int)row.Field("CanConvert"), row.Field("KeyPropertyIndex"))).ToLookup((NetObjectTypeEx k) => k.EntityType);
			}
			return result;
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x00024CB0 File Offset: 0x00022EB0
		private void DeleteOldSubscriptions()
		{
			using (IInformationServiceProxy2 informationServiceProxy = this._swisServiceProxyCreator.Create())
			{
				string text = "SELECT Uri FROM System.Subscription WHERE description = @description";
				foreach (DataRow dataRow in informationServiceProxy.Query(text, new Dictionary<string, object>
				{
					{
						"description",
						"NetObjectDowntimeIndication"
					}
				}).Rows.Cast<DataRow>())
				{
					informationServiceProxy.Delete(dataRow[0].ToString());
				}
			}
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x00024D50 File Offset: 0x00022F50
		public Task OnNotificationAsync(Notification notification)
		{
			Stopwatch stopwatch = new Stopwatch();
			try
			{
				stopwatch.Start();
				if (notification.SourceInstanceProperties == null)
				{
					throw new ArgumentNullException("sourceInstanceProperties");
				}
				if (DowntimeMonitoringNotificationSubscriber.log.IsDebugEnabled)
				{
					DowntimeMonitoringNotificationSubscriber.log.Debug(this.DetailInfo(notification.SubscriptionId, notification.IndicationType, notification.IndicationProperties, notification.SourceInstanceProperties));
				}
				object obj = null;
				notification.SourceInstanceProperties.TryGetValue("InstanceType", out obj);
				if (obj == null)
				{
					notification.SourceInstanceProperties.TryGetValue("SourceInstanceType", out obj);
				}
				string text = obj as string;
				if (text == null)
				{
					DowntimeMonitoringNotificationSubscriber.log.Error("Wrong PropertyBag data. InstanceType or SourceInstanceType are null");
					return Task.CompletedTask;
				}
				string netObjectIdColumnForSwisEntity = this.GetNetObjectIdColumnForSwisEntity(text);
				if (netObjectIdColumnForSwisEntity == null)
				{
					DowntimeMonitoringNotificationSubscriber.log.DebugFormat("Not a supported instance type: {0}", text);
					return Task.CompletedTask;
				}
				object obj2;
				if (!notification.SourceInstanceProperties.TryGetValue(netObjectIdColumnForSwisEntity, out obj2))
				{
					DowntimeMonitoringNotificationSubscriber.log.DebugFormat("Unable to get Entity ID. InstanceType : {0}, ID Field: {1}", text, netObjectIdColumnForSwisEntity);
					return Task.CompletedTask;
				}
				if (notification.IndicationType == IndicationHelper.GetIndicationType(2) || notification.IndicationType == IndicationHelper.GetIndicationType(0))
				{
					object obj3;
					notification.SourceInstanceProperties.TryGetValue("Status", out obj3);
					if (obj3 == null)
					{
						DowntimeMonitoringNotificationSubscriber.log.DebugFormat("No Status reported for InstanceType : {0}", text);
						return Task.CompletedTask;
					}
					if (this._nodeNetObjectIdColumn == null)
					{
						this._nodeNetObjectIdColumn = this.GetNetObjectIdColumnForSwisEntity("Orion.Nodes");
					}
					object obj4;
					notification.SourceInstanceProperties.TryGetValue(this._nodeNetObjectIdColumn, out obj4);
					if (obj4 == null)
					{
						DowntimeMonitoringNotificationSubscriber.log.DebugFormat("SourceBag must include NodeId. InstanceType : {0}", text);
						return Task.CompletedTask;
					}
					this._netObjectDowntimeDal.Insert(new NetObjectDowntime
					{
						EntityID = obj2.ToString(),
						NodeID = this.ExtractStatusID(obj4),
						EntityType = text,
						DateTimeFrom = (DateTime)notification.IndicationProperties[IndicationConstants.IndicationTime],
						StatusID = this.ExtractStatusID(obj3)
					});
				}
				else if (notification.IndicationType == IndicationHelper.GetIndicationType(1))
				{
					this._netObjectDowntimeDal.DeleteDowntimeObjects(obj2.ToString(), text);
				}
			}
			catch (Exception ex)
			{
				DowntimeMonitoringNotificationSubscriber.log.Error(string.Format("Exception occured when processing incoming indication of type \"{0}\"", notification.IndicationType), ex);
			}
			finally
			{
				stopwatch.Stop();
				DowntimeMonitoringNotificationSubscriber.log.DebugFormat("Downtime notification has been processed in {0} miliseconds.", stopwatch.ElapsedMilliseconds);
			}
			return Task.CompletedTask;
		}

		// Token: 0x040001E3 RID: 483
		private const string NetObjectDowntimeIndication = "NetObjectDowntimeIndication";

		// Token: 0x040001E4 RID: 484
		private const string NetObjectDowntimeInitializator = "NetObjectDowntimeInitializator";

		// Token: 0x040001E5 RID: 485
		private readonly ISubscriptionManager _subscriptionManager;

		// Token: 0x040001E6 RID: 486
		private string _nodeNetObjectIdColumn;

		// Token: 0x040001E7 RID: 487
		protected static readonly Log log = new Log();

		// Token: 0x040001E8 RID: 488
		private readonly INetObjectDowntimeDAL _netObjectDowntimeDal;

		// Token: 0x040001E9 RID: 489
		private readonly IInformationServiceProxyCreator _swisServiceProxyCreator;

		// Token: 0x040001EA RID: 490
		private readonly ISwisUriParser _swisUriParser;

		// Token: 0x040001EB RID: 491
		private Lazy<ILookup<string, NetObjectTypeEx>> _netObjectTypes;

		// Token: 0x040001EC RID: 492
		private static readonly Regex NodeIdRegex = new Regex("(N:\\d+)", RegexOptions.Compiled);

		// Token: 0x040001ED RID: 493
		private readonly List<SubscriptionId> subscriptionIds = new List<SubscriptionId>();
	}
}
