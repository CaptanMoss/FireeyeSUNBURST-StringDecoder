﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.PubSub;
using SolarWinds.Orion.Swis.PubSub.InformationService;

namespace SolarWinds.Orion.Core.BusinessLayer.DowntimeMonitoring
{
	// Token: 0x0200007A RID: 122
	public class DowntimeMonitoringEnableSubscriber : ISubscriber
	{
		// Token: 0x06000606 RID: 1542 RVA: 0x000241C0 File Offset: 0x000223C0
		public DowntimeMonitoringEnableSubscriber(DowntimeMonitoringNotificationSubscriber downtimeMonitoringSubscriber) : this(SubscriptionManager.Instance, downtimeMonitoringSubscriber)
		{
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x000241CE File Offset: 0x000223CE
		public DowntimeMonitoringEnableSubscriber(ISubscriptionManager subscriptionManager, DowntimeMonitoringNotificationSubscriber downtimeMonitoringSubscriber)
		{
			if (subscriptionManager == null)
			{
				throw new ArgumentNullException("subscriptionManager");
			}
			if (downtimeMonitoringSubscriber == null)
			{
				throw new ArgumentNullException("downtimeMonitoringSubscriber");
			}
			this.subscriptionManager = subscriptionManager;
			this.downtimeMonitoringSubscriber = downtimeMonitoringSubscriber;
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x00024200 File Offset: 0x00022400
		// (set) Token: 0x06000609 RID: 1545 RVA: 0x00024208 File Offset: 0x00022408
		public DowntimeMonitoringNotificationSubscriber DowntimeMonitoringSubscriber
		{
			get
			{
				return this.downtimeMonitoringSubscriber;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("DowntimeMonitoringSubscriber");
				}
				this.downtimeMonitoringSubscriber = value;
			}
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x00024220 File Offset: 0x00022420
		public Task OnNotificationAsync(Notification notification)
		{
			if (notification.SourceInstanceProperties == null)
			{
				DowntimeMonitoringEnableSubscriber.Log.Error("Argument sourceInstanceProperties is null");
				return Task.CompletedTask;
			}
			if (!notification.SourceInstanceProperties.ContainsKey("CurrentValue"))
			{
				DowntimeMonitoringEnableSubscriber.Log.Error("CurrentValue not supplied in sourceInstanceProperties");
				return Task.CompletedTask;
			}
			try
			{
				DowntimeMonitoringEnableSubscriber.Log.DebugFormat("Downtime monitoring changed to {0}, unsubscribing..", notification.SourceInstanceProperties["CurrentValue"]);
				bool flag = Convert.ToBoolean(notification.SourceInstanceProperties["CurrentValue"]);
				this.downtimeMonitoringSubscriber.Stop();
				if (flag)
				{
					DowntimeMonitoringEnableSubscriber.Log.Debug("Re-subscribing..");
					this.downtimeMonitoringSubscriber.Start();
				}
				else
				{
					this.SealIntervals();
				}
			}
			catch (Exception ex)
			{
				DowntimeMonitoringEnableSubscriber.Log.Error("Indication handling failed", ex);
				return Task.CompletedTask;
			}
			return Task.CompletedTask;
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00024308 File Offset: 0x00022508
		private void SealIntervals()
		{
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("UPDATE [dbo].[NetObjectDowntime] SET [DateTimeUntil] = @now WHERE [DateTimeUntil] IS NULL"))
			{
				textCommand.Parameters.AddWithValue("@now", DateTime.Now.ToUniversalTime());
				SqlHelper.ExecuteNonQuery(textCommand);
			}
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x00024368 File Offset: 0x00022568
		public void Start()
		{
			DowntimeMonitoringEnableSubscriber.Log.Debug("Subscribing DowntimeMonitoringEnableSubscriber changed indications..");
			if (this.subscription != null)
			{
				DowntimeMonitoringEnableSubscriber.Log.Debug("Already subscribed, unsubscribing first..");
				this.Stop(false);
			}
			try
			{
				string subscriptionQuery = "SUBSCRIBE CHANGES TO Orion.Settings WHEN SettingsID = '" + DowntimeMonitoringEnableSubscriber.SettingsKey + "'";
				SubscriptionId subscriptionId;
				subscriptionId..ctor("Core", typeof(DowntimeMonitoringEnableSubscriber).FullName, 0);
				SubscriberConfiguration subscriberConfiguration = new SubscriberConfiguration
				{
					SubscriptionQuery = subscriptionQuery
				};
				this.subscription = this.subscriptionManager.Subscribe(subscriptionId, this, subscriberConfiguration);
				DowntimeMonitoringEnableSubscriber.Log.TraceFormat("Subscribed with URI '{0}'", new object[]
				{
					this.subscription
				});
			}
			catch (Exception ex)
			{
				DowntimeMonitoringEnableSubscriber.Log.Error("Failed to subscribe", ex);
				throw;
			}
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x00024438 File Offset: 0x00022638
		public void Stop(bool sealInterval = true)
		{
			DowntimeMonitoringEnableSubscriber.Log.Debug("Unsubscribing DowntimeMonitoringEnableSubscriber changed indications..");
			if (sealInterval)
			{
				try
				{
					this.SealIntervals();
				}
				catch (Exception ex)
				{
					DowntimeMonitoringEnableSubscriber.Log.Error("Failed to seal intervals", ex);
					throw;
				}
			}
			if (this.subscription == null)
			{
				DowntimeMonitoringEnableSubscriber.Log.Debug("SubscriptionUri not set, no action performed");
				return;
			}
			try
			{
				this.subscriptionManager.Unsubscribe(this.subscription.Id);
				this.subscription = null;
			}
			catch (Exception ex2)
			{
				DowntimeMonitoringEnableSubscriber.Log.Error("Failed to unsubscribe", ex2);
				throw;
			}
		}

		// Token: 0x040001DE RID: 478
		private static string SettingsKey = "SWNetPerfMon-Settings-EnableDowntimeMonitoring";

		// Token: 0x040001DF RID: 479
		private static readonly Log Log = new Log();

		// Token: 0x040001E0 RID: 480
		private readonly ISubscriptionManager subscriptionManager;

		// Token: 0x040001E1 RID: 481
		private DowntimeMonitoringNotificationSubscriber downtimeMonitoringSubscriber;

		// Token: 0x040001E2 RID: 482
		private ISubscription subscription;
	}
}
