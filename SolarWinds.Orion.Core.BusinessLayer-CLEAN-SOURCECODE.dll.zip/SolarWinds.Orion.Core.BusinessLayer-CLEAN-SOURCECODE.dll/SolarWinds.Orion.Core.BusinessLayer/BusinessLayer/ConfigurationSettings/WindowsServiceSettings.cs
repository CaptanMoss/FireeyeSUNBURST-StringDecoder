﻿using System;
using SolarWinds.Settings;

namespace SolarWinds.Orion.Core.BusinessLayer.ConfigurationSettings
{
	// Token: 0x02000066 RID: 102
	internal class WindowsServiceSettings : SettingsBase
	{
		// Token: 0x06000587 RID: 1415 RVA: 0x0001D410 File Offset: 0x0001B610
		private WindowsServiceSettings()
		{
		}

		// Token: 0x0400019C RID: 412
		public static readonly WindowsServiceSettings Instance = new WindowsServiceSettings();

		// Token: 0x0400019D RID: 413
		[Setting(Default = 20000, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int ServiceTimeout;
	}
}
