﻿using System;
using SolarWinds.Orion.Core.Common.Configuration;
using SolarWinds.Orion.Core.SharedCredentials.Credentials;
using SolarWinds.Settings;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000047 RID: 71
	internal class BusinessLayerSettings : SettingsBase, IBusinessLayerSettings
	{
		// Token: 0x06000443 RID: 1091 RVA: 0x0001D410 File Offset: 0x0001B610
		private BusinessLayerSettings()
		{
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000444 RID: 1092 RVA: 0x0001D418 File Offset: 0x0001B618
		public static IBusinessLayerSettings Instance
		{
			get
			{
				return BusinessLayerSettings.Factory();
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000445 RID: 1093 RVA: 0x0001D424 File Offset: 0x0001B624
		// (set) Token: 0x06000446 RID: 1094 RVA: 0x0001D42C File Offset: 0x0001B62C
		[Setting(Default = 30, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int DBConnectionRetryInterval { get; internal set; }

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000447 RID: 1095 RVA: 0x0001D435 File Offset: 0x0001B635
		// (set) Token: 0x06000448 RID: 1096 RVA: 0x0001D43D File Offset: 0x0001B63D
		[Setting(Default = 300, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int DBConnectionRetryIntervalOnFail { get; internal set; }

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06000449 RID: 1097 RVA: 0x0001D446 File Offset: 0x0001B646
		// (set) Token: 0x0600044A RID: 1098 RVA: 0x0001D44E File Offset: 0x0001B64E
		[Setting(Default = 10, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int DBConnectionRetries { get; internal set; }

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x0600044B RID: 1099 RVA: 0x0001D457 File Offset: 0x0001B657
		// (set) Token: 0x0600044C RID: 1100 RVA: 0x0001D45F File Offset: 0x0001B65F
		[Setting(Default = "net.pipe://localhost/solarwinds/jobengine/scheduler", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string JobSchedulerEndpointNetPipe { get; internal set; }

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x0600044D RID: 1101 RVA: 0x0001D468 File Offset: 0x0001B668
		// (set) Token: 0x0600044E RID: 1102 RVA: 0x0001D470 File Offset: 0x0001B670
		[Setting(Default = "net.tcp://{0}:17777/solarwinds/jobengine/scheduler/ssl", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string JobSchedulerEndpointTcpPipe { get; internal set; }

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x0600044F RID: 1103 RVA: 0x0001D479 File Offset: 0x0001B679
		[Obsolete("use SolarWinds.Orion.Core.Common.Configuration.HttpProxySettings without using WCF")]
		public bool ProxyAvailable
		{
			get
			{
				return !HttpProxySettings.Instance.IsDisabled;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06000450 RID: 1104 RVA: 0x0001D488 File Offset: 0x0001B688
		[Obsolete("use SolarWinds.Orion.Core.Common.Configuration.HttpProxySettings without using WCF")]
		public string UserName
		{
			get
			{
				IHttpProxySettings httpProxySettings = HttpProxySettings.Instance;
				if (!httpProxySettings.IsValid)
				{
					return null;
				}
				if (httpProxySettings.UseSystemDefaultProxy)
				{
					return string.Empty;
				}
				UsernamePasswordCredential usernamePasswordCredential = httpProxySettings.Credential as UsernamePasswordCredential;
				if (usernamePasswordCredential == null)
				{
					return null;
				}
				return usernamePasswordCredential.Username;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000451 RID: 1105 RVA: 0x0001D4CC File Offset: 0x0001B6CC
		[Obsolete("use SolarWinds.Orion.Core.Common.Configuration.HttpProxySettings without using WCF")]
		public string Password
		{
			get
			{
				IHttpProxySettings httpProxySettings = HttpProxySettings.Instance;
				if (!httpProxySettings.IsValid)
				{
					return null;
				}
				UsernamePasswordCredential usernamePasswordCredential = httpProxySettings.Credential as UsernamePasswordCredential;
				if (usernamePasswordCredential == null)
				{
					return null;
				}
				return usernamePasswordCredential.Password;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06000452 RID: 1106 RVA: 0x0001D500 File Offset: 0x0001B700
		[Obsolete("use SolarWinds.Orion.Core.Common.Configuration.HttpProxySettings without using WCF")]
		public string ProxyAddress
		{
			get
			{
				IHttpProxySettings httpProxySettings = HttpProxySettings.Instance;
				if (!httpProxySettings.IsValid)
				{
					return string.Empty;
				}
				return new Uri(httpProxySettings.Uri).Host;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000453 RID: 1107 RVA: 0x0001D534 File Offset: 0x0001B734
		[Obsolete("use SolarWinds.Orion.Core.Common.Configuration.HttpProxySettings without using WCF")]
		public int ProxyPort
		{
			get
			{
				IHttpProxySettings httpProxySettings = HttpProxySettings.Instance;
				if (!httpProxySettings.IsValid)
				{
					return 0;
				}
				return new Uri(httpProxySettings.Uri).Port;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000454 RID: 1108 RVA: 0x0001D561 File Offset: 0x0001B761
		// (set) Token: 0x06000455 RID: 1109 RVA: 0x0001D569 File Offset: 0x0001B769
		[Setting(Default = "http://thwackfeeds.solarwinds.com/blogs/orion-product-team-blog/rss.aspx", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string OrionProductTeamBlogUrl { get; internal set; }

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000456 RID: 1110 RVA: 0x0001D572 File Offset: 0x0001B772
		// (set) Token: 0x06000457 RID: 1111 RVA: 0x0001D57A File Offset: 0x0001B77A
		[Setting(Default = 60, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int LicenseSaturationCheckInterval { get; internal set; }

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000458 RID: 1112 RVA: 0x0001D583 File Offset: 0x0001B783
		// (set) Token: 0x06000459 RID: 1113 RVA: 0x0001D58B File Offset: 0x0001B78B
		[Setting(Default = 90, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int MaintenanceExpirationWarningDays { get; internal set; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600045A RID: 1114 RVA: 0x0001D594 File Offset: 0x0001B794
		// (set) Token: 0x0600045B RID: 1115 RVA: 0x0001D59C File Offset: 0x0001B79C
		[Setting(Default = 15, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int MaintenanceExpiredShowAgainAtDays { get; internal set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x0600045C RID: 1116 RVA: 0x0001D5A5 File Offset: 0x0001B7A5
		// (set) Token: 0x0600045D RID: 1117 RVA: 0x0001D5AD File Offset: 0x0001B7AD
		[Setting(Default = "00:05:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan PollerLimitTimer { get; internal set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x0600045E RID: 1118 RVA: 0x0001D5B6 File Offset: 0x0001B7B6
		// (set) Token: 0x0600045F RID: 1119 RVA: 0x0001D5BE File Offset: 0x0001B7BE
		[Setting(Default = "00:30:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan CheckDatabaseLimitTimer { get; internal set; }

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000460 RID: 1120 RVA: 0x0001D5C7 File Offset: 0x0001B7C7
		// (set) Token: 0x06000461 RID: 1121 RVA: 0x0001D5CF File Offset: 0x0001B7CF
		[Setting(Default = "00:05:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan CheckForOldLogsTimer { get; internal set; }

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000462 RID: 1122 RVA: 0x0001D5D8 File Offset: 0x0001B7D8
		// (set) Token: 0x06000463 RID: 1123 RVA: 0x0001D5E0 File Offset: 0x0001B7E0
		[Setting(Default = "00:00:30", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan UpdateEngineTimer { get; internal set; }

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000464 RID: 1124 RVA: 0x0001D5E9 File Offset: 0x0001B7E9
		// (set) Token: 0x06000465 RID: 1125 RVA: 0x0001D5F1 File Offset: 0x0001B7F1
		[Setting(Default = "00:02:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan RemoteCollectorStatusCacheExpiration { get; internal set; }

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000466 RID: 1126 RVA: 0x0001D5FA File Offset: 0x0001B7FA
		// (set) Token: 0x06000467 RID: 1127 RVA: 0x0001D602 File Offset: 0x0001B802
		[Setting(Default = false, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public bool MaintenanceModeEnabled { get; internal set; }

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000468 RID: 1128 RVA: 0x0001D60B File Offset: 0x0001B80B
		// (set) Token: 0x06000469 RID: 1129 RVA: 0x0001D613 File Offset: 0x0001B813
		[Setting(Default = "00:01:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan SettingsToRegistryFrequency { get; internal set; }

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600046A RID: 1130 RVA: 0x0001D61C File Offset: 0x0001B81C
		// (set) Token: 0x0600046B RID: 1131 RVA: 0x0001D624 File Offset: 0x0001B824
		[Setting(Default = "00:00:10", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan DiscoveryUpdateNetObjectStatusWaitForChangesDelay { get; internal set; }

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x0600046C RID: 1132 RVA: 0x0001D62D File Offset: 0x0001B82D
		// (set) Token: 0x0600046D RID: 1133 RVA: 0x0001D635 File Offset: 0x0001B835
		[Setting(Default = "00:02:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan DiscoveryUpdateNetObjectStatusStartupDelay { get; internal set; }

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x0600046E RID: 1134 RVA: 0x0001D63E File Offset: 0x0001B83E
		// (set) Token: 0x0600046F RID: 1135 RVA: 0x0001D646 File Offset: 0x0001B846
		[Setting(Default = true, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public bool EnableLimitationReplacement { get; internal set; }

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x06000470 RID: 1136 RVA: 0x0001D64F File Offset: 0x0001B84F
		// (set) Token: 0x06000471 RID: 1137 RVA: 0x0001D657 File Offset: 0x0001B857
		[Setting(Default = true, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public bool EnableTechnologyPollingAssignmentsChangesAuditing { get; internal set; }

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x06000472 RID: 1138 RVA: 0x0001D660 File Offset: 0x0001B860
		// (set) Token: 0x06000473 RID: 1139 RVA: 0x0001D668 File Offset: 0x0001B868
		[Setting(Default = 5, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int LimitationSqlExaggeration { get; internal set; }

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x06000474 RID: 1140 RVA: 0x0001D671 File Offset: 0x0001B871
		// (set) Token: 0x06000475 RID: 1141 RVA: 0x0001D679 File Offset: 0x0001B879
		[Setting(Default = "00:10:00", AllowServerOverride = true)]
		public TimeSpan AgentDiscoveryPluginsDeploymentTimeLimit { get; internal set; }

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000476 RID: 1142 RVA: 0x0001D682 File Offset: 0x0001B882
		// (set) Token: 0x06000477 RID: 1143 RVA: 0x0001D68A File Offset: 0x0001B88A
		[Setting(Default = "00:10:00", AllowServerOverride = true)]
		public TimeSpan AgentDiscoveryJobTimeout { get; internal set; }

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000478 RID: 1144 RVA: 0x0001D693 File Offset: 0x0001B893
		// (set) Token: 0x06000479 RID: 1145 RVA: 0x0001D69B File Offset: 0x0001B89B
		[Setting(Default = "1.00:00:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		}, Description = "Time for which we try to perform safe certificate maintenance. If the certificate maintenance can't be done in a safe way - no damage to the system or data - for given time, we inform user and let him confirm maintenance with knowledge what will break.", Deprecated = true)]
		public TimeSpan SafeCertificateMaintenanceTrialPeriod { get; internal set; }

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x0600047A RID: 1146 RVA: 0x0001D6A4 File Offset: 0x0001B8A4
		// (set) Token: 0x0600047B RID: 1147 RVA: 0x0001D6AC File Offset: 0x0001B8AC
		[Setting(Default = "00:05:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		}, Description = "Frequency with which certificate maintenance task result is checked.", Deprecated = true)]
		public TimeSpan CertificateMaintenanceTaskCheckInterval { get; internal set; }

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x0600047C RID: 1148 RVA: 0x0001D6B5 File Offset: 0x0001B8B5
		// (set) Token: 0x0600047D RID: 1149 RVA: 0x0001D6BD File Offset: 0x0001B8BD
		[Setting(Default = "00:05:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		}, Description = "After how long a notification about certificate maintenance approval reappears if customer acknowledges it and does not approve certificate maintenance.", Deprecated = true)]
		public TimeSpan CertificateMaintenanceNotificationReappearPeriod { get; internal set; }

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x0600047E RID: 1150 RVA: 0x0001D6C6 File Offset: 0x0001B8C6
		// (set) Token: 0x0600047F RID: 1151 RVA: 0x0001D6CE File Offset: 0x0001B8CE
		[Setting(Default = "00:01:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		}, Description = "How often Core polls AMS to get fresh status of agent certificate update for certificate maintenance.", Deprecated = true)]
		public TimeSpan CertificateMaintenanceAgentPollFrequency { get; internal set; }

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06000480 RID: 1152 RVA: 0x0001D6D7 File Offset: 0x0001B8D7
		// (set) Token: 0x06000481 RID: 1153 RVA: 0x0001D6DF File Offset: 0x0001B8DF
		[Setting(Default = "00:00:30", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		}, Description = "How long Core waits for results from test jobs.")]
		public TimeSpan TestJobTimeout { get; internal set; }

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x06000482 RID: 1154 RVA: 0x0001D6E8 File Offset: 0x0001B8E8
		// (set) Token: 0x06000483 RID: 1155 RVA: 0x0001D6F0 File Offset: 0x0001B8F0
		[Setting(Default = "00:10:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan BackgroundInventoryCheckTimer { get; internal set; }

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x06000484 RID: 1156 RVA: 0x0001D6F9 File Offset: 0x0001B8F9
		// (set) Token: 0x06000485 RID: 1157 RVA: 0x0001D701 File Offset: 0x0001B901
		[Setting(Default = 50, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int BackgroundInventoryParallelTasksCount { get; internal set; }

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x06000486 RID: 1158 RVA: 0x0001D70A File Offset: 0x0001B90A
		// (set) Token: 0x06000487 RID: 1159 RVA: 0x0001D712 File Offset: 0x0001B912
		[Setting(Default = 10, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int BackgroundInventoryRetriesCount { get; internal set; }

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x06000488 RID: 1160 RVA: 0x0001D71B File Offset: 0x0001B91B
		// (set) Token: 0x06000489 RID: 1161 RVA: 0x0001D723 File Offset: 0x0001B923
		[Setting(Default = 10000, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int ThresholdsProcessingBatchSize { get; internal set; }

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x0600048A RID: 1162 RVA: 0x0001D72C File Offset: 0x0001B92C
		// (set) Token: 0x0600048B RID: 1163 RVA: 0x0001D734 File Offset: 0x0001B934
		[Setting(Default = "Core_All", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsProcessingDefaultTimeFrame { get; internal set; }

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x0600048C RID: 1164 RVA: 0x0001D73D File Offset: 0x0001B93D
		// (set) Token: 0x0600048D RID: 1165 RVA: 0x0001D745 File Offset: 0x0001B945
		[Setting(Default = "00:05:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public TimeSpan ThresholdsProcessingDefaultTimer { get; internal set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x0600048E RID: 1166 RVA: 0x0001D74E File Offset: 0x0001B94E
		// (set) Token: 0x0600048F RID: 1167 RVA: 0x0001D756 File Offset: 0x0001B956
		[Setting(Default = true, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public bool ThresholdsProcessingEnabled { get; internal set; }

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06000490 RID: 1168 RVA: 0x0001D75F File Offset: 0x0001B95F
		// (set) Token: 0x06000491 RID: 1169 RVA: 0x0001D767 File Offset: 0x0001B967
		[Setting(Default = "${USE_BASELINE}", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsUseBaselineCalculationMacro { get; internal set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x06000492 RID: 1170 RVA: 0x0001D770 File Offset: 0x0001B970
		// (set) Token: 0x06000493 RID: 1171 RVA: 0x0001D778 File Offset: 0x0001B978
		[Setting(Default = "${USE_BASELINE_WARNING}", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsUseBaselineWarningCalculationMacro { get; internal set; }

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x06000494 RID: 1172 RVA: 0x0001D781 File Offset: 0x0001B981
		// (set) Token: 0x06000495 RID: 1173 RVA: 0x0001D789 File Offset: 0x0001B989
		[Setting(Default = "${USE_BASELINE_CRITICAL}", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsUseBaselineCriticalCalculationMacro { get; internal set; }

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06000496 RID: 1174 RVA: 0x0001D792 File Offset: 0x0001B992
		// (set) Token: 0x06000497 RID: 1175 RVA: 0x0001D79A File Offset: 0x0001B99A
		[Setting(Default = "${MEAN}+2*${STD_DEV}", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsDefaultWarningFormulaForGreater { get; internal set; }

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000498 RID: 1176 RVA: 0x0001D7A3 File Offset: 0x0001B9A3
		// (set) Token: 0x06000499 RID: 1177 RVA: 0x0001D7AB File Offset: 0x0001B9AB
		[Setting(Default = "${MEAN}-2*${STD_DEV}", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsDefaultWarningFormulaForLess { get; internal set; }

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x0600049A RID: 1178 RVA: 0x0001D7B4 File Offset: 0x0001B9B4
		// (set) Token: 0x0600049B RID: 1179 RVA: 0x0001D7BC File Offset: 0x0001B9BC
		[Setting(Default = "${MEAN}+3*${STD_DEV}", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsDefaultCriticalFormulaForGreater { get; internal set; }

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x0600049C RID: 1180 RVA: 0x0001D7C5 File Offset: 0x0001B9C5
		// (set) Token: 0x0600049D RID: 1181 RVA: 0x0001D7CD File Offset: 0x0001B9CD
		[Setting(Default = "${MEAN}-3*${STD_DEV}", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public string ThresholdsDefaultCriticalFormulaForLess { get; internal set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x0600049E RID: 1182 RVA: 0x0001D7D6 File Offset: 0x0001B9D6
		// (set) Token: 0x0600049F RID: 1183 RVA: 0x0001D7DE File Offset: 0x0001B9DE
		[Setting(Default = 50, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int ThresholdsHistogramChartIntervalsCount { get; internal set; }

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x060004A0 RID: 1184 RVA: 0x0001D7E7 File Offset: 0x0001B9E7
		// (set) Token: 0x060004A1 RID: 1185 RVA: 0x0001D7EF File Offset: 0x0001B9EF
		[Setting(Default = 12, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int EvaluationExpirationCheckIntervalHours { get; internal set; }

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x060004A2 RID: 1186 RVA: 0x0001D7F8 File Offset: 0x0001B9F8
		// (set) Token: 0x060004A3 RID: 1187 RVA: 0x0001D800 File Offset: 0x0001BA00
		[Setting(Default = 14, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int EvaluationExpirationNotificationDays { get; internal set; }

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060004A4 RID: 1188 RVA: 0x0001D809 File Offset: 0x0001BA09
		// (set) Token: 0x060004A5 RID: 1189 RVA: 0x0001D811 File Offset: 0x0001BA11
		[Setting(Default = 7, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int EvaluationExpirationShowAgainAtDays { get; internal set; }

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060004A6 RID: 1190 RVA: 0x0001D81A File Offset: 0x0001BA1A
		// (set) Token: 0x060004A7 RID: 1191 RVA: 0x0001D822 File Offset: 0x0001BA22
		[Setting(Default = 7, AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		})]
		public int CachedWebImageExpirationPeriodDays { get; internal set; }

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060004A8 RID: 1192 RVA: 0x0001D82B File Offset: 0x0001BA2B
		// (set) Token: 0x060004A9 RID: 1193 RVA: 0x0001D833 File Offset: 0x0001BA33
		[Setting(Default = "00:10:00", AllowServerOverride = true, ServiceRestartDependencies = new string[]
		{
			"OrionModuleEngine"
		}, Description = "How often we synchronize Orion.Features.")]
		public TimeSpan OrionFeatureRefreshTimer { get; internal set; }

		// Token: 0x0400010F RID: 271
		private static readonly Lazy<IBusinessLayerSettings> instance = new Lazy<IBusinessLayerSettings>(() => new BusinessLayerSettings());

		// Token: 0x04000110 RID: 272
		public static Func<IBusinessLayerSettings> Factory = () => BusinessLayerSettings.instance.Value;
	}
}
