﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using SolarWinds.Common.Threading;
using SolarWinds.Database.TimeSeries;
using SolarWinds.Database.TimeSeries.Contracts;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;

namespace SolarWinds.Orion.Core.BusinessLayer.TimeSeries
{
	// Token: 0x0200004A RID: 74
	internal class TimeSeriesDataInsertorLazy : ITimeSeriesDataInsertor
	{
		// Token: 0x060004B5 RID: 1205 RVA: 0x0001DDE8 File Offset: 0x0001BFE8
		private static IDataInsertor CreateDataInsertor()
		{
			return new TimeSeriesDatabaseFactory(TimeSeriesSettings.Instance, new TimeSeriesDataInsertorLazy.DatabaseConnectionFactory(), new TimeSeriesDataInsertorLazy.LoggerFactory()).InitializeDatabase().DataInsertor;
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0001DE08 File Offset: 0x0001C008
		public void InsertData(string tableName, IReadOnlyList<string> columnNames, IEnumerable<IReadOnlyList<object>> data)
		{
			this._dataInsertor.Value.InsertData(tableName, columnNames, data);
		}

		// Token: 0x04000146 RID: 326
		private static readonly Log log = new Log();

		// Token: 0x04000147 RID: 327
		private readonly LazyWithoutExceptionCache<IDataInsertor> _dataInsertor = new LazyWithoutExceptionCache<IDataInsertor>(new Func<IDataInsertor>(TimeSeriesDataInsertorLazy.CreateDataInsertor));

		// Token: 0x02000158 RID: 344
		private class LoggerFactory : ILoggerFactory
		{
			// Token: 0x06000B7A RID: 2938 RVA: 0x0004A190 File Offset: 0x00048390
			public ILogger<T> CreateLogger<T>()
			{
				return new TimeSeriesDataInsertorLazy.LoggerFactory.Logger<T>();
			}

			// Token: 0x020001D7 RID: 471
			private class Logger<T> : ILogger<T>, ILogger
			{
				// Token: 0x06000D23 RID: 3363 RVA: 0x0004C95F File Offset: 0x0004AB5F
				public void LogDebug(string message)
				{
					TimeSeriesDataInsertorLazy.log.Debug(message);
				}

				// Token: 0x06000D24 RID: 3364 RVA: 0x0004C96C File Offset: 0x0004AB6C
				public void LogInfo(string message)
				{
					TimeSeriesDataInsertorLazy.log.Info(message);
				}

				// Token: 0x06000D25 RID: 3365 RVA: 0x0004C979 File Offset: 0x0004AB79
				public void LogError(string message)
				{
					TimeSeriesDataInsertorLazy.log.Error(message);
				}
			}
		}

		// Token: 0x02000159 RID: 345
		private class DatabaseConnectionFactory : IConnectionFactory
		{
			// Token: 0x06000B7C RID: 2940 RVA: 0x0004A197 File Offset: 0x00048397
			public Task<IDbConnection> CreateAndOpenAsync(CancellationToken cancellation = default(CancellationToken))
			{
				return Task.FromResult<IDbConnection>(DatabaseFunctions.CreateConnection());
			}

			// Token: 0x06000B7D RID: 2941 RVA: 0x0004A1A3 File Offset: 0x000483A3
			public IDbConnection CreateAndOpen()
			{
				return DatabaseFunctions.CreateConnection();
			}

			// Token: 0x06000B7E RID: 2942 RVA: 0x0004A1AA File Offset: 0x000483AA
			public SqlConnection RetrieveSqlConnection(IDbConnection connection)
			{
				return (SqlConnection)connection;
			}
		}
	}
}
