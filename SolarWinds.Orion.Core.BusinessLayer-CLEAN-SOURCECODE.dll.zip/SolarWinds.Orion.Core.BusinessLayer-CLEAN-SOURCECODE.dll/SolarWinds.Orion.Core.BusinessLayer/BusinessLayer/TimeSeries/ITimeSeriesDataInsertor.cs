﻿using System;
using System.Collections.Generic;

namespace SolarWinds.Orion.Core.BusinessLayer.TimeSeries
{
	// Token: 0x0200004B RID: 75
	internal interface ITimeSeriesDataInsertor
	{
		// Token: 0x060004B9 RID: 1209
		void InsertData(string tableName, IReadOnlyList<string> columnNames, IEnumerable<IReadOnlyList<object>> data);
	}
}
