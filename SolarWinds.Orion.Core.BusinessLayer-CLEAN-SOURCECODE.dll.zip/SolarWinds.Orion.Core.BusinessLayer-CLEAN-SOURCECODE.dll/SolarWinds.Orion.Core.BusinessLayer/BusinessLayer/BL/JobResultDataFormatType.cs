﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.BL
{
	// Token: 0x020000B8 RID: 184
	public enum JobResultDataFormatType
	{
		// Token: 0x04000288 RID: 648
		Xml,
		// Token: 0x04000289 RID: 649
		Json
	}
}
