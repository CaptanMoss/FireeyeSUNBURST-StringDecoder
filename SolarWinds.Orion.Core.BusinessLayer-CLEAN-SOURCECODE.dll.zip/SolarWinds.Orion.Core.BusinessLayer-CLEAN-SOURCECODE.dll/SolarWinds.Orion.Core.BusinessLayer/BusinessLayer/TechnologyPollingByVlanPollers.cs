﻿using System;
using System.Collections.Generic;
using System.Linq;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Models.Interfaces;
using SolarWinds.Orion.Core.Models.Technology;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000017 RID: 23
	public class TechnologyPollingByVlanPollers : ITechnologyPolling
	{
		// Token: 0x06000295 RID: 661 RVA: 0x0001058A File Offset: 0x0000E78A
		public TechnologyPollingByVlanPollers(string technologyID, string technologyPollingID, string displayName, int priority, string[] pollerTypePatterns)
		{
			this.TechnologyID = technologyID;
			this.TechnologyPollingID = technologyPollingID;
			this.DisplayName = displayName;
			this.Priority = priority;
			this.pollerTypePatterns = pollerTypePatterns;
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000296 RID: 662 RVA: 0x000105C2 File Offset: 0x0000E7C2
		// (set) Token: 0x06000297 RID: 663 RVA: 0x000105CA File Offset: 0x0000E7CA
		public string TechnologyID { get; set; }

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000298 RID: 664 RVA: 0x000105D3 File Offset: 0x0000E7D3
		// (set) Token: 0x06000299 RID: 665 RVA: 0x000105DB File Offset: 0x0000E7DB
		public string TechnologyPollingID { get; set; }

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x0600029A RID: 666 RVA: 0x000105E4 File Offset: 0x0000E7E4
		// (set) Token: 0x0600029B RID: 667 RVA: 0x000105EC File Offset: 0x0000E7EC
		public string DisplayName { get; set; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x0600029C RID: 668 RVA: 0x000105F5 File Offset: 0x0000E7F5
		// (set) Token: 0x0600029D RID: 669 RVA: 0x000105FD File Offset: 0x0000E7FD
		public int Priority { get; set; }

		// Token: 0x0600029E RID: 670 RVA: 0x00010608 File Offset: 0x0000E808
		public int[] EnableDisableAssignment(bool enable, int[] netObjectIDs)
		{
			return (from p in this.pollersDAL.UpdatePollersStatus(this.pollerTypePatterns, enable, netObjectIDs)
			select p.NetObjectID).Distinct<int>().ToArray<int>();
		}

		// Token: 0x0600029F RID: 671 RVA: 0x00010658 File Offset: 0x0000E858
		public int[] EnableDisableAssignment(bool enable)
		{
			return (from p in this.pollersDAL.UpdatePollersStatus(this.pollerTypePatterns, enable, null)
			select p.NetObjectID).Distinct<int>().ToArray<int>();
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x000106A6 File Offset: 0x0000E8A6
		public IEnumerable<TechnologyPollingAssignment> GetAssignments()
		{
			return this.GetAssignments(null);
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x000106AF File Offset: 0x0000E8AF
		public IEnumerable<TechnologyPollingAssignment> GetAssignments(int[] netObjectIDs)
		{
			return this.pollersDAL.GetPollersAssignmentsGroupedByNetObjectIdMatchingAllPollerTypes(this.TechnologyPollingID, this.pollerTypePatterns, netObjectIDs);
		}

		// Token: 0x0400006E RID: 110
		private PollersDAL pollersDAL = new PollersDAL();

		// Token: 0x0400006F RID: 111
		protected string[] pollerTypePatterns;
	}
}
