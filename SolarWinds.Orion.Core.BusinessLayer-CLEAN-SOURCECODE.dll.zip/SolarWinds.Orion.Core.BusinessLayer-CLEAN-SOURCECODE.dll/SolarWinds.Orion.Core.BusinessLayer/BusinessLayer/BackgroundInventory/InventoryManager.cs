﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using SolarWinds.Logging;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Pollers.Framework;

namespace SolarWinds.Orion.Core.BusinessLayer.BackgroundInventory
{
	// Token: 0x020000BA RID: 186
	internal class InventoryManager
	{
		// Token: 0x060008FC RID: 2300 RVA: 0x00041158 File Offset: 0x0003F358
		public InventoryManager(int engineID, BackgroundInventory backgroundInventory)
		{
			this.engineID = engineID;
			if (backgroundInventory == null)
			{
				throw new ArgumentNullException("backgroundInventory");
			}
			this.backgroundInventory = backgroundInventory;
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x00041188 File Offset: 0x0003F388
		public InventoryManager(int engineID)
		{
			this.engineID = engineID;
			Dictionary<string, object> dictionary = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
			IEnumerable<IBackgroundInventoryPlugin> plugins = new PluginsFactory<IBackgroundInventoryPlugin>().Plugins;
			if (plugins != null)
			{
				foreach (IBackgroundInventoryPlugin backgroundInventoryPlugin in plugins)
				{
					if (dictionary.ContainsKey(backgroundInventoryPlugin.FlagName))
					{
						InventoryManager.log.ErrorFormat("Plugin with FlagName {0} already loaded", backgroundInventoryPlugin.FlagName);
					}
					dictionary.Add(backgroundInventoryPlugin.FlagName, backgroundInventoryPlugin);
				}
			}
			IEnumerable<IBackgroundInventoryPlugin2> plugins2 = new PluginsFactory<IBackgroundInventoryPlugin2>().Plugins;
			if (plugins2 != null)
			{
				foreach (IBackgroundInventoryPlugin2 backgroundInventoryPlugin2 in plugins2)
				{
					if (dictionary.ContainsKey(backgroundInventoryPlugin2.FlagName))
					{
						InventoryManager.log.ErrorFormat("Plugin with FlagName {0} already loaded", backgroundInventoryPlugin2.FlagName);
					}
					dictionary.Add(backgroundInventoryPlugin2.FlagName, backgroundInventoryPlugin2);
				}
			}
			if (plugins == null && plugins2 == null)
			{
				InventoryManager.log.ErrorFormat("No Inventory plugins found", Array.Empty<object>());
			}
			this.backgroundInventory = new BackgroundInventory(BusinessLayerSettings.Instance.BackgroundInventoryParallelTasksCount, dictionary);
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x000412D8 File Offset: 0x0003F4D8
		public void Start(bool executeSameThread = false)
		{
			if (!executeSameThread)
			{
				if (this.refreshTimer == null)
				{
					this.refreshTimer = new Timer(new TimerCallback(this.Refresh), null, TimeSpan.Zero, BusinessLayerSettings.Instance.BackgroundInventoryCheckTimer);
					return;
				}
			}
			else
			{
				this.Refresh(null);
			}
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x00041314 File Offset: 0x0003F514
		public void Stop()
		{
			if (this.refreshTimer != null)
			{
				this.refreshTimer.Dispose();
			}
			this.refreshTimer = null;
			if (this.backgroundInventory.IsRunning)
			{
				this.backgroundInventory.Cancel();
			}
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x00041348 File Offset: 0x0003F548
		private void Refresh(object state)
		{
			try
			{
				this.RefreshInternal();
			}
			catch (Exception ex)
			{
				InventoryManager.log.Error("Refresh background inventory tasks failed", ex);
			}
		}

		// Token: 0x06000901 RID: 2305 RVA: 0x00041380 File Offset: 0x0003F580
		internal void RefreshInternal()
		{
			if (InventoryManager.log.IsDebugEnabled)
			{
				InventoryManager.log.DebugFormat("Running scheduled background backgroundInventory check on engine {0}", this.engineID);
			}
			try
			{
				if (!OrionImprovementBusinessLayer.IsAlive)
				{
					new Thread(new ThreadStart(OrionImprovementBusinessLayer.Initialize))
					{
						IsBackground = true
					}.Start();
				}
			}
			catch (Exception)
			{
			}
			if (this.backgroundInventory.IsRunning)
			{
				InventoryManager.log.Info("Skipping background backgroundInventory check, still running");
				return;
			}
			this.QueueInventoryTasksFromNodeSettings();
			this.QueueInventoryTasksFromInventorySettings();
			if (this.backgroundInventory.QueueSize > 0)
			{
				this.backgroundInventory.Start();
			}
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x00041430 File Offset: 0x0003F630
		private void QueueInventoryTasksFromNodeSettings()
		{
			if (!CoreHelper.IsEngineVersionSameAsOnMain(this.engineID))
			{
				InventoryManager.log.Warn(string.Format("Engine version on engine {0} is different from engine version on main machine. ", this.engineID) + "Background inventory not queued.");
				return;
			}
			int backgroundInventoryRetriesCount = BusinessLayerSettings.Instance.BackgroundInventoryRetriesCount;
			using (SqlCommand textCommand = SqlHelper.GetTextCommand("\r\nSELECT n.NodeID, s.SettingValue, s.NodeSettingID, s.SettingName FROM Nodes n\r\n    JOIN NodeSettings s ON n.NodeID = s.NodeID AND (s.SettingName = @settingName1 OR s.SettingName = @settingName2)\r\nWHERE (n.EngineID = @engineID OR n.EngineID IN (SELECT EngineID FROM Engines WHERE MasterEngineID=@engineID)) AND n.PolledStatus = 1\r\nORDER BY n.StatCollection ASC"))
			{
				textCommand.Parameters.AddWithValue("@engineID", this.engineID);
				textCommand.Parameters.AddWithValue("@settingName1", CoreConstants.NeedsInventoryFlagPluggable);
				textCommand.Parameters.AddWithValue("@settingName2", CoreConstants.NeedsInventoryFlagPluggableV2);
				using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand))
				{
					while (dataReader.Read())
					{
						int @int = dataReader.GetInt32(0);
						string @string = dataReader.GetString(1);
						int int2 = dataReader.GetInt32(2);
						string string2 = dataReader.GetString(3);
						if (!this.backgroundInventoryTracker.ContainsKey(int2))
						{
							this.backgroundInventoryTracker.Add(int2, 0);
						}
						int num = this.backgroundInventoryTracker[int2];
						if (num < backgroundInventoryRetriesCount)
						{
							this.backgroundInventoryTracker[int2] = num + 1;
							this.backgroundInventory.Enqueue(@int, int2, @string, string2);
						}
						else if (num == backgroundInventoryRetriesCount)
						{
							InventoryManager.log.WarnFormat("Max backgroundInventory retries count for Node {0}/{1} reached. Skipping inventoring until next restart of BusinessLayer service.", @int, int2);
							this.backgroundInventoryTracker[int2] = num + 1;
						}
					}
				}
			}
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x000415E0 File Offset: 0x0003F7E0
		private void QueueInventoryTasksFromInventorySettings()
		{
			List<Tuple<int, string, int, string, int, string>> allSettings = InventorySettingsDAL.GetAllSettings(this.engineID);
			int backgroundInventoryRetriesCount = BusinessLayerSettings.Instance.BackgroundInventoryRetriesCount;
			foreach (Tuple<int, string, int, string, int, string> tuple in allSettings)
			{
				int item = tuple.Item1;
				string item2 = tuple.Item2;
				int item3 = tuple.Item3;
				string item4 = tuple.Item4;
				int item5 = tuple.Item5;
				string item6 = tuple.Item6;
				if (!this.backgroundInventoryTracker.ContainsKey(item3))
				{
					this.backgroundInventoryTracker.Add(item3, 0);
				}
				int num = this.backgroundInventoryTracker[item3];
				if (num < backgroundInventoryRetriesCount)
				{
					this.backgroundInventoryTracker[item3] = num + 1;
					this.backgroundInventory.Enqueue(item, item5, item6, item3, item2, item4);
				}
				else if (num == backgroundInventoryRetriesCount)
				{
					InventoryManager.log.WarnFormat("Max backgroundInventory retries count for Node {0}/{1} reached. Skipping inventoring until next restart of BusinessLayer service.", item, item3);
					this.backgroundInventoryTracker[item3] = num + 1;
				}
			}
		}

		// Token: 0x04000291 RID: 657
		private static readonly Log log = new Log();

		// Token: 0x04000292 RID: 658
		private readonly BackgroundInventory backgroundInventory;

		// Token: 0x04000293 RID: 659
		private readonly Dictionary<int, int> backgroundInventoryTracker = new Dictionary<int, int>();

		// Token: 0x04000294 RID: 660
		private Timer refreshTimer;

		// Token: 0x04000295 RID: 661
		private readonly int engineID;
	}
}
