﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.BusinessLayer.DAL;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.DALs;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Models.Enums;
using SolarWinds.Orion.Core.SharedCredentials;
using SolarWinds.Orion.Pollers.Framework;
using SolarWinds.Orion.Pollers.Framework.SNMP;
using SolarWinds.Orion.Pollers.Framework.WMI;

namespace SolarWinds.Orion.Core.BusinessLayer.BackgroundInventory
{
	// Token: 0x020000B9 RID: 185
	public class BackgroundInventory : IDisposable
	{
		// Token: 0x17000121 RID: 289
		// (get) Token: 0x060008E8 RID: 2280 RVA: 0x0004087D File Offset: 0x0003EA7D
		public bool IsRunning
		{
			get
			{
				return this.scheduler.IsRunning;
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x060008E9 RID: 2281 RVA: 0x0004088A File Offset: 0x0003EA8A
		public int QueueSize
		{
			get
			{
				return this.scheduler.QueueSize;
			}
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x00040897 File Offset: 0x0003EA97
		public virtual bool IsScheduledTaskCanceled()
		{
			return this.scheduler.IsTaskCanceled;
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x000408A4 File Offset: 0x0003EAA4
		public BackgroundInventory(int parallelTasksCount, Dictionary<string, object> plugins)
		{
			if (plugins == null)
			{
				throw new ArgumentNullException("plugins");
			}
			this.scheduler = new QueuedTaskScheduler<BackgroundInventory.InventoryTask>(new QueuedTaskScheduler<BackgroundInventory.InventoryTask>.TaskProcessingRoutine(this.DoInventory), parallelTasksCount);
			this.scheduler.TaskProcessingFinished += this.scheduler_TaskProcessingFinished;
			this.snmpGlobals = new SnmpGlobalSettings();
			this.snmpGlobals.MaxReplies = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-SNMP MaxReps", 5);
			this.snmpGlobals.RequestTimeout = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-SNMP Timeout", 2500);
			this.snmpGlobals.RequestRetries = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-SNMP Retries", 2);
			this.snmpGlobals.HsrpEnabled = SettingsDAL.GetCurrent<bool>("SWNetPerfMon-Settings-SNMP HSRPEnabled", true);
			this.wmiGlobals = new WmiGlobalSettings();
			this.wmiGlobals.UserImpersonationLevel = SettingsDAL.GetCurrent<ImpersonationLevel>("SWNetPerfMon-Settings-Wmi UserImpersonationLevel", ImpersonationLevel.Default);
			this.wmiGlobals.ConnectionRationMode = SettingsDAL.GetCurrent<WmiConnectionRationMode>("SWNetPerfMon-Settings-Wmi ConnectionRationMode", 1);
			this.wmiGlobals.MaxRationedConnections = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-Wmi MaxRationedConnections", 0);
			this.wmiGlobals.KillProcessExcessiveError = SettingsDAL.GetCurrent<bool>("SWNetPerfMon-Settings-Wmi KillProcessExcessiveError", true);
			this.wmiGlobals.ExcessiveErrorThreshhold = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-Wmi ExcessiveErrorThreshhold", 50);
			this.wmiGlobals.WmiRetries = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-WMI Retries", 0);
			this.wmiGlobals.WmiRetryInterval = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-WMI Retry Interval", 0);
			this.wmiGlobals.WmiAutoCorrectRDNSInconsistency = Convert.ToBoolean(SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-WMI Auto Correct Reverse DNS", 0));
			this.wmiGlobals.WmiDefaultRootNamespaceOverrideIndex = SettingsDAL.GetCurrentInt("SWNetPerfMon-Settings-WMI Default Root Namespace Override Index", 0);
			this.inventories = plugins;
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x00040A44 File Offset: 0x0003EC44
		private void scheduler_TaskProcessingFinished(object sender, EventArgs e)
		{
			BackgroundInventory.log.Info("Background Inventorying Finished");
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x00040A55 File Offset: 0x0003EC55
		public virtual void Enqueue(int nodeID, int objectID, string objectType, int nodeSettingID, string settings, string inventorySettingName)
		{
			this.scheduler.EnqueueTask(new BackgroundInventory.InventoryTask(nodeID, objectID, objectType, nodeSettingID, settings, inventorySettingName, BackgroundInventory.InventoryTask.InventoryInputSource.InventorySettings));
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x00040A71 File Offset: 0x0003EC71
		public virtual void Enqueue(int nodeID, int nodeSettingID, string settings, string inventorySettingName)
		{
			this.scheduler.EnqueueTask(new BackgroundInventory.InventoryTask(nodeID, -1, string.Empty, nodeSettingID, settings, inventorySettingName, BackgroundInventory.InventoryTask.InventoryInputSource.NodeSettings));
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x00040A8F File Offset: 0x0003EC8F
		public void Start()
		{
			this.scheduler.Start();
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x00040A9C File Offset: 0x0003EC9C
		public void Cancel()
		{
			this.scheduler.Cancel();
		}

		// Token: 0x060008F1 RID: 2289 RVA: 0x0000CC8C File Offset: 0x0000AE8C
		public virtual Node GetNode(int nodeId)
		{
			return NodeBLDAL.GetNode(nodeId);
		}

		// Token: 0x060008F2 RID: 2290 RVA: 0x00040AA9 File Offset: 0x0003ECA9
		public virtual Credential GetCredentialsForNode(Node node)
		{
			return CredentialHelper.ParseCredentialsFromNode(node);
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x00040AB4 File Offset: 0x0003ECB4
		public void DoInventory(BackgroundInventory.InventoryTask task)
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			Node node = this.GetNode(task.NodeID);
			if (node == null || node.PolledStatus != 1)
			{
				BackgroundInventory.log.InfoFormat("Skipping inventorying of Node {0}, status is not UP.", task.NodeID);
				return;
			}
			Credential credentialsForNode = this.GetCredentialsForNode(node);
			GlobalSettingsBase globals = this.snmpGlobals;
			if (node.NodeSubType == 3)
			{
				globals = this.wmiGlobals;
			}
			if (BackgroundInventory.log.IsInfoEnabled)
			{
				BackgroundInventory.log.InfoFormat("Starting inventorying of Node {0}, NeedsInventory = '{1}'", task.NodeID, task.Settings);
			}
			string[] array = task.Settings.Split(new char[]
			{
				':'
			});
			List<string> failedTasks = new List<string>();
			List<string> completedTasks = new List<string>();
			Func<string, bool> <>9__0;
			foreach (string text in array)
			{
				BackgroundInventory.log.InfoFormat("Attempting to inventory with plugin '{0}' on Node {1}", text, task.NodeID);
				if (!this.inventories.ContainsKey(text))
				{
					failedTasks.Add(text);
					if (BackgroundInventory.log.IsErrorEnabled)
					{
						BackgroundInventory.log.ErrorFormat("Unable to inventory '{0}' on Node {1}", text, task.NodeID);
					}
				}
				else
				{
					if (this.IsScheduledTaskCanceled())
					{
						if (BackgroundInventory.log.IsInfoEnabled)
						{
							BackgroundInventory.log.InfoFormat("Inventorying of Node {0} was canceled. ElapsedTime = {1}", task.NodeID, stopwatch.ElapsedMilliseconds);
						}
						stopwatch.Stop();
						return;
					}
					if (!this.IsValidPlugin(this.inventories[text]))
					{
						failedTasks.Add(text);
						if (BackgroundInventory.log.IsErrorEnabled)
						{
							BackgroundInventory.log.ErrorFormat("No plugins are available to execute Inventory '{0}' on Node {1} returned null result", text, task.NodeID);
						}
					}
					else
					{
						InventoryResultBase inventoryResultBase = this.DoInventory(this.inventories[text], task, globals, credentialsForNode, node);
						if (inventoryResultBase == null)
						{
							failedTasks.Add(text);
							if (BackgroundInventory.log.IsErrorEnabled)
							{
								BackgroundInventory.log.ErrorFormat("Inventory '{0}' on Node {1} returned null result", text, task.NodeID);
							}
						}
						else
						{
							if (inventoryResultBase.Outcome == 1)
							{
								bool flag = false;
								try
								{
									flag = this.ProcessResults(this.inventories[text], task, inventoryResultBase, node);
								}
								catch (Exception ex)
								{
									BackgroundInventory.log.Error(string.Format("Inventory '{0}' failed to import results for {1}", task, text), ex);
								}
								if (flag)
								{
									completedTasks.Add(text);
								}
								else
								{
									failedTasks.Add(text);
								}
							}
							else
							{
								failedTasks.Add(text);
								if (inventoryResultBase.Error != null)
								{
									if (BackgroundInventory.log.IsWarnEnabled)
									{
										BackgroundInventory.log.WarnFormat("Inventory '{0}' on Node {1} failed with code {2}", text, task, inventoryResultBase.Error.ErrorCode);
									}
									if (inventoryResultBase.Error.ErrorCode != 31002U)
									{
										IEnumerable<string> source = array;
										Func<string, bool> predicate;
										if ((predicate = <>9__0) == null)
										{
											predicate = (<>9__0 = ((string n) => !completedTasks.Contains(n) && !failedTasks.Contains(n)));
										}
										List<string> list = source.Where(predicate).ToList<string>();
										if (list.Count > 0)
										{
											failedTasks.AddRange(list);
											if (BackgroundInventory.log.IsWarnEnabled)
											{
												BackgroundInventory.log.WarnFormat("Skipping inventory for '{0}' on Node {1}", string.Join(":", list.ToArray()), task.NodeID);
												break;
											}
											break;
										}
									}
								}
								else if (BackgroundInventory.log.IsWarnEnabled)
								{
									BackgroundInventory.log.WarnFormat("Inventory '{0}' on Node {1} failed on unknown error", text, task.NodeID);
								}
							}
							BackgroundInventory.log.InfoFormat("Inventory with plugin '{0}' on Node {1} is completed", text, task.NodeID);
						}
					}
				}
			}
			string settingsForTask = this.GetSettingsForTask(task);
			if ((string.IsNullOrEmpty(settingsForTask) || !settingsForTask.Equals(task.Settings, StringComparison.OrdinalIgnoreCase)) && BackgroundInventory.log.IsInfoEnabled)
			{
				BackgroundInventory.log.InfoFormat("Skipping inventory result processing for {0}, NeedsInventory flag changed. OldValue = '{1}', NewValue = '{2}'.", task, task.Settings, settingsForTask);
				return;
			}
			if (failedTasks.Count == 0)
			{
				if (task.InventoryInput == BackgroundInventory.InventoryTask.InventoryInputSource.NodeSettings)
				{
					NodeSettingsDAL.DeleteSpecificSettings(task.ObjectSettingID, task.InventorySettingName);
				}
				else
				{
					InventorySettingsDAL.DeleteSpecificSettings(task.ObjectSettingID, task.InventorySettingName);
				}
				if (BackgroundInventory.log.IsInfoEnabled)
				{
					BackgroundInventory.log.InfoFormat("Inventorying of {0} completed in {1}ms.", task, stopwatch.ElapsedMilliseconds);
				}
			}
			else if (failedTasks.Count < array.Length)
			{
				string text2 = string.Join(":", failedTasks.ToArray());
				if (task.InventoryInput == BackgroundInventory.InventoryTask.InventoryInputSource.NodeSettings)
				{
					NodeSettingsDAL.UpdateSettingValue(task.ObjectSettingID, task.InventorySettingName, text2);
				}
				else
				{
					InventorySettingsDAL.UpdateSettingValue(task.ObjectSettingID, task.InventorySettingName, text2);
				}
				if (BackgroundInventory.log.IsInfoEnabled)
				{
					BackgroundInventory.log.InfoFormat("Inventorying of {0} partially completed in {1}ms. NeedsInventory updated to '{2}'", task, stopwatch.ElapsedMilliseconds, text2);
				}
			}
			else if (BackgroundInventory.log.IsInfoEnabled)
			{
				BackgroundInventory.log.InfoFormat("Inventorying of {0} failed. Elapsed time {1}ms.", task, stopwatch.ElapsedMilliseconds);
			}
			stopwatch.Stop();
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x00040FF8 File Offset: 0x0003F1F8
		private bool IsValidPlugin(object plugin)
		{
			bool flag = plugin is IBackgroundInventoryPlugin;
			IBackgroundInventoryPlugin2 backgroundInventoryPlugin = plugin as IBackgroundInventoryPlugin2;
			return flag || backgroundInventoryPlugin != null;
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x0004101C File Offset: 0x0003F21C
		private InventoryResultBase DoInventory(object plugin, BackgroundInventory.InventoryTask task, GlobalSettingsBase globals, Credential credentials, Node node)
		{
			IBackgroundInventoryPlugin backgroundInventoryPlugin = plugin as IBackgroundInventoryPlugin;
			if (backgroundInventoryPlugin != null)
			{
				return backgroundInventoryPlugin.DoInventory(globals, credentials, node);
			}
			IBackgroundInventoryPlugin2 backgroundInventoryPlugin2 = plugin as IBackgroundInventoryPlugin2;
			if (backgroundInventoryPlugin2 != null)
			{
				return backgroundInventoryPlugin2.DoInventory(globals, credentials, new BackgroundInventoryObject(node, task.ObjectID, task.ObjectType));
			}
			return null;
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x00041068 File Offset: 0x0003F268
		private bool ProcessResults(object plugin, BackgroundInventory.InventoryTask task, InventoryResultBase result, Node node)
		{
			IBackgroundInventoryPlugin backgroundInventoryPlugin = plugin as IBackgroundInventoryPlugin;
			if (backgroundInventoryPlugin != null)
			{
				return backgroundInventoryPlugin.ProcessResults(result, node);
			}
			IBackgroundInventoryPlugin2 backgroundInventoryPlugin2 = plugin as IBackgroundInventoryPlugin2;
			return backgroundInventoryPlugin2 != null && backgroundInventoryPlugin2.ProcessResults(result, new BackgroundInventoryObject(node, task.ObjectID, task.ObjectType));
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x000410AF File Offset: 0x0003F2AF
		private string GetSettingsForTask(BackgroundInventory.InventoryTask task)
		{
			if (task.InventoryInput != BackgroundInventory.InventoryTask.InventoryInputSource.NodeSettings)
			{
				return InventorySettingsDAL.GetInventorySettings(task.ObjectSettingID, task.InventorySettingName);
			}
			return NodeSettingsDAL.GetNodeSettings(task.ObjectSettingID, task.InventorySettingName);
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x000410DC File Offset: 0x0003F2DC
		private void Dispose(bool disposing)
		{
			if (!this.disposed)
			{
				if (disposing && this.scheduler != null)
				{
					this.scheduler.Dispose();
					this.scheduler = null;
				}
				this.disposed = true;
			}
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x0004110A File Offset: 0x0003F30A
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x0004111C File Offset: 0x0003F31C
		~BackgroundInventory()
		{
			this.Dispose(false);
		}

		// Token: 0x0400028A RID: 650
		private static readonly Log log = new Log();

		// Token: 0x0400028B RID: 651
		private QueuedTaskScheduler<BackgroundInventory.InventoryTask> scheduler;

		// Token: 0x0400028C RID: 652
		private IPollersDAL pollersDAL = new PollersDAL();

		// Token: 0x0400028D RID: 653
		private Dictionary<string, object> inventories;

		// Token: 0x0400028E RID: 654
		private SnmpGlobalSettings snmpGlobals;

		// Token: 0x0400028F RID: 655
		private WmiGlobalSettings wmiGlobals;

		// Token: 0x04000290 RID: 656
		private bool disposed;

		// Token: 0x020001B1 RID: 433
		public class InventoryTask
		{
			// Token: 0x06000CB7 RID: 3255 RVA: 0x0004C19D File Offset: 0x0004A39D
			public InventoryTask(int nodeID, int objectID, string objectType, int objectSettingID, string settings, string inventorySettingName, BackgroundInventory.InventoryTask.InventoryInputSource inventoryInputSource)
			{
				this.NodeID = nodeID;
				this.ObjectSettingID = objectSettingID;
				this.Settings = settings;
				this.InventorySettingName = inventorySettingName;
				this.ObjectID = objectID;
				this.ObjectType = objectType;
				this.InventoryInput = inventoryInputSource;
			}

			// Token: 0x06000CB8 RID: 3256 RVA: 0x0004C1DC File Offset: 0x0004A3DC
			public override string ToString()
			{
				return string.Format("NodeID = {0}, NodeSettingID = {1}, Settings = {2}, InventorySettingName = {3}, ObjectID = {4}, ObjectType = {5}", new object[]
				{
					this.NodeID,
					this.ObjectSettingID,
					this.Settings,
					this.InventorySettingName,
					this.ObjectID,
					this.ObjectType
				});
			}

			// Token: 0x04000570 RID: 1392
			public int NodeID;

			// Token: 0x04000571 RID: 1393
			public int ObjectSettingID;

			// Token: 0x04000572 RID: 1394
			public string Settings;

			// Token: 0x04000573 RID: 1395
			public string InventorySettingName;

			// Token: 0x04000574 RID: 1396
			public int ObjectID;

			// Token: 0x04000575 RID: 1397
			public string ObjectType;

			// Token: 0x04000576 RID: 1398
			public BackgroundInventory.InventoryTask.InventoryInputSource InventoryInput;

			// Token: 0x020001DA RID: 474
			public enum InventoryInputSource
			{
				// Token: 0x040005E1 RID: 1505
				NodeSettings,
				// Token: 0x040005E2 RID: 1506
				InventorySettings
			}
		}
	}
}
