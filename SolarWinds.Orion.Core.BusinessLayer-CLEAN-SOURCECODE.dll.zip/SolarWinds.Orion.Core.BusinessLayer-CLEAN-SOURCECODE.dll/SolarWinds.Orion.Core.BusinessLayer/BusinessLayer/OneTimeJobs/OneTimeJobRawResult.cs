﻿using System;
using System.IO;

namespace SolarWinds.Orion.Core.BusinessLayer.OneTimeJobs
{
	// Token: 0x0200006D RID: 109
	public struct OneTimeJobRawResult : IDisposable
	{
		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060005AE RID: 1454 RVA: 0x00022AA8 File Offset: 0x00020CA8
		// (set) Token: 0x060005AF RID: 1455 RVA: 0x00022AB0 File Offset: 0x00020CB0
		public bool Success { get; set; }

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060005B0 RID: 1456 RVA: 0x00022AB9 File Offset: 0x00020CB9
		// (set) Token: 0x060005B1 RID: 1457 RVA: 0x00022AC1 File Offset: 0x00020CC1
		public string Error { get; set; }

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060005B2 RID: 1458 RVA: 0x00022ACA File Offset: 0x00020CCA
		// (set) Token: 0x060005B3 RID: 1459 RVA: 0x00022AD2 File Offset: 0x00020CD2
		public Stream JobResultStream { get; set; }

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x060005B4 RID: 1460 RVA: 0x00022ADB File Offset: 0x00020CDB
		// (set) Token: 0x060005B5 RID: 1461 RVA: 0x00022AE3 File Offset: 0x00020CE3
		public Exception ExceptionFromJob { get; set; }

		// Token: 0x060005B6 RID: 1462 RVA: 0x00022AEC File Offset: 0x00020CEC
		public void Dispose()
		{
			Stream jobResultStream = this.JobResultStream;
			if (jobResultStream == null)
			{
				return;
			}
			jobResultStream.Dispose();
		}
	}
}
