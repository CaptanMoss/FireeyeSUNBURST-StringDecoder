﻿using System;
using SolarWinds.JobEngine;
using SolarWinds.JobEngine.Security;
using SolarWinds.Orion.Core.BusinessLayer.BL;

namespace SolarWinds.Orion.Core.BusinessLayer.OneTimeJobs
{
	// Token: 0x0200006B RID: 107
	public interface IOneTimeJobService : IDisposable
	{
		// Token: 0x0600059D RID: 1437
		void Start(string listenerUri);

		// Token: 0x0600059E RID: 1438
		OneTimeJobResult<T> ExecuteJobAndGetResult<T>(int engineId, JobDescription jobDescription, CredentialBase jobCredential, JobResultDataFormatType resultDataFormat, string jobType) where T : class, new();

		// Token: 0x0600059F RID: 1439
		OneTimeJobResult<T> ExecuteJobAndGetResult<T>(string engineName, JobDescription jobDescription, CredentialBase jobCredential, JobResultDataFormatType resultDataFormat, string jobType) where T : class, new();
	}
}
