﻿using System;
using SolarWinds.JobEngine;
using SolarWinds.JobEngine.Security;

namespace SolarWinds.Orion.Core.BusinessLayer.OneTimeJobs
{
	// Token: 0x0200006A RID: 106
	public interface IOneTimeJobManager
	{
		// Token: 0x0600059B RID: 1435
		OneTimeJobRawResult ExecuteJob(JobDescription jobDescription, CredentialBase jobCredential = null);

		// Token: 0x0600059C RID: 1436
		void SetListenerUri(string listenerUri);
	}
}
