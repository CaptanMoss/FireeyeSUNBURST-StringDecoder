﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.OneTimeJobs
{
	// Token: 0x0200006E RID: 110
	public class OneTimeJobResult<T>
	{
		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x060005B7 RID: 1463 RVA: 0x00022AFE File Offset: 0x00020CFE
		// (set) Token: 0x060005B8 RID: 1464 RVA: 0x00022B06 File Offset: 0x00020D06
		public bool Success { get; set; }

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x060005B9 RID: 1465 RVA: 0x00022B0F File Offset: 0x00020D0F
		// (set) Token: 0x060005BA RID: 1466 RVA: 0x00022B17 File Offset: 0x00020D17
		public string Message { get; set; }

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x060005BB RID: 1467 RVA: 0x00022B20 File Offset: 0x00020D20
		// (set) Token: 0x060005BC RID: 1468 RVA: 0x00022B28 File Offset: 0x00020D28
		public T Value { get; set; }
	}
}
