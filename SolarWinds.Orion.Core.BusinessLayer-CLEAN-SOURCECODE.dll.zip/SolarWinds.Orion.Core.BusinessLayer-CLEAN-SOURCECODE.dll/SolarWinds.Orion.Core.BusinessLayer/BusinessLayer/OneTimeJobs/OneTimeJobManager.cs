﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Security.Cryptography;
using System.ServiceModel;
using System.Threading;
using SolarWinds.Common.IO;
using SolarWinds.JobEngine;
using SolarWinds.JobEngine.Security;
using SolarWinds.Logging;
using SolarWinds.Orion.Core.Common.JobEngine;
using SolarWinds.Orion.Core.Strings;

namespace SolarWinds.Orion.Core.BusinessLayer.OneTimeJobs
{
	// Token: 0x0200006C RID: 108
	[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, IncludeExceptionDetailInFaults = true, AutomaticSessionShutdown = true, ConcurrencyMode = ConcurrencyMode.Multiple)]
	public class OneTimeJobManager : JobSchedulerEventServicev2, IOneTimeJobManager
	{
		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060005A0 RID: 1440 RVA: 0x00022418 File Offset: 0x00020618
		// (remove) Token: 0x060005A1 RID: 1441 RVA: 0x00022450 File Offset: 0x00020650
		public event EventHandler<EventArgs> JobStarted;

		// Token: 0x060005A2 RID: 1442 RVA: 0x00022485 File Offset: 0x00020685
		public OneTimeJobManager() : this(null)
		{
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x0002248E File Offset: 0x0002068E
		public OneTimeJobManager(IServiceStateProvider parent) : this(parent, () => JobScheduler.GetLocalInstance(), TimeSpan.FromSeconds(10.0))
		{
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x000224C4 File Offset: 0x000206C4
		internal OneTimeJobManager(IServiceStateProvider parent, Func<IJobSchedulerHelper> jobSchedulerHelperFactory, TimeSpan jobTimeoutTolerance) : base(parent)
		{
			this.jobSchedulerHelperFactory = jobSchedulerHelperFactory;
			this.jobTimeoutTolerance = jobTimeoutTolerance;
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x0002251B File Offset: 0x0002071B
		public void SetListenerUri(string listenerUri)
		{
			this.listenerUri = listenerUri;
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00022524 File Offset: 0x00020724
		private RSACryptoServiceProvider CreateCrypoService()
		{
			if (string.IsNullOrEmpty(this.schedulerPublicKey))
			{
				using (IJobSchedulerHelper jobSchedulerHelper = this.jobSchedulerHelperFactory())
				{
					this.schedulerPublicKey = jobSchedulerHelper.GetPublicKey();
				}
			}
			RSACryptoServiceProvider rsacryptoServiceProvider = new RSACryptoServiceProvider();
			rsacryptoServiceProvider.FromXmlString(this.schedulerPublicKey);
			return rsacryptoServiceProvider;
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00022584 File Offset: 0x00020784
		private Credential EncryptCredentials(CredentialBase creds)
		{
			if (creds == null)
			{
				return Credential.Empty;
			}
			Credential result;
			using (RSACryptoServiceProvider rsacryptoServiceProvider = this.CreateCrypoService())
			{
				result = new Credential(creds, rsacryptoServiceProvider);
			}
			return result;
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x000225C8 File Offset: 0x000207C8
		private Guid SubmitScheduledJobToScheduler(ScheduledJob job)
		{
			Guid result;
			using (IJobSchedulerHelper jobSchedulerHelper = this.jobSchedulerHelperFactory())
			{
				OneTimeJobManager.Logger.Debug("Adding new job to Job Engine");
				result = jobSchedulerHelper.AddJob(job);
			}
			return result;
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x00022618 File Offset: 0x00020818
		public OneTimeJobRawResult ExecuteJob(JobDescription jobDescription, CredentialBase jobCredential = null)
		{
			if (this.listenerUri == string.Empty)
			{
				JobSchedulerEventServicev2.log.Error("ListenerUri remains uninitialized");
				OneTimeJobRawResult result = new OneTimeJobRawResult
				{
					Success = false,
					Error = Resources.TestErrorJobFailed
				};
				return result;
			}
			if (jobCredential != null)
			{
				jobDescription.Credential = this.EncryptCredentials(jobCredential);
			}
			if (jobDescription.SupportedRoles == null)
			{
				jobDescription.SupportedRoles = 7;
			}
			ScheduledJob job = new ScheduledJob
			{
				NotificationAddress = this.listenerUri,
				State = "CoreOneTimeJob",
				RunOnce = true,
				IsOneShot = true,
				Job = jobDescription
			};
			Guid guid;
			try
			{
				guid = this.SubmitScheduledJobToScheduler(job);
				OneTimeJobManager.Logger.DebugFormat("Job {0} scheduled", guid);
			}
			catch (Exception ex)
			{
				OneTimeJobManager.Logger.ErrorFormat("Failed to submit job: {0}", ex);
				OneTimeJobRawResult result = default(OneTimeJobRawResult);
				result.Success = false;
				result.Error = Resources.TestErrorJobFailed;
				result.ExceptionFromJob = ex;
				return result;
			}
			TimeSpan timeSpan = jobDescription.Timeout.Add(this.jobTimeoutTolerance);
			OneTimeJobManager.PendingJobItem pendingJobItem = new OneTimeJobManager.PendingJobItem();
			this.pendingJobs[guid] = pendingJobItem;
			if (this.JobStarted != null)
			{
				this.JobStarted(this, new OneTimeJobManager.JobStartedEventArgs(guid));
			}
			OneTimeJobRawResult result2;
			if (pendingJobItem.WaitHandle.WaitOne(timeSpan))
			{
				result2 = pendingJobItem.RawResult;
			}
			else
			{
				OneTimeJobManager.Logger.ErrorFormat("No result from job {0} received before timeout ({1})", guid, timeSpan);
				result2 = new OneTimeJobRawResult
				{
					Success = false,
					Error = Resources.TestErrorTimeout
				};
			}
			this.pendingJobs.TryRemove(guid, out pendingJobItem);
			return result2;
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x000227D0 File Offset: 0x000209D0
		protected override void ProcessJobProgress(JobProgress jobProgress)
		{
			OneTimeJobManager.Logger.InfoFormat("Progress from job {0}: {1}", jobProgress.JobId, jobProgress.Progress);
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x000227F4 File Offset: 0x000209F4
		protected override void ProcessJobFailure(FinishedJobInfo jobResult)
		{
			Guid scheduledJobId = jobResult.ScheduledJobId;
			OneTimeJobManager.PendingJobItem pendingJobItem;
			if (this.pendingJobs.TryGetValue(scheduledJobId, out pendingJobItem))
			{
				OneTimeJobRawResult result = new OneTimeJobRawResult
				{
					Success = false,
					Error = Resources.TestErrorJobFailed
				};
				OneTimeJobManager.Logger.WarnFormat("Job {0} failed with error: {1}", scheduledJobId, jobResult.Result.Error);
				pendingJobItem.Done(result);
				return;
			}
			OneTimeJobManager.Logger.ErrorFormat("Failure of unknown job {0} received", scheduledJobId);
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00022874 File Offset: 0x00020A74
		protected override void ProcessJobResult(FinishedJobInfo jobResult)
		{
			Guid scheduledJobId = jobResult.ScheduledJobId;
			OneTimeJobManager.PendingJobItem pendingJobItem;
			if (this.pendingJobs.TryGetValue(scheduledJobId, out pendingJobItem))
			{
				OneTimeJobRawResult result = default(OneTimeJobRawResult);
				try
				{
					result.Success = (jobResult.Result.State == 6 && string.IsNullOrEmpty(jobResult.Result.Error));
					if (jobResult.Result.IsResultStreamed)
					{
						using (IJobSchedulerHelper jobSchedulerHelper = this.jobSchedulerHelperFactory())
						{
							using (Stream jobResultStream = jobSchedulerHelper.GetJobResultStream(jobResult.Result.JobId, "JobResult"))
							{
								result.JobResultStream = new DynamicStream();
								jobResultStream.CopyTo(result.JobResultStream);
								result.JobResultStream.Position = 0L;
							}
							jobSchedulerHelper.DeleteJobResult(jobResult.Result.JobId);
							goto IL_100;
						}
					}
					if (jobResult.Result.Output != null && jobResult.Result.Output.Length != 0)
					{
						result.JobResultStream = new MemoryStream(jobResult.Result.Output);
					}
					IL_100:
					result.Error = jobResult.Result.Error;
					OneTimeJobManager.Logger.InfoFormat("Result of one time job {0} received", scheduledJobId);
				}
				catch (Exception ex)
				{
					result.Success = false;
					result.Error = Resources.TestErrorInvalidResult;
					OneTimeJobManager.Logger.ErrorFormat("Failed to process result of one time job {0}: {1}", scheduledJobId, ex);
				}
				pendingJobItem.Done(result);
				return;
			}
			OneTimeJobManager.Logger.ErrorFormat("Result of unknown job {0} received", scheduledJobId);
			if (jobResult.Result != null && jobResult.Result.IsResultStreamed)
			{
				using (IJobSchedulerHelper jobSchedulerHelper2 = this.jobSchedulerHelperFactory())
				{
					jobSchedulerHelper2.DeleteJobResult(jobResult.Result.JobId);
				}
			}
		}

		// Token: 0x040001A7 RID: 423
		private static readonly Log Logger = new Log();

		// Token: 0x040001A8 RID: 424
		private string schedulerPublicKey = string.Empty;

		// Token: 0x040001A9 RID: 425
		private string listenerUri = string.Empty;

		// Token: 0x040001AA RID: 426
		private ConcurrentDictionary<Guid, OneTimeJobManager.PendingJobItem> pendingJobs = new ConcurrentDictionary<Guid, OneTimeJobManager.PendingJobItem>();

		// Token: 0x040001AB RID: 427
		private readonly Func<IJobSchedulerHelper> jobSchedulerHelperFactory;

		// Token: 0x040001AC RID: 428
		private readonly TimeSpan jobTimeoutTolerance = TimeSpan.FromSeconds(10.0);

		// Token: 0x02000161 RID: 353
		public class JobStartedEventArgs : EventArgs
		{
			// Token: 0x17000149 RID: 329
			// (get) Token: 0x06000BA8 RID: 2984 RVA: 0x0004A488 File Offset: 0x00048688
			// (set) Token: 0x06000BA9 RID: 2985 RVA: 0x0004A490 File Offset: 0x00048690
			public Guid JobId { get; private set; }

			// Token: 0x06000BAA RID: 2986 RVA: 0x0004A499 File Offset: 0x00048699
			public JobStartedEventArgs(Guid jobId)
			{
				this.JobId = jobId;
			}
		}

		// Token: 0x02000162 RID: 354
		private class PendingJobItem
		{
			// Token: 0x1700014A RID: 330
			// (get) Token: 0x06000BAB RID: 2987 RVA: 0x0004A4A8 File Offset: 0x000486A8
			public ManualResetEvent WaitHandle
			{
				get
				{
					return this.waitHandle;
				}
			}

			// Token: 0x1700014B RID: 331
			// (get) Token: 0x06000BAC RID: 2988 RVA: 0x0004A4B0 File Offset: 0x000486B0
			// (set) Token: 0x06000BAD RID: 2989 RVA: 0x0004A4B8 File Offset: 0x000486B8
			public OneTimeJobRawResult RawResult { get; private set; }

			// Token: 0x06000BAE RID: 2990 RVA: 0x0004A4C1 File Offset: 0x000486C1
			public void Done(OneTimeJobRawResult result)
			{
				this.RawResult = result;
				this.waitHandle.Set();
			}

			// Token: 0x04000474 RID: 1140
			private ManualResetEvent waitHandle = new ManualResetEvent(false);
		}
	}
}
