﻿using System;
using SolarWinds.JobEngine;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x02000026 RID: 38
	public interface IJobSchedulerHelper : IJobScheduler, IDisposable
	{
	}
}
