﻿using System;
using SolarWinds.Orion.Core.Common.Models;
using SolarWinds.Orion.Core.Common.Models.Thresholds;

namespace SolarWinds.Orion.Core.BusinessLayer.Thresholds
{
	// Token: 0x02000050 RID: 80
	internal class HistogramCalculator
	{
		// Token: 0x060004DC RID: 1244 RVA: 0x0001ECFC File Offset: 0x0001CEFC
		public StatisticalDataHistogram[] CreateHistogram(StatisticalData[] data, TimeFrame[] timeFrames, int intervalsCount)
		{
			ThresholdMinMaxValue minMax = new MinMaxCalculator().Calculate(data);
			return HistogramCalculator.CreateBucketsAndHistogram(data, timeFrames, intervalsCount, minMax);
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x0001ED20 File Offset: 0x0001CF20
		public StatisticalDataHistogram[] CreateHistogramWithScaledInterval(StatisticalData[] data, TimeFrame[] timeFrames, int intervalsCount, Type dataType)
		{
			ThresholdMinMaxValue thresholdMinMaxValue = new MinMaxCalculator().Calculate(data);
			if (dataType != null && dataType == typeof(int))
			{
				int num = (int)(thresholdMinMaxValue.Max - thresholdMinMaxValue.Min);
				if (num == 0)
				{
					num = 1;
				}
				intervalsCount = Math.Min(num, intervalsCount);
			}
			return HistogramCalculator.CreateBucketsAndHistogram(data, timeFrames, intervalsCount, thresholdMinMaxValue);
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x0001ED7C File Offset: 0x0001CF7C
		private static StatisticalDataHistogram[] CreateBucketsAndHistogram(StatisticalData[] data, TimeFrame[] timeFrames, int intervalsCount, ThresholdMinMaxValue minMax)
		{
			Bucket[] array = new Bucketizer().CreateBuckets(intervalsCount, minMax);
			StatisticalDataHistogram[] histograms = HistogramCalculator.CreateHistogramForTimeFrames(timeFrames, array.Length);
			histograms = HistogramCalculator.CreateHistogramsPointsFromBuckets(histograms, array);
			return HistogramCalculator.CalculatePointsFrequencyFromStatistics(data, histograms);
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0001EDB4 File Offset: 0x0001CFB4
		private static StatisticalDataHistogram[] CalculatePointsFrequencyFromStatistics(StatisticalData[] values, StatisticalDataHistogram[] histograms)
		{
			foreach (StatisticalData statisticalData in values)
			{
				for (int j = 0; j < histograms.Length; j++)
				{
					if (histograms[j].TimeFrame.IsInTimeFrame(statisticalData.Date))
					{
						HistogramCalculator.IncrementPointFrequency(histograms[j], statisticalData.Value);
					}
				}
			}
			return histograms;
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0001EE08 File Offset: 0x0001D008
		private static void IncrementPointFrequency(StatisticalDataHistogram histograms, double value)
		{
			for (int i = 0; i < histograms.DataPoints.Length; i++)
			{
				if (histograms.DataPoints[i].EndValue >= value)
				{
					HistogramDataPoint histogramDataPoint = histograms.DataPoints[i];
					uint frequency = histogramDataPoint.Frequency;
					histogramDataPoint.Frequency = frequency + 1U;
					return;
				}
			}
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x0001EE50 File Offset: 0x0001D050
		private static StatisticalDataHistogram[] CreateHistogramsPointsFromBuckets(StatisticalDataHistogram[] histograms, Bucket[] buckets)
		{
			for (int i = 0; i < buckets.Length; i++)
			{
				for (int j = 0; j < histograms.Length; j++)
				{
					histograms[j].DataPoints[i] = new HistogramDataPoint(buckets[i].MinValue, buckets[i].MaxValue);
				}
			}
			return histograms;
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x0001EE9C File Offset: 0x0001D09C
		private static StatisticalDataHistogram[] CreateHistogramForTimeFrames(TimeFrame[] timeFrames, int bucketsCount)
		{
			StatisticalDataHistogram[] array = new StatisticalDataHistogram[timeFrames.Length];
			for (int i = 0; i < timeFrames.Length; i++)
			{
				array[i] = new StatisticalDataHistogram(timeFrames[i], bucketsCount);
			}
			return array;
		}
	}
}
