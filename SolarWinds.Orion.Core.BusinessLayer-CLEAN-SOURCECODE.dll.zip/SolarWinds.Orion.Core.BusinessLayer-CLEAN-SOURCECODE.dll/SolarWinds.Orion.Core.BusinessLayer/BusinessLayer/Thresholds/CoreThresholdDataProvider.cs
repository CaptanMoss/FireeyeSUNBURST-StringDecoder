﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data;
using System.Data.SqlClient;
using SolarWinds.Orion.Common;
using SolarWinds.Orion.Core.Common.Models.Thresholds;
using SolarWinds.Orion.Core.Common.Thresholds;

namespace SolarWinds.Orion.Core.BusinessLayer.Thresholds
{
	// Token: 0x0200004D RID: 77
	[Export(typeof(ThresholdDataProvider))]
	public class CoreThresholdDataProvider : ThresholdDataProvider
	{
		// Token: 0x060004BD RID: 1213 RVA: 0x0001DE8A File Offset: 0x0001C08A
		public override IEnumerable<string> GetKnownThresholdNames()
		{
			yield return "Nodes.Stats.PercentMemoryUsed";
			yield return "Nodes.Stats.ResponseTime";
			yield return "Nodes.Stats.PercentLoss";
			yield return "Nodes.Stats.CpuLoad";
			yield return "Volumes.Stats.PercentDiskUsed";
			yield break;
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x0001DE93 File Offset: 0x0001C093
		public override Type GetThresholdDataProcessor()
		{
			return typeof(CoreThresholdProcessor);
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0001DEA0 File Offset: 0x0001C0A0
		public override StatisticalTableMetadata GetStatisticalTableMetadata(string thresholdName)
		{
			if (CoreThresholdDataProvider.IsResponseTime(thresholdName))
			{
				return new StatisticalTableMetadata
				{
					TableName = "ResponseTime_Statistics",
					InstanceIdColumnName = "NodeID",
					MeanColumnName = "AvgResponseTimeMean",
					StdDevColumnName = "AvgResponseTimeStDev",
					MinColumnName = "AvgResponseTimeMin",
					MaxColumnName = "AvgResponseTimeMax",
					CountColumnName = "AvgResponseTimeCount",
					MinDateTime = "MinDateTime",
					MaxDateTime = "MaxDateTime",
					Timestamp = "Timestamp"
				};
			}
			if (CoreThresholdDataProvider.IsPercentLoss(thresholdName))
			{
				return new StatisticalTableMetadata
				{
					TableName = "ResponseTime_Statistics",
					InstanceIdColumnName = "NodeID",
					MeanColumnName = "PercentLossMean",
					StdDevColumnName = "PercentLossStDev",
					MinColumnName = "PercentLossMin",
					MaxColumnName = "PercentLossMax",
					CountColumnName = "PercentLossCount",
					MinDateTime = "MinDateTime",
					MaxDateTime = "MaxDateTime",
					Timestamp = "Timestamp"
				};
			}
			if (CoreThresholdDataProvider.IsCpuLoad(thresholdName))
			{
				return new StatisticalTableMetadata
				{
					TableName = "CPULoad_Statistics",
					InstanceIdColumnName = "NodeID",
					MeanColumnName = "AvgLoadMean",
					StdDevColumnName = "AvgLoadStDev",
					MinColumnName = "AvgLoadMin",
					MaxColumnName = "AvgLoadMax",
					CountColumnName = "AvgLoadCount",
					MinDateTime = "MinDateTime",
					MaxDateTime = "MaxDateTime",
					Timestamp = "Timestamp"
				};
			}
			if (CoreThresholdDataProvider.IsPercentMemoryUsage(thresholdName))
			{
				return new StatisticalTableMetadata
				{
					TableName = "CPULoad_Statistics",
					InstanceIdColumnName = "NodeID",
					MeanColumnName = "AvgPercentMemoryUsedMean",
					StdDevColumnName = "AvgPercentMemoryUsedStDev",
					MinColumnName = "AvgPercentMemoryUsedMin",
					MaxColumnName = "AvgPercentMemoryUsedMax",
					CountColumnName = "AvgPercentMemoryUsedCount",
					MinDateTime = "MinDateTime",
					MaxDateTime = "MaxDateTime",
					Timestamp = "Timestamp"
				};
			}
			if (CoreThresholdDataProvider.IsPercentDiskUsed(thresholdName))
			{
				return new StatisticalTableMetadata
				{
					TableName = "VolumeUsage_Statistics",
					InstanceIdColumnName = "VolumeID",
					MeanColumnName = "PercentDiskUsedMean",
					StdDevColumnName = "PercentDiskUsedStDev",
					MinColumnName = "PercentDiskUsedMin",
					MaxColumnName = "PercentDiskUsedMax",
					CountColumnName = "PercentDiskUsedCount",
					MinDateTime = "MinDateTime",
					MaxDateTime = "MaxDateTime",
					Timestamp = "Timestamp"
				};
			}
			throw new InvalidOperationException(string.Format("Threshold name '{0}' is not supported.", thresholdName));
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0001E12C File Offset: 0x0001C32C
		public override ThresholdMinMaxValue GetThresholdMinMaxValues(string thresholdName, int instanceId)
		{
			if (CoreThresholdDataProvider.IsResponseTime(thresholdName))
			{
				return new ThresholdMinMaxValue
				{
					Min = 0.0,
					Max = 100000.0,
					DataType = typeof(int)
				};
			}
			if (CoreThresholdDataProvider.IsPercentLoss(thresholdName))
			{
				return new ThresholdMinMaxValue
				{
					Min = 0.0,
					Max = 100.0,
					DataType = typeof(int)
				};
			}
			if (CoreThresholdDataProvider.IsCpuLoad(thresholdName))
			{
				return new ThresholdMinMaxValue
				{
					Min = 0.0,
					Max = 100.0,
					DataType = typeof(int)
				};
			}
			if (CoreThresholdDataProvider.IsPercentMemoryUsage(thresholdName))
			{
				return new ThresholdMinMaxValue
				{
					Min = 0.0,
					Max = 100.0,
					DataType = typeof(double)
				};
			}
			if (CoreThresholdDataProvider.IsPercentDiskUsed(thresholdName))
			{
				return new ThresholdMinMaxValue
				{
					Min = 0.0,
					Max = 100.0,
					DataType = typeof(int)
				};
			}
			throw new InvalidOperationException(string.Format("Threshold name '{0}' is not supported.", thresholdName));
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0001E278 File Offset: 0x0001C478
		public override StatisticalData[] GetStatisticalData(string thresholdName, int instanceId, DateTime minDateTimeInUtc, DateTime maxDateTimeInUtc)
		{
			string text;
			if (CoreThresholdDataProvider.IsResponseTime(thresholdName))
			{
				text = "SELECT AvgResponseTime, [TimeStamp] FROM ResponseTime_CS_Detail WHERE NodeID = @nodeId AND ([TimeStamp] between @start and @end)";
			}
			else if (CoreThresholdDataProvider.IsPercentLoss(thresholdName))
			{
				text = "SELECT PercentLoss, [TimeStamp] FROM ResponseTime_CS_Detail WHERE NodeID = @nodeId AND ([TimeStamp] between @start and @end)";
			}
			else if (CoreThresholdDataProvider.IsCpuLoad(thresholdName))
			{
				text = "SELECT AvgLoad, [TimeStamp] FROM CPULoad_CS_Detail WHERE NodeID = @nodeId AND ([TimeStamp] between @start and @end)";
			}
			else if (CoreThresholdDataProvider.IsPercentMemoryUsage(thresholdName))
			{
				text = "SELECT PercentMemoryUsed, [TimeStamp] FROM CPULoad_CS_Detail WHERE NodeID = @nodeId AND ([TimeStamp] between @start and @end)";
			}
			else
			{
				if (!CoreThresholdDataProvider.IsPercentDiskUsed(thresholdName))
				{
					throw new InvalidOperationException(string.Format("Threshold name '{0}' is not supported.", thresholdName));
				}
				text = "SELECT PercentDiskUsed, [TimeStamp] FROM VolumeUsage_CS_Detail WHERE VolumeID = @instanceId AND ([TimeStamp] between @start and @end)";
			}
			List<StatisticalData> list = new List<StatisticalData>();
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlCommand textCommand = SqlHelper.GetTextCommand(text))
				{
					textCommand.Parameters.AddWithValue("instanceId", instanceId).SqlDbType = SqlDbType.Int;
					textCommand.Parameters.AddWithValue("start", minDateTimeInUtc.ToLocalTime()).SqlDbType = SqlDbType.DateTime;
					textCommand.Parameters.AddWithValue("end", maxDateTimeInUtc.ToLocalTime()).SqlDbType = SqlDbType.DateTime;
					using (IDataReader dataReader = SqlHelper.ExecuteReader(textCommand, sqlConnection))
					{
						while (dataReader.Read())
						{
							if (!dataReader.IsDBNull(0) && !dataReader.IsDBNull(1))
							{
								list.Add(new StatisticalData
								{
									Value = Convert.ToDouble(dataReader[0]),
									Date = DatabaseFunctions.GetDateTime(dataReader, 1, DateTimeKind.Local)
								});
							}
						}
					}
				}
			}
			return list.ToArray();
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0001E400 File Offset: 0x0001C600
		public override string GetThresholdInstanceName(string thresholdName, int instanceId)
		{
			string text;
			if (CoreThresholdDataProvider.IsPercentDiskUsed(thresholdName))
			{
				text = "SELECT [Caption] FROM [Volumes] WHERE [VolumeId] = @instanceId";
			}
			else
			{
				text = "SELECT [Caption] FROM [NodesData] WHERE [NodeId] = @instanceId";
			}
			string result;
			using (SqlConnection sqlConnection = DatabaseFunctions.CreateConnection())
			{
				using (SqlCommand textCommand = SqlHelper.GetTextCommand(text))
				{
					textCommand.Connection = sqlConnection;
					textCommand.Parameters.AddWithValue("instanceId", instanceId).SqlDbType = SqlDbType.Int;
					object obj = textCommand.ExecuteScalar();
					if (obj != null && obj != DBNull.Value)
					{
						result = obj.ToString();
					}
					else
					{
						result = string.Empty;
					}
				}
			}
			return result;
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0001E4AC File Offset: 0x0001C6AC
		public override string GetStatisticalDataChartName(string thresholdName)
		{
			if (CoreThresholdDataProvider.IsResponseTime(thresholdName))
			{
				return "MinMaxAvgRT";
			}
			if (CoreThresholdDataProvider.IsPercentLoss(thresholdName))
			{
				return "PacketLossLine";
			}
			if (CoreThresholdDataProvider.IsCpuLoad(thresholdName))
			{
				return "CiscoMMAvgCPULoad";
			}
			if (CoreThresholdDataProvider.IsPercentMemoryUsage(thresholdName))
			{
				return "HostAvgPercentMemoryUsed";
			}
			if (CoreThresholdDataProvider.IsPercentDiskUsed(thresholdName))
			{
				return "PercentDiskUsage";
			}
			throw new InvalidOperationException(string.Format("Threshold name '{0}' is not supported.", thresholdName));
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0001E50F File Offset: 0x0001C70F
		private static bool IsResponseTime(string thresholdName)
		{
			return string.Equals(thresholdName, "Nodes.Stats.ResponseTime", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0001E51D File Offset: 0x0001C71D
		private static bool IsPercentLoss(string thresholdName)
		{
			return string.Equals(thresholdName, "Nodes.Stats.PercentLoss", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0001E52B File Offset: 0x0001C72B
		private static bool IsCpuLoad(string thresholdName)
		{
			return string.Equals(thresholdName, "Nodes.Stats.CpuLoad", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0001E539 File Offset: 0x0001C739
		private static bool IsPercentMemoryUsage(string thresholdName)
		{
			return string.Equals(thresholdName, "Nodes.Stats.PercentMemoryUsed", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x0001E547 File Offset: 0x0001C747
		private static bool IsPercentDiskUsed(string thresholdName)
		{
			return string.Equals(thresholdName, "Volumes.Stats.PercentDiskUsed", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x0400014A RID: 330
		private const string PercentMemoryUsedName = "Nodes.Stats.PercentMemoryUsed";

		// Token: 0x0400014B RID: 331
		private const string ResponseTimeName = "Nodes.Stats.ResponseTime";

		// Token: 0x0400014C RID: 332
		private const string PercentLossName = "Nodes.Stats.PercentLoss";

		// Token: 0x0400014D RID: 333
		private const string CpuLoadName = "Nodes.Stats.CpuLoad";

		// Token: 0x0400014E RID: 334
		private const string PercentDiskUsedName = "Volumes.Stats.PercentDiskUsed";

		// Token: 0x0400014F RID: 335
		private const string PercentMemoryUsedChartName = "HostAvgPercentMemoryUsed";

		// Token: 0x04000150 RID: 336
		private const string ResponseTimeChartName = "MinMaxAvgRT";

		// Token: 0x04000151 RID: 337
		private const string PercentLossChartName = "PacketLossLine";

		// Token: 0x04000152 RID: 338
		private const string CpuLoadChartName = "CiscoMMAvgCPULoad";

		// Token: 0x04000153 RID: 339
		private const string PercentDiskUsedChartName = "PercentDiskUsage";
	}
}
