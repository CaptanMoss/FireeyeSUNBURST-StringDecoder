﻿using System;
using System.Collections.Generic;
using System.Data;
using SolarWinds.InformationService.Contract2;
using SolarWinds.Orion.Core.Common;
using SolarWinds.Orion.Core.Common.Indications;
using SolarWinds.Orion.Core.Common.InformationService;
using SolarWinds.Orion.Core.Common.Models.Thresholds;
using SolarWinds.Orion.Core.Common.Notification;
using SolarWinds.Orion.PubSub;
using SolarWinds.Orion.Swis.PubSub;

namespace SolarWinds.Orion.Core.BusinessLayer.Thresholds
{
	// Token: 0x02000055 RID: 85
	internal class ThresholdIndicator : IThresholdIndicator
	{
		// Token: 0x060004EF RID: 1263 RVA: 0x0001F050 File Offset: 0x0001D250
		public ThresholdIndicator() : this(new InformationServiceProxyFactory(), PublisherClient.Instance)
		{
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x0001F062 File Offset: 0x0001D262
		public ThresholdIndicator(IInformationServiceProxyFactory swisFactory, IPublisherManager publishManager)
		{
			if (swisFactory == null)
			{
				throw new ArgumentNullException("swisFactory");
			}
			this._swisFactory = swisFactory;
			if (publishManager == null)
			{
				throw new ArgumentNullException("publishManager");
			}
			this._publishManager = publishManager;
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x0001F098 File Offset: 0x0001D298
		private ThresholdIndicator.InstanceInformation GetInstanceInformation(string entityType, int instanceId)
		{
			if (string.IsNullOrEmpty(entityType) || instanceId == 0)
			{
				return null;
			}
			ThresholdIndicator.InstanceInformation instanceInformation = new ThresholdIndicator.InstanceInformation();
			using (IInformationServiceProxy2 informationServiceProxy = this._swisFactory.CreateConnection())
			{
				DataTable dataTable = informationServiceProxy.Query("SELECT TOP 1 Prefix, KeyProperty, NameProperty FROM Orion.NetObjectTypes WHERE EntityType = @entityType", new Dictionary<string, object>
				{
					{
						"entityType",
						entityType
					}
				});
				if (dataTable != null && dataTable.Rows.Count == 1)
				{
					string arg = dataTable.Rows[0]["Prefix"] as string;
					object obj = dataTable.Rows[0]["KeyProperty"];
					object obj2 = dataTable.Rows[0]["NameProperty"];
					instanceInformation.NetObject = string.Format("{0}:{1}", arg, instanceId);
					if (obj != DBNull.Value && obj != DBNull.Value)
					{
						DataTable dataTable2 = informationServiceProxy.Query(string.Format("SELECT {0} FROM {1} WHERE {2} = @InstanceId", obj2, entityType, obj), new Dictionary<string, object>
						{
							{
								"InstanceId",
								instanceId
							}
						});
						if (dataTable2 != null && dataTable2.Rows.Count > 0)
						{
							instanceInformation.InstanceName = dataTable2.Rows[0][obj2.ToString()].ToString();
						}
						else
						{
							instanceInformation.InstanceName = instanceInformation.NetObject;
						}
					}
					else
					{
						instanceInformation.InstanceName = instanceInformation.NetObject;
					}
				}
			}
			return instanceInformation;
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x0001F218 File Offset: 0x0001D418
		public void LoadPreviousThresholdData(int instanceId, string thresholdName)
		{
			using (IInformationServiceProxy2 informationServiceProxy = this._swisFactory.CreateConnection())
			{
				this._previousThresholdValues = informationServiceProxy.Query("SELECT OT.ThresholdOperator,\r\n                    OT.Level1Value,\r\n                    OT.Level1Formula,\r\n                    OT.Level2Value,\r\n                    OT.Level2Formula,\r\n                    OT.WarningPolls,\r\n                    OT.WarningPollsInterval,\r\n                    OT.CriticalPolls,\r\n                    OT.CriticalPollsInterval,\r\n                    OT.WarningEnabled,\r\n                    OT.CriticalEnabled\r\n                    FROM Orion.Thresholds OT\r\n                    WHERE OT.InstanceId = @InstanceId AND OT.Name = @Name", new Dictionary<string, object>
				{
					{
						"InstanceId",
						instanceId
					},
					{
						"Name",
						thresholdName
					}
				});
			}
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x0001F280 File Offset: 0x0001D480
		private string GetThresholdEntityType(string thresholdName)
		{
			using (IInformationServiceProxy2 informationServiceProxy = this._swisFactory.CreateConnection())
			{
				DataTable dataTable = informationServiceProxy.Query("SELECT EntityType FROM Orion.Thresholds WHERE Name = @Name", new Dictionary<string, object>
				{
					{
						"Name",
						thresholdName
					}
				});
				if (dataTable != null && dataTable.Rows.Count > 0)
				{
					return dataTable.Rows[0]["EntityType"].ToString();
				}
			}
			return null;
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0001F304 File Offset: 0x0001D504
		public void ReportThresholdNotification(Threshold threshold)
		{
			if (threshold == null)
			{
				throw new ArgumentNullException("threshold");
			}
			string thresholdEntityType = this.GetThresholdEntityType(threshold.ThresholdName);
			ThresholdIndicator.InstanceInformation instanceInformation = this.GetInstanceInformation(thresholdEntityType, threshold.InstanceId);
			PropertyBag propertyBag = new PropertyBag();
			propertyBag.Add("InstanceType", "Orion.Thresholds");
			propertyBag.Add("Name", threshold.ThresholdName);
			propertyBag.Add("InstanceName", (instanceInformation != null) ? instanceInformation.InstanceName : threshold.InstanceId.ToString());
			propertyBag.Add("InstanceId", threshold.InstanceId);
			propertyBag.Add("ThresholdType", threshold.ThresholdType);
			propertyBag.Add("ThresholdOperator", threshold.ThresholdOperator);
			propertyBag.Add("Level1Value", threshold.Warning);
			propertyBag.Add("Level2Value", threshold.Critical);
			propertyBag.Add("Level1Formula", threshold.WarningFormula);
			propertyBag.Add("Level2Formula", threshold.CriticalFormula);
			propertyBag.Add("WarningPolls", threshold.WarningPolls);
			propertyBag.Add("WarningPollsInterval", threshold.WarningPollsInterval);
			propertyBag.Add("CriticalPolls", threshold.CriticalPolls);
			propertyBag.Add("CriticalPollsInterval", threshold.CriticalPollsInterval);
			propertyBag.Add("WarningEnabled", threshold.WarningEnabled);
			propertyBag.Add("CriticalEnabled", threshold.CriticalEnabled);
			PropertyBag propertyBag2 = propertyBag;
			if (instanceInformation != null && !string.IsNullOrEmpty(instanceInformation.NetObject))
			{
				propertyBag2.Add("NetObject", instanceInformation.NetObject);
			}
			if (this._previousThresholdValues != null && this._previousThresholdValues.Rows.Count > 0)
			{
				Dictionary<string, object> dictionary = new Dictionary<string, object>();
				object obj = this._previousThresholdValues.Rows[0]["ThresholdOperator"];
				object obj2 = this._previousThresholdValues.Rows[0]["Level1Value"];
				object obj3 = this._previousThresholdValues.Rows[0]["Level2Value"];
				object obj4 = this._previousThresholdValues.Rows[0]["Level1Formula"];
				object obj5 = this._previousThresholdValues.Rows[0]["Level2Formula"];
				object obj6 = this._previousThresholdValues.Rows[0]["WarningPolls"];
				object obj7 = this._previousThresholdValues.Rows[0]["WarningPollsInterval"];
				object obj8 = this._previousThresholdValues.Rows[0]["CriticalPolls"];
				object obj9 = this._previousThresholdValues.Rows[0]["CriticalPollsInterval"];
				object obj10 = this._previousThresholdValues.Rows[0]["WarningEnabled"];
				object obj11 = this._previousThresholdValues.Rows[0]["CriticalEnabled"];
				dictionary.Add("ThresholdOperator", (obj != DBNull.Value) ? obj : null);
				dictionary.Add("Level1Value", (obj2 != DBNull.Value) ? obj2 : null);
				dictionary.Add("Level2Value", (obj3 != DBNull.Value) ? obj3 : null);
				dictionary.Add("Level1Formula", (obj4 != DBNull.Value) ? obj4 : null);
				dictionary.Add("Level2Formula", (obj5 != DBNull.Value) ? obj5 : null);
				dictionary.Add("WarningPolls", (obj6 != DBNull.Value) ? obj6 : null);
				dictionary.Add("WarningPollsInterval", (obj7 != DBNull.Value) ? obj7 : null);
				dictionary.Add("CriticalPolls", (obj8 != DBNull.Value) ? obj8 : null);
				dictionary.Add("CriticalPollsInterval", (obj9 != DBNull.Value) ? obj9 : null);
				dictionary.Add("WarningEnabled", (obj10 != DBNull.Value) ? obj10 : null);
				dictionary.Add("CriticalEnabled", (obj11 != DBNull.Value) ? obj11 : null);
				if (dictionary.Count > 0)
				{
					propertyBag2.Add("PreviousProperties", dictionary);
				}
				this._previousThresholdValues.Clear();
			}
			this._publishManager.Publish(new ThresholdNotification(IndicationHelper.GetIndicationType(2), propertyBag2));
		}

		// Token: 0x0400015D RID: 349
		private readonly IInformationServiceProxyFactory _swisFactory;

		// Token: 0x0400015E RID: 350
		private readonly IPublisherManager _publishManager;

		// Token: 0x0400015F RID: 351
		private DataTable _previousThresholdValues;

		// Token: 0x0200015D RID: 349
		public class InstanceInformation
		{
			// Token: 0x17000147 RID: 327
			// (get) Token: 0x06000B8D RID: 2957 RVA: 0x0004A30D File Offset: 0x0004850D
			// (set) Token: 0x06000B8E RID: 2958 RVA: 0x0004A315 File Offset: 0x00048515
			public string NetObject { get; set; }

			// Token: 0x17000148 RID: 328
			// (get) Token: 0x06000B8F RID: 2959 RVA: 0x0004A31E File Offset: 0x0004851E
			// (set) Token: 0x06000B90 RID: 2960 RVA: 0x0004A326 File Offset: 0x00048526
			public string InstanceName { get; set; }
		}
	}
}
