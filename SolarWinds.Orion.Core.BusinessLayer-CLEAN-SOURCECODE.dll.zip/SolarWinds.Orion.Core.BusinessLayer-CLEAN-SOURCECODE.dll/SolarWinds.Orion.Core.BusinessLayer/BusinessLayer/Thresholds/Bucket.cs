﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.Thresholds
{
	// Token: 0x02000053 RID: 83
	internal class Bucket
	{
		// Token: 0x060004E8 RID: 1256 RVA: 0x0001F018 File Offset: 0x0001D218
		public Bucket(double minValue, double maxValue)
		{
			this.MinValue = minValue;
			this.MaxValue = maxValue;
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x0001F02E File Offset: 0x0001D22E
		// (set) Token: 0x060004EA RID: 1258 RVA: 0x0001F036 File Offset: 0x0001D236
		public double MinValue { get; set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060004EB RID: 1259 RVA: 0x0001F03F File Offset: 0x0001D23F
		// (set) Token: 0x060004EC RID: 1260 RVA: 0x0001F047 File Offset: 0x0001D247
		public double MaxValue { get; set; }
	}
}
