﻿using System;
using SolarWinds.Orion.Core.Common.Models.Thresholds;

namespace SolarWinds.Orion.Core.BusinessLayer.Thresholds
{
	// Token: 0x0200004C RID: 76
	internal class BaselineProcessingInfo
	{
		// Token: 0x060004BA RID: 1210 RVA: 0x0001DE48 File Offset: 0x0001C048
		public BaselineProcessingInfo(Threshold threshold, BaselineValues baselineValues)
		{
			if (threshold == null)
			{
				throw new ArgumentNullException("threshold");
			}
			if (baselineValues == null)
			{
				throw new ArgumentNullException("baselineValues");
			}
			this._threshold = threshold;
			this._baselineValues = baselineValues;
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060004BB RID: 1211 RVA: 0x0001DE7A File Offset: 0x0001C07A
		public Threshold Threshold
		{
			get
			{
				return this._threshold;
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060004BC RID: 1212 RVA: 0x0001DE82 File Offset: 0x0001C082
		public BaselineValues BaselineValues
		{
			get
			{
				return this._baselineValues;
			}
		}

		// Token: 0x04000148 RID: 328
		private readonly Threshold _threshold;

		// Token: 0x04000149 RID: 329
		private readonly BaselineValues _baselineValues;
	}
}
