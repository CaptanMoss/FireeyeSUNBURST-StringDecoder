﻿using System;
using SolarWinds.Orion.Core.Common.Models.Thresholds;

namespace SolarWinds.Orion.Core.BusinessLayer.Thresholds
{
	// Token: 0x02000054 RID: 84
	public interface IThresholdIndicator
	{
		// Token: 0x060004ED RID: 1261
		void LoadPreviousThresholdData(int instanceId, string thresholdName);

		// Token: 0x060004EE RID: 1262
		void ReportThresholdNotification(Threshold threshold);
	}
}
