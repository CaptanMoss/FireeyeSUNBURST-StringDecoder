﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.Linq;
using SolarWinds.Common.Threading;
using SolarWinds.Orion.Core.Common.Catalogs;
using SolarWinds.Orion.Core.Common.Settings;
using SolarWinds.Orion.Core.Common.Thresholds;

namespace SolarWinds.Orion.Core.BusinessLayer.Thresholds
{
	// Token: 0x02000057 RID: 87
	internal class ThresholdProcessingManager
	{
		// Token: 0x06000515 RID: 1301 RVA: 0x000213E8 File Offset: 0x0001F5E8
		internal ThresholdProcessingManager(ComposablePartCatalog catalog, ICollectorSettings settings)
		{
			this.ComposeParts(catalog);
			this._engine = new ThresholdProcessingEngine(this._thresholdProcessors, this._thresholdDataProviders, new ThresholdIndicator(), settings)
			{
				BatchSize = BusinessLayerSettings.Instance.ThresholdsProcessingBatchSize,
				BaselineTimeFrame = BusinessLayerSettings.Instance.ThresholdsProcessingDefaultTimeFrame
			};
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00021458 File Offset: 0x0001F658
		private void ComposeParts(ComposablePartCatalog catalog)
		{
			using (CompositionContainer compositionContainer = new CompositionContainer(catalog, Array.Empty<ExportProvider>()))
			{
				compositionContainer.ComposeParts(new object[]
				{
					this
				});
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000517 RID: 1303 RVA: 0x000214A0 File Offset: 0x0001F6A0
		public static ThresholdProcessingManager Instance
		{
			get
			{
				return ThresholdProcessingManager._instance.Value;
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x06000518 RID: 1304 RVA: 0x000214AC File Offset: 0x0001F6AC
		// (set) Token: 0x06000519 RID: 1305 RVA: 0x000214B3 File Offset: 0x0001F6B3
		internal static CompositionContainer CompositionContainer { get; set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600051A RID: 1306 RVA: 0x000214BB File Offset: 0x0001F6BB
		public ThresholdProcessingEngine Engine
		{
			get
			{
				return this._engine;
			}
		}

		// Token: 0x04000169 RID: 361
		private static readonly LazyWithoutExceptionCache<ThresholdProcessingManager> _instance = new LazyWithoutExceptionCache<ThresholdProcessingManager>(delegate()
		{
			ThresholdProcessingManager result;
			using (ComposablePartCatalog catalogForArea = MEFPluginsLoader.Instance.GetCatalogForArea("Thresholds"))
			{
				result = new ThresholdProcessingManager(catalogForArea, CollectorSettings.Instance);
			}
			return result;
		});

		// Token: 0x0400016A RID: 362
		[ImportMany(typeof(IThresholdDataProcessor))]
		private IEnumerable<IThresholdDataProcessor> _thresholdProcessors = Enumerable.Empty<IThresholdDataProcessor>();

		// Token: 0x0400016B RID: 363
		[ImportMany(typeof(ThresholdDataProvider))]
		private IEnumerable<ThresholdDataProvider> _thresholdDataProviders = Enumerable.Empty<ThresholdDataProvider>();

		// Token: 0x0400016C RID: 364
		private readonly ThresholdProcessingEngine _engine;
	}
}
