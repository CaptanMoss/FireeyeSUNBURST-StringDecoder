﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x0200003B RID: 59
	internal abstract class SynchronizeItem
	{
		// Token: 0x060003FF RID: 1023
		public abstract object GetDatabaseValue();
	}
}
