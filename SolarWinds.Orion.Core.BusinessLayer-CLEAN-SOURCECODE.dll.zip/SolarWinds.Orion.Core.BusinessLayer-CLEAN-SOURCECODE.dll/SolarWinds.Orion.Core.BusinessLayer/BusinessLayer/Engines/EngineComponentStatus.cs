﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.Engines
{
	// Token: 0x02000077 RID: 119
	public enum EngineComponentStatus
	{
		// Token: 0x040001D8 RID: 472
		Up,
		// Token: 0x040001D9 RID: 473
		Down
	}
}
