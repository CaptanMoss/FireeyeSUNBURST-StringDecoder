﻿using System;

namespace SolarWinds.Orion.Core.BusinessLayer.Engines
{
	// Token: 0x02000078 RID: 120
	public interface IEngineComponent
	{
		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x060005FA RID: 1530
		int EngineId { get; }

		// Token: 0x060005FB RID: 1531
		EngineComponentStatus GetStatus();
	}
}
