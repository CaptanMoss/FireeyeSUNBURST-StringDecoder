﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using SolarWinds.Net.SNMP;

namespace SolarWinds.Orion.Core.BusinessLayer
{
	// Token: 0x0200003D RID: 61
	public class SNMPManagerWrapper
	{
		// Token: 0x06000405 RID: 1029 RVA: 0x0001BE44 File Offset: 0x0001A044
		public SNMPManagerWrapper()
		{
			this.bgworker.DoWork += this.bgworker_DoWork;
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x0001BE98 File Offset: 0x0001A098
		private void bgworker_DoWork(object sender, DoWorkEventArgs e)
		{
			while (this._doWork)
			{
				bool flag = false;
				Queue<SNMPRequest> query = this._Query;
				lock (query)
				{
					if (this._Query.Count > 0)
					{
						if (this._manager.OutstandingQueries <= 5)
						{
							SNMPRequest snR = this._Query.Dequeue();
							int num = 0;
							string empty = string.Empty;
							this.BeginQuery(snR, true, out num, out empty);
						}
						else
						{
							flag = true;
						}
					}
					else
					{
						flag = true;
					}
				}
				if (flag)
				{
					Thread.Sleep(100);
				}
			}
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x0001BF30 File Offset: 0x0001A130
		public bool BeginQuery(SNMPRequest snR, bool used, out int err, out string ErrDes)
		{
			Queue<SNMPRequest> query = this._Query;
			bool result;
			lock (query)
			{
				if (this._manager.OutstandingQueries > 5)
				{
					this._Query.Enqueue(snR);
					if (!this.bgworker.IsBusy)
					{
						this.bgworker.RunWorkerAsync();
					}
					err = 0;
					ErrDes = string.Empty;
					result = true;
				}
				else
				{
					result = this._manager.BeginQuery(snR, used, ref err, ref ErrDes);
				}
			}
			return result;
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000408 RID: 1032 RVA: 0x0001BFC0 File Offset: 0x0001A1C0
		public int OutstandingQueries
		{
			get
			{
				Queue<SNMPRequest> query = this._Query;
				int result;
				lock (query)
				{
					result = this._manager.OutstandingQueries + this._Query.Count;
				}
				return result;
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000409 RID: 1033 RVA: 0x0001C014 File Offset: 0x0001A214
		public SNMPRequest DefaultInfo
		{
			get
			{
				return this._manager.DefaultInfo;
			}
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0001C021 File Offset: 0x0001A221
		public SNMPResponse Query(SNMPRequest snR, bool usDI)
		{
			return this._manager.Query(snR, usDI);
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0001C030 File Offset: 0x0001A230
		public void Cancel()
		{
			this._manager.Cancel();
			this._doWork = false;
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0001C044 File Offset: 0x0001A244
		public void Dispose()
		{
			this._manager.Dispose();
			this._doWork = false;
		}

		// Token: 0x040000EB RID: 235
		private SNMPManager _manager = new SNMPManager();

		// Token: 0x040000EC RID: 236
		private const int _maxCount = 5;

		// Token: 0x040000ED RID: 237
		private Queue<SNMPRequest> _Query = new Queue<SNMPRequest>();

		// Token: 0x040000EE RID: 238
		private BackgroundWorker bgworker = new BackgroundWorker();

		// Token: 0x040000EF RID: 239
		private bool _doWork = true;
	}
}
